"""
Este módulo contiene funciones para realizar operaciones de importación a la base de datos.
"""
# pylint: disable=c-extension-no-member
import pyodbc
#from bd import conexion

# Obtener los datos del formulario

SERVER = 'SERVHISTORI'
BD = 'balanzapt_carveout'
USUARIO = 'sa'
CONTRASENA = 'Cimplicity1'

try:
    conexion = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' +
                              SERVER+';DATABASE='+BD+';UID='+USUARIO+';PWD=' + CONTRASENA)
    print('Conexion Exitosa')
except pyodbc.Error:
    print('error al conectarse')

# Ejecutar la consulta
CONSULTA = 'SELECT * FROM [Asistencia].[dbo].[mensaje]'
cursor = conexion.cursor()
cursor.execute(CONSULTA)

# Obtener los resultados
resultados = []

for fila in cursor.fetchall():
    resultado = {
        'Id': fila[0],
        'Nombre': fila[1],
        'Email': fila[2],
        'Mensaje': fila[3]
    }
    resultados.append(resultado)

# Cerrar la conexión
conexion.close()

# Hacer algo con los resultados
print(resultados)
