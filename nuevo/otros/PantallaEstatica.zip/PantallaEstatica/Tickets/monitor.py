from tkinter import Tk, ttk, Label, PhotoImage, Frame
import pyodbc
from datetime import datetime

def obtener_conexion_db():
    try:
        conexion = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=10.32.60.118;'
            'DATABASE=database_IOP;'
            'UID=ctcuser;'
            'PWD=ctcuser',
            timeout=5  # Timeout para la conexión
        )
        return conexion
    except pyodbc.Error as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None

def obtener_datos():
    conn = obtener_conexion_db()
    if conn is None:
        return []  # Si no hay conexión, retornar lista vacía
    try:
        cursor = conn.cursor()
        cursor.execute("EXEC VentanaEstaticaObjetivosDiarios")
        filas = cursor.fetchall()
        conn.close()
        return filas
    except pyodbc.Error as e:
        print(f"Error al ejecutar la consulta: {e}")
        return []  # Retornar lista vacía en caso de error

def actualizar_datos():
    datos = obtener_datos()
    
    # Si no se pueden obtener datos, no hacer nada
    if not datos:
        print("No se pudieron obtener datos. Reintentando en 5 segundos...")
        ventana.after(5000, actualizar_datos)  # Reintentar en 5 segundos
        return

    # Actualizar filas solo si hay cambios
    for i, fila in enumerate(datos):
        tag = 'impar' if i % 2 == 0 else 'par'
        if i < len(fila_ids):
            tabla.item(fila_ids[i], values=tuple(fila), tags=(tag,))
        else:
            fila_id = tabla.insert("", "end", values=tuple(fila), tags=(tag,))
            fila_ids.append(fila_id)

    # Programar la próxima actualización en 2 segundos
    ventana.after(4000, actualizar_datos)

def actualizar_hora():
    fecha_hora_actual = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    label_fecha.config(text=f"Fecha: {fecha_hora_actual}")
    ventana.after(1000, actualizar_hora)

def configurar_ventana():
    global tabla, fila_ids, label_fecha, ventana

    # Crear ventana principal
    ventana = Tk()
    ventana.title("Reporte en Tiempo Real")
    ventana.attributes('-topmost', True)

    # Crear un marco para el logo y las etiquetas
    frame_superior = Frame(ventana, bg='#00a134')
    frame_superior.pack(fill="x", pady=(10, 0))

    # Cargar el logo
    logo = PhotoImage(file="cania.png")
    label_logo = Label(frame_superior, image=logo, bg='#00a134')
    label_logo.pack(side="left", padx=(10, 10))

    frame_texto = Frame(frame_superior, bg='#00a134')
    frame_texto.pack(side="left", padx=(10, 10), expand=True)

    label_titulo = Label(frame_texto, text="Objetivo del Día", font=("Arial", 18, "bold"), bg='#00a134', fg="white")
    label_titulo.pack(anchor="center")

    label_fecha = Label(frame_texto, font=("Arial", 12), bg='#00a134', fg="white")
    label_fecha.pack(anchor="center")

    # Iniciar la actualización de la hora
    actualizar_hora()

    # Configurar el estilo de la tabla
    estilo = ttk.Style()
    estilo.configure("Treeview",
                     background="white",
                     foreground="black",
                     fieldbackground="white",
                     font=("Arial", 15))
    estilo.configure("Treeview.Heading",
                     background="green",
                     foreground="green",
                     font=("Arial", 14, "bold"))
    estilo.map("Treeview.Heading", background=[('active', '#5A9BD5')])

    # Configurar la tabla
    tabla = ttk.Treeview(ventana, columns=("Reporte", "Objetivo", "Real", "% de Avance", "Acumulado Mes"), show="headings")
    tabla.heading("Reporte", text="Reporte")
    tabla.heading("Objetivo", text="Objetivo")
    tabla.heading("Real", text="Real")
    tabla.heading("% de Avance", text="% de Avance")
    tabla.heading("Acumulado Mes", text="Acumulado Mes")

    for col in tabla["columns"]:
        tabla.column(col, anchor="center", width=100)

    tabla.tag_configure('impar', background='#E1E1E1')
    tabla.tag_configure('par', background='#FFFFFF')

    tabla.pack(fill="both", expand=True)

    # Inicializar filas de la tabla
    fila_ids = []

    # Iniciar actualización de datos
    ventana.after(0, actualizar_datos)

    # Ejecutar la ventana principal
    ventana.mainloop()

if __name__ == "__main__":
    configurar_ventana()
