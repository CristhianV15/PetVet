﻿namespace CaniaBrava
{
    partial class ui_asgHorPer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIdAsigHor = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dTimeFecFin = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.dTimeFecInicio = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cbAmPmDo2 = new System.Windows.Forms.ComboBox();
            this.cbAmPmSa2 = new System.Windows.Forms.ComboBox();
            this.cbAmPmVi2 = new System.Windows.Forms.ComboBox();
            this.cbAmPmJu2 = new System.Windows.Forms.ComboBox();
            this.cbAmPmMi2 = new System.Windows.Forms.ComboBox();
            this.cbAmPmMa2 = new System.Windows.Forms.ComboBox();
            this.cbAmPmLu2 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.nDoMin2 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.nDoHor2 = new System.Windows.Forms.NumericUpDown();
            this.cbAmPmDo1 = new System.Windows.Forms.ComboBox();
            this.nDoMin1 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.nDoHor1 = new System.Windows.Forms.NumericUpDown();
            this.nSaMin2 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.nSaHor2 = new System.Windows.Forms.NumericUpDown();
            this.cbAmPmSa1 = new System.Windows.Forms.ComboBox();
            this.nSaMin1 = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.nSaHor1 = new System.Windows.Forms.NumericUpDown();
            this.nViMin2 = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.nViHor2 = new System.Windows.Forms.NumericUpDown();
            this.cbAmPmVi1 = new System.Windows.Forms.ComboBox();
            this.nViMin1 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.nViHor1 = new System.Windows.Forms.NumericUpDown();
            this.nJuMin2 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nJuHor2 = new System.Windows.Forms.NumericUpDown();
            this.cbAmPmJu1 = new System.Windows.Forms.ComboBox();
            this.nJuMin1 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nJuHor1 = new System.Windows.Forms.NumericUpDown();
            this.nMiMin2 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.nMiHor2 = new System.Windows.Forms.NumericUpDown();
            this.cbAmPmMi1 = new System.Windows.Forms.ComboBox();
            this.nMiMin1 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.nMiHor1 = new System.Windows.Forms.NumericUpDown();
            this.nMaMin2 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nMaHor2 = new System.Windows.Forms.NumericUpDown();
            this.cbAmPmMa1 = new System.Windows.Forms.ComboBox();
            this.nMaMin1 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nMaHor1 = new System.Windows.Forms.NumericUpDown();
            this.nLuMin2 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nLuHor2 = new System.Windows.Forms.NumericUpDown();
            this.chkJu = new System.Windows.Forms.CheckBox();
            this.cbAmPmLu1 = new System.Windows.Forms.ComboBox();
            this.nLuMin1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.nLuHor1 = new System.Windows.Forms.NumericUpDown();
            this.chkDo = new System.Windows.Forms.CheckBox();
            this.chkSa = new System.Windows.Forms.CheckBox();
            this.chkVi = new System.Windows.Forms.CheckBox();
            this.chkMi = new System.Windows.Forms.CheckBox();
            this.chkMa = new System.Windows.Forms.CheckBox();
            this.chkLu = new System.Windows.Forms.CheckBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.btnAsignar = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblF2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNombres = new System.Windows.Forms.TextBox();
            this.txtNroDocIden = new System.Windows.Forms.TextBox();
            this.txtDocIdent = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCodigoInterno = new System.Windows.Forms.TextBox();
            this.pictureBoxBuscar = new System.Windows.Forms.PictureBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nDoMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nDoHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nDoMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nDoHor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaHor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViHor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuHor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiHor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaHor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuMin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuHor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuMin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuHor1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuscar)).BeginInit();
            this.SuspendLayout();
            // 
            // txtIdAsigHor
            // 
            this.txtIdAsigHor.Location = new System.Drawing.Point(303, 418);
            this.txtIdAsigHor.Name = "txtIdAsigHor";
            this.txtIdAsigHor.Size = new System.Drawing.Size(100, 20);
            this.txtIdAsigHor.TabIndex = 155;
            this.txtIdAsigHor.Text = "0";
            this.txtIdAsigHor.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dTimeFecFin);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.dTimeFecInicio);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Location = new System.Drawing.Point(8, 347);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(499, 53);
            this.groupBox2.TabIndex = 154;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Duracion de Horario";
            // 
            // dTimeFecFin
            // 
            this.dTimeFecFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTimeFecFin.Location = new System.Drawing.Point(308, 19);
            this.dTimeFecFin.Name = "dTimeFecFin";
            this.dTimeFecFin.Size = new System.Drawing.Size(85, 20);
            this.dTimeFecFin.TabIndex = 69;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(268, 22);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(34, 13);
            this.label20.TabIndex = 89;
            this.label20.Text = "Final";
            // 
            // dTimeFecInicio
            // 
            this.dTimeFecInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTimeFecInicio.Location = new System.Drawing.Point(126, 19);
            this.dTimeFecInicio.Name = "dTimeFecInicio";
            this.dTimeFecInicio.Size = new System.Drawing.Size(85, 20);
            this.dTimeFecInicio.TabIndex = 68;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(82, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(38, 13);
            this.label22.TabIndex = 87;
            this.label22.Text = "Inicio";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.cbAmPmDo2);
            this.groupBox1.Controls.Add(this.cbAmPmSa2);
            this.groupBox1.Controls.Add(this.cbAmPmVi2);
            this.groupBox1.Controls.Add(this.cbAmPmJu2);
            this.groupBox1.Controls.Add(this.cbAmPmMi2);
            this.groupBox1.Controls.Add(this.cbAmPmMa2);
            this.groupBox1.Controls.Add(this.cbAmPmLu2);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.nDoMin2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.nDoHor2);
            this.groupBox1.Controls.Add(this.cbAmPmDo1);
            this.groupBox1.Controls.Add(this.nDoMin1);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.nDoHor1);
            this.groupBox1.Controls.Add(this.nSaMin2);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.nSaHor2);
            this.groupBox1.Controls.Add(this.cbAmPmSa1);
            this.groupBox1.Controls.Add(this.nSaMin1);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.nSaHor1);
            this.groupBox1.Controls.Add(this.nViMin2);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.nViHor2);
            this.groupBox1.Controls.Add(this.cbAmPmVi1);
            this.groupBox1.Controls.Add(this.nViMin1);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.nViHor1);
            this.groupBox1.Controls.Add(this.nJuMin2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.nJuHor2);
            this.groupBox1.Controls.Add(this.cbAmPmJu1);
            this.groupBox1.Controls.Add(this.nJuMin1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.nJuHor1);
            this.groupBox1.Controls.Add(this.nMiMin2);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.nMiHor2);
            this.groupBox1.Controls.Add(this.cbAmPmMi1);
            this.groupBox1.Controls.Add(this.nMiMin1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.nMiHor1);
            this.groupBox1.Controls.Add(this.nMaMin2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nMaHor2);
            this.groupBox1.Controls.Add(this.cbAmPmMa1);
            this.groupBox1.Controls.Add(this.nMaMin1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.nMaHor1);
            this.groupBox1.Controls.Add(this.nLuMin2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.nLuHor2);
            this.groupBox1.Controls.Add(this.chkJu);
            this.groupBox1.Controls.Add(this.cbAmPmLu1);
            this.groupBox1.Controls.Add(this.nLuMin1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.nLuHor1);
            this.groupBox1.Controls.Add(this.chkDo);
            this.groupBox1.Controls.Add(this.chkSa);
            this.groupBox1.Controls.Add(this.chkVi);
            this.groupBox1.Controls.Add(this.chkMi);
            this.groupBox1.Controls.Add(this.chkMa);
            this.groupBox1.Controls.Add(this.chkLu);
            this.groupBox1.Controls.Add(this.chkAll);
            this.groupBox1.Location = new System.Drawing.Point(8, 124);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(499, 209);
            this.groupBox1.TabIndex = 153;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Horario";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(361, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 13);
            this.label19.TabIndex = 82;
            this.label19.Text = "Salida";
            // 
            // cbAmPmDo2
            // 
            this.cbAmPmDo2.FormattingEnabled = true;
            this.cbAmPmDo2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmDo2.Location = new System.Drawing.Point(409, 180);
            this.cbAmPmDo2.Name = "cbAmPmDo2";
            this.cbAmPmDo2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmDo2.TabIndex = 67;
            // 
            // cbAmPmSa2
            // 
            this.cbAmPmSa2.FormattingEnabled = true;
            this.cbAmPmSa2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmSa2.Location = new System.Drawing.Point(409, 157);
            this.cbAmPmSa2.Name = "cbAmPmSa2";
            this.cbAmPmSa2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmSa2.TabIndex = 59;
            // 
            // cbAmPmVi2
            // 
            this.cbAmPmVi2.FormattingEnabled = true;
            this.cbAmPmVi2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmVi2.Location = new System.Drawing.Point(409, 134);
            this.cbAmPmVi2.Name = "cbAmPmVi2";
            this.cbAmPmVi2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmVi2.TabIndex = 51;
            // 
            // cbAmPmJu2
            // 
            this.cbAmPmJu2.FormattingEnabled = true;
            this.cbAmPmJu2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmJu2.Location = new System.Drawing.Point(409, 111);
            this.cbAmPmJu2.Name = "cbAmPmJu2";
            this.cbAmPmJu2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmJu2.TabIndex = 43;
            // 
            // cbAmPmMi2
            // 
            this.cbAmPmMi2.FormattingEnabled = true;
            this.cbAmPmMi2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmMi2.Location = new System.Drawing.Point(409, 88);
            this.cbAmPmMi2.Name = "cbAmPmMi2";
            this.cbAmPmMi2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmMi2.TabIndex = 35;
            // 
            // cbAmPmMa2
            // 
            this.cbAmPmMa2.FormattingEnabled = true;
            this.cbAmPmMa2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmMa2.Location = new System.Drawing.Point(409, 65);
            this.cbAmPmMa2.Name = "cbAmPmMa2";
            this.cbAmPmMa2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmMa2.TabIndex = 27;
            // 
            // cbAmPmLu2
            // 
            this.cbAmPmLu2.FormattingEnabled = true;
            this.cbAmPmLu2.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmLu2.Location = new System.Drawing.Point(409, 42);
            this.cbAmPmLu2.Name = "cbAmPmLu2";
            this.cbAmPmLu2.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmLu2.TabIndex = 19;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(175, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 13);
            this.label18.TabIndex = 74;
            this.label18.Text = "Entrada";
            // 
            // nDoMin2
            // 
            this.nDoMin2.Location = new System.Drawing.Point(363, 179);
            this.nDoMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nDoMin2.Name = "nDoMin2";
            this.nDoMin2.Size = new System.Drawing.Size(40, 20);
            this.nDoMin2.TabIndex = 66;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(348, 175);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 24);
            this.label12.TabIndex = 65;
            this.label12.Text = ":";
            // 
            // nDoHor2
            // 
            this.nDoHor2.Location = new System.Drawing.Point(308, 179);
            this.nDoHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nDoHor2.Name = "nDoHor2";
            this.nDoHor2.Size = new System.Drawing.Size(40, 20);
            this.nDoHor2.TabIndex = 64;
            // 
            // cbAmPmDo1
            // 
            this.cbAmPmDo1.FormattingEnabled = true;
            this.cbAmPmDo1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmDo1.Location = new System.Drawing.Point(228, 178);
            this.cbAmPmDo1.Name = "cbAmPmDo1";
            this.cbAmPmDo1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmDo1.TabIndex = 63;
            // 
            // nDoMin1
            // 
            this.nDoMin1.Location = new System.Drawing.Point(182, 179);
            this.nDoMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nDoMin1.Name = "nDoMin1";
            this.nDoMin1.Size = new System.Drawing.Size(40, 20);
            this.nDoMin1.TabIndex = 62;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(167, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 24);
            this.label13.TabIndex = 61;
            this.label13.Text = ":";
            // 
            // nDoHor1
            // 
            this.nDoHor1.Location = new System.Drawing.Point(126, 179);
            this.nDoHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nDoHor1.Name = "nDoHor1";
            this.nDoHor1.Size = new System.Drawing.Size(40, 20);
            this.nDoHor1.TabIndex = 60;
            // 
            // nSaMin2
            // 
            this.nSaMin2.Location = new System.Drawing.Point(363, 156);
            this.nSaMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nSaMin2.Name = "nSaMin2";
            this.nSaMin2.Size = new System.Drawing.Size(40, 20);
            this.nSaMin2.TabIndex = 58;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(348, 152);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 24);
            this.label14.TabIndex = 57;
            this.label14.Text = ":";
            // 
            // nSaHor2
            // 
            this.nSaHor2.Location = new System.Drawing.Point(308, 156);
            this.nSaHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nSaHor2.Name = "nSaHor2";
            this.nSaHor2.Size = new System.Drawing.Size(40, 20);
            this.nSaHor2.TabIndex = 56;
            // 
            // cbAmPmSa1
            // 
            this.cbAmPmSa1.FormattingEnabled = true;
            this.cbAmPmSa1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmSa1.Location = new System.Drawing.Point(228, 155);
            this.cbAmPmSa1.Name = "cbAmPmSa1";
            this.cbAmPmSa1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmSa1.TabIndex = 55;
            // 
            // nSaMin1
            // 
            this.nSaMin1.Location = new System.Drawing.Point(182, 156);
            this.nSaMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nSaMin1.Name = "nSaMin1";
            this.nSaMin1.Size = new System.Drawing.Size(40, 20);
            this.nSaMin1.TabIndex = 54;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(167, 152);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 24);
            this.label15.TabIndex = 53;
            this.label15.Text = ":";
            // 
            // nSaHor1
            // 
            this.nSaHor1.Location = new System.Drawing.Point(126, 156);
            this.nSaHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nSaHor1.Name = "nSaHor1";
            this.nSaHor1.Size = new System.Drawing.Size(40, 20);
            this.nSaHor1.TabIndex = 52;
            // 
            // nViMin2
            // 
            this.nViMin2.Location = new System.Drawing.Point(363, 133);
            this.nViMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nViMin2.Name = "nViMin2";
            this.nViMin2.Size = new System.Drawing.Size(40, 20);
            this.nViMin2.TabIndex = 50;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(348, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 24);
            this.label16.TabIndex = 49;
            this.label16.Text = ":";
            // 
            // nViHor2
            // 
            this.nViHor2.Location = new System.Drawing.Point(308, 133);
            this.nViHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nViHor2.Name = "nViHor2";
            this.nViHor2.Size = new System.Drawing.Size(40, 20);
            this.nViHor2.TabIndex = 48;
            // 
            // cbAmPmVi1
            // 
            this.cbAmPmVi1.FormattingEnabled = true;
            this.cbAmPmVi1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmVi1.Location = new System.Drawing.Point(228, 132);
            this.cbAmPmVi1.Name = "cbAmPmVi1";
            this.cbAmPmVi1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmVi1.TabIndex = 47;
            // 
            // nViMin1
            // 
            this.nViMin1.Location = new System.Drawing.Point(182, 133);
            this.nViMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nViMin1.Name = "nViMin1";
            this.nViMin1.Size = new System.Drawing.Size(40, 20);
            this.nViMin1.TabIndex = 46;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(167, 129);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(16, 24);
            this.label17.TabIndex = 45;
            this.label17.Text = ":";
            // 
            // nViHor1
            // 
            this.nViHor1.Location = new System.Drawing.Point(126, 133);
            this.nViHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nViHor1.Name = "nViHor1";
            this.nViHor1.Size = new System.Drawing.Size(40, 20);
            this.nViHor1.TabIndex = 44;
            // 
            // nJuMin2
            // 
            this.nJuMin2.Location = new System.Drawing.Point(363, 110);
            this.nJuMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nJuMin2.Name = "nJuMin2";
            this.nJuMin2.Size = new System.Drawing.Size(40, 20);
            this.nJuMin2.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(348, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 24);
            this.label5.TabIndex = 41;
            this.label5.Text = ":";
            // 
            // nJuHor2
            // 
            this.nJuHor2.Location = new System.Drawing.Point(308, 110);
            this.nJuHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nJuHor2.Name = "nJuHor2";
            this.nJuHor2.Size = new System.Drawing.Size(40, 20);
            this.nJuHor2.TabIndex = 40;
            // 
            // cbAmPmJu1
            // 
            this.cbAmPmJu1.FormattingEnabled = true;
            this.cbAmPmJu1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmJu1.Location = new System.Drawing.Point(228, 109);
            this.cbAmPmJu1.Name = "cbAmPmJu1";
            this.cbAmPmJu1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmJu1.TabIndex = 39;
            // 
            // nJuMin1
            // 
            this.nJuMin1.Location = new System.Drawing.Point(182, 110);
            this.nJuMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nJuMin1.Name = "nJuMin1";
            this.nJuMin1.Size = new System.Drawing.Size(40, 20);
            this.nJuMin1.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(167, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 24);
            this.label6.TabIndex = 37;
            this.label6.Text = ":";
            // 
            // nJuHor1
            // 
            this.nJuHor1.Location = new System.Drawing.Point(126, 110);
            this.nJuHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nJuHor1.Name = "nJuHor1";
            this.nJuHor1.Size = new System.Drawing.Size(40, 20);
            this.nJuHor1.TabIndex = 36;
            // 
            // nMiMin2
            // 
            this.nMiMin2.Location = new System.Drawing.Point(363, 87);
            this.nMiMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nMiMin2.Name = "nMiMin2";
            this.nMiMin2.Size = new System.Drawing.Size(40, 20);
            this.nMiMin2.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(348, 83);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 24);
            this.label10.TabIndex = 33;
            this.label10.Text = ":";
            // 
            // nMiHor2
            // 
            this.nMiHor2.Location = new System.Drawing.Point(308, 87);
            this.nMiHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nMiHor2.Name = "nMiHor2";
            this.nMiHor2.Size = new System.Drawing.Size(40, 20);
            this.nMiHor2.TabIndex = 32;
            // 
            // cbAmPmMi1
            // 
            this.cbAmPmMi1.FormattingEnabled = true;
            this.cbAmPmMi1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmMi1.Location = new System.Drawing.Point(228, 86);
            this.cbAmPmMi1.Name = "cbAmPmMi1";
            this.cbAmPmMi1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmMi1.TabIndex = 31;
            // 
            // nMiMin1
            // 
            this.nMiMin1.Location = new System.Drawing.Point(182, 87);
            this.nMiMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nMiMin1.Name = "nMiMin1";
            this.nMiMin1.Size = new System.Drawing.Size(40, 20);
            this.nMiMin1.TabIndex = 30;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(167, 83);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 24);
            this.label11.TabIndex = 29;
            this.label11.Text = ":";
            // 
            // nMiHor1
            // 
            this.nMiHor1.Location = new System.Drawing.Point(126, 87);
            this.nMiHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nMiHor1.Name = "nMiHor1";
            this.nMiHor1.Size = new System.Drawing.Size(40, 20);
            this.nMiHor1.TabIndex = 28;
            // 
            // nMaMin2
            // 
            this.nMaMin2.Location = new System.Drawing.Point(363, 64);
            this.nMaMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nMaMin2.Name = "nMaMin2";
            this.nMaMin2.Size = new System.Drawing.Size(40, 20);
            this.nMaMin2.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(348, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 24);
            this.label3.TabIndex = 25;
            this.label3.Text = ":";
            // 
            // nMaHor2
            // 
            this.nMaHor2.Location = new System.Drawing.Point(308, 64);
            this.nMaHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nMaHor2.Name = "nMaHor2";
            this.nMaHor2.Size = new System.Drawing.Size(40, 20);
            this.nMaHor2.TabIndex = 24;
            // 
            // cbAmPmMa1
            // 
            this.cbAmPmMa1.FormattingEnabled = true;
            this.cbAmPmMa1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmMa1.Location = new System.Drawing.Point(228, 63);
            this.cbAmPmMa1.Name = "cbAmPmMa1";
            this.cbAmPmMa1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmMa1.TabIndex = 23;
            // 
            // nMaMin1
            // 
            this.nMaMin1.Location = new System.Drawing.Point(182, 64);
            this.nMaMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nMaMin1.Name = "nMaMin1";
            this.nMaMin1.Size = new System.Drawing.Size(40, 20);
            this.nMaMin1.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(167, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 24);
            this.label4.TabIndex = 21;
            this.label4.Text = ":";
            // 
            // nMaHor1
            // 
            this.nMaHor1.Location = new System.Drawing.Point(126, 64);
            this.nMaHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nMaHor1.Name = "nMaHor1";
            this.nMaHor1.Size = new System.Drawing.Size(40, 20);
            this.nMaHor1.TabIndex = 20;
            // 
            // nLuMin2
            // 
            this.nLuMin2.Location = new System.Drawing.Point(363, 41);
            this.nLuMin2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nLuMin2.Name = "nLuMin2";
            this.nLuMin2.Size = new System.Drawing.Size(40, 20);
            this.nLuMin2.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(348, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 24);
            this.label2.TabIndex = 17;
            this.label2.Text = ":";
            // 
            // nLuHor2
            // 
            this.nLuHor2.Location = new System.Drawing.Point(308, 41);
            this.nLuHor2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nLuHor2.Name = "nLuHor2";
            this.nLuHor2.Size = new System.Drawing.Size(40, 20);
            this.nLuHor2.TabIndex = 16;
            // 
            // chkJu
            // 
            this.chkJu.AutoSize = true;
            this.chkJu.Location = new System.Drawing.Point(14, 111);
            this.chkJu.Name = "chkJu";
            this.chkJu.Size = new System.Drawing.Size(60, 17);
            this.chkJu.TabIndex = 8;
            this.chkJu.Text = "Jueves";
            this.chkJu.UseVisualStyleBackColor = true;
            // 
            // cbAmPmLu1
            // 
            this.cbAmPmLu1.DisplayMember = "idAmPm";
            this.cbAmPmLu1.FormattingEnabled = true;
            this.cbAmPmLu1.Items.AddRange(new object[] {
            "a.m.",
            "p.m."});
            this.cbAmPmLu1.Location = new System.Drawing.Point(228, 40);
            this.cbAmPmLu1.Name = "cbAmPmLu1";
            this.cbAmPmLu1.Size = new System.Drawing.Size(43, 21);
            this.cbAmPmLu1.TabIndex = 15;
            this.cbAmPmLu1.ValueMember = "idAmPm";
            // 
            // nLuMin1
            // 
            this.nLuMin1.Location = new System.Drawing.Point(182, 41);
            this.nLuMin1.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nLuMin1.Name = "nLuMin1";
            this.nLuMin1.Size = new System.Drawing.Size(40, 20);
            this.nLuMin1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(167, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 24);
            this.label1.TabIndex = 13;
            this.label1.Text = ":";
            // 
            // nLuHor1
            // 
            this.nLuHor1.Location = new System.Drawing.Point(126, 41);
            this.nLuHor1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nLuHor1.Name = "nLuHor1";
            this.nLuHor1.Size = new System.Drawing.Size(40, 20);
            this.nLuHor1.TabIndex = 12;
            // 
            // chkDo
            // 
            this.chkDo.AutoSize = true;
            this.chkDo.Location = new System.Drawing.Point(14, 180);
            this.chkDo.Name = "chkDo";
            this.chkDo.Size = new System.Drawing.Size(68, 17);
            this.chkDo.TabIndex = 11;
            this.chkDo.Text = "Domingo";
            this.chkDo.UseVisualStyleBackColor = true;
            // 
            // chkSa
            // 
            this.chkSa.AutoSize = true;
            this.chkSa.Location = new System.Drawing.Point(14, 157);
            this.chkSa.Name = "chkSa";
            this.chkSa.Size = new System.Drawing.Size(63, 17);
            this.chkSa.TabIndex = 10;
            this.chkSa.Text = "Sabado";
            this.chkSa.UseVisualStyleBackColor = true;
            // 
            // chkVi
            // 
            this.chkVi.AutoSize = true;
            this.chkVi.Location = new System.Drawing.Point(14, 134);
            this.chkVi.Name = "chkVi";
            this.chkVi.Size = new System.Drawing.Size(61, 17);
            this.chkVi.TabIndex = 9;
            this.chkVi.Text = "Viernes";
            this.chkVi.UseVisualStyleBackColor = true;
            // 
            // chkMi
            // 
            this.chkMi.AutoSize = true;
            this.chkMi.Location = new System.Drawing.Point(14, 88);
            this.chkMi.Name = "chkMi";
            this.chkMi.Size = new System.Drawing.Size(71, 17);
            this.chkMi.TabIndex = 7;
            this.chkMi.Text = "Miercoles";
            this.chkMi.UseVisualStyleBackColor = true;
            // 
            // chkMa
            // 
            this.chkMa.AutoSize = true;
            this.chkMa.Location = new System.Drawing.Point(14, 65);
            this.chkMa.Name = "chkMa";
            this.chkMa.Size = new System.Drawing.Size(58, 17);
            this.chkMa.TabIndex = 6;
            this.chkMa.Text = "Martes";
            this.chkMa.UseVisualStyleBackColor = true;
            // 
            // chkLu
            // 
            this.chkLu.AutoSize = true;
            this.chkLu.Location = new System.Drawing.Point(14, 42);
            this.chkLu.Name = "chkLu";
            this.chkLu.Size = new System.Drawing.Size(55, 17);
            this.chkLu.TabIndex = 5;
            this.chkLu.Text = "Lunes";
            this.chkLu.UseVisualStyleBackColor = true;
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAll.Location = new System.Drawing.Point(13, 19);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(61, 17);
            this.chkAll.TabIndex = 4;
            this.chkAll.Text = "Todos";
            this.chkAll.UseVisualStyleBackColor = true;
            // 
            // btnAsignar
            // 
            this.btnAsignar.Location = new System.Drawing.Point(417, 418);
            this.btnAsignar.Name = "btnAsignar";
            this.btnAsignar.Size = new System.Drawing.Size(90, 26);
            this.btnAsignar.TabIndex = 151;
            this.btnAsignar.Text = "Asignar";
            this.btnAsignar.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBoxBuscar);
            this.groupBox3.Controls.Add(this.lblF2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtNombres);
            this.groupBox3.Controls.Add(this.txtNroDocIden);
            this.groupBox3.Controls.Add(this.txtDocIdent);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtCodigoInterno);
            this.groupBox3.Location = new System.Drawing.Point(8, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(499, 97);
            this.groupBox3.TabIndex = 152;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Trabajador";
            // 
            // lblF2
            // 
            this.lblF2.AutoSize = true;
            this.lblF2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF2.Location = new System.Drawing.Point(248, 21);
            this.lblF2.Name = "lblF2";
            this.lblF2.Size = new System.Drawing.Size(21, 13);
            this.lblF2.TabIndex = 54;
            this.lblF2.Text = "F2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Documento de Identidad :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Apellidos y Nombres :";
            // 
            // txtNombres
            // 
            this.txtNombres.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtNombres.Enabled = false;
            this.txtNombres.Location = new System.Drawing.Point(145, 41);
            this.txtNombres.Name = "txtNombres";
            this.txtNombres.Size = new System.Drawing.Size(345, 20);
            this.txtNombres.TabIndex = 1;
            // 
            // txtNroDocIden
            // 
            this.txtNroDocIden.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtNroDocIden.Enabled = false;
            this.txtNroDocIden.Location = new System.Drawing.Point(251, 65);
            this.txtNroDocIden.Name = "txtNroDocIden";
            this.txtNroDocIden.Size = new System.Drawing.Size(239, 20);
            this.txtNroDocIden.TabIndex = 3;
            // 
            // txtDocIdent
            // 
            this.txtDocIdent.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtDocIdent.Enabled = false;
            this.txtDocIdent.Location = new System.Drawing.Point(145, 65);
            this.txtDocIdent.Name = "txtDocIdent";
            this.txtDocIdent.Size = new System.Drawing.Size(100, 20);
            this.txtDocIdent.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Código Interno :";
            // 
            // txtCodigoInterno
            // 
            this.txtCodigoInterno.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCodigoInterno.Location = new System.Drawing.Point(145, 17);
            this.txtCodigoInterno.MaxLength = 5;
            this.txtCodigoInterno.Name = "txtCodigoInterno";
            this.txtCodigoInterno.ReadOnly = true;
            this.txtCodigoInterno.Size = new System.Drawing.Size(100, 20);
            this.txtCodigoInterno.TabIndex = 0;
            // 
            // pictureBoxBuscar
            // 
            this.pictureBoxBuscar.Image = global::CaniaBrava.Properties.Resources.LOCATE;
            this.pictureBoxBuscar.Location = new System.Drawing.Point(270, 17);
            this.pictureBoxBuscar.Name = "pictureBoxBuscar";
            this.pictureBoxBuscar.Size = new System.Drawing.Size(24, 21);
            this.pictureBoxBuscar.TabIndex = 55;
            this.pictureBoxBuscar.TabStop = false;
            // 
            // ui_asgHorPer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 455);
            this.Controls.Add(this.txtIdAsigHor);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAsignar);
            this.Controls.Add(this.groupBox3);
            this.MaximumSize = new System.Drawing.Size(523, 482);
            this.MinimumSize = new System.Drawing.Size(523, 482);
            this.Name = "ui_asgHorPer";
            this.Text = "ui_asgHorPer";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nDoMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nDoHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nDoMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nDoHor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSaHor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nViHor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nJuHor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMiHor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nMaHor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuMin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuHor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuMin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nLuHor1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuscar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIdAsigHor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dTimeFecFin;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker dTimeFecInicio;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cbAmPmDo2;
        private System.Windows.Forms.ComboBox cbAmPmSa2;
        private System.Windows.Forms.ComboBox cbAmPmVi2;
        private System.Windows.Forms.ComboBox cbAmPmJu2;
        private System.Windows.Forms.ComboBox cbAmPmMi2;
        private System.Windows.Forms.ComboBox cbAmPmMa2;
        private System.Windows.Forms.ComboBox cbAmPmLu2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown nDoMin2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nDoHor2;
        private System.Windows.Forms.ComboBox cbAmPmDo1;
        private System.Windows.Forms.NumericUpDown nDoMin1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nDoHor1;
        private System.Windows.Forms.NumericUpDown nSaMin2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown nSaHor2;
        private System.Windows.Forms.ComboBox cbAmPmSa1;
        private System.Windows.Forms.NumericUpDown nSaMin1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown nSaHor1;
        private System.Windows.Forms.NumericUpDown nViMin2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown nViHor2;
        private System.Windows.Forms.ComboBox cbAmPmVi1;
        private System.Windows.Forms.NumericUpDown nViMin1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown nViHor1;
        private System.Windows.Forms.NumericUpDown nJuMin2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nJuHor2;
        private System.Windows.Forms.ComboBox cbAmPmJu1;
        private System.Windows.Forms.NumericUpDown nJuMin1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nJuHor1;
        private System.Windows.Forms.NumericUpDown nMiMin2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nMiHor2;
        private System.Windows.Forms.ComboBox cbAmPmMi1;
        private System.Windows.Forms.NumericUpDown nMiMin1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown nMiHor1;
        private System.Windows.Forms.NumericUpDown nMaMin2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nMaHor2;
        private System.Windows.Forms.ComboBox cbAmPmMa1;
        private System.Windows.Forms.NumericUpDown nMaMin1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nMaHor1;
        private System.Windows.Forms.NumericUpDown nLuMin2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nLuHor2;
        private System.Windows.Forms.CheckBox chkJu;
        private System.Windows.Forms.ComboBox cbAmPmLu1;
        private System.Windows.Forms.NumericUpDown nLuMin1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nLuHor1;
        private System.Windows.Forms.CheckBox chkDo;
        private System.Windows.Forms.CheckBox chkSa;
        private System.Windows.Forms.CheckBox chkVi;
        private System.Windows.Forms.CheckBox chkMi;
        private System.Windows.Forms.CheckBox chkMa;
        private System.Windows.Forms.CheckBox chkLu;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.Button btnAsignar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBoxBuscar;
        private System.Windows.Forms.Label lblF2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox txtNombres;
        public System.Windows.Forms.TextBox txtNroDocIden;
        public System.Windows.Forms.TextBox txtDocIdent;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox txtCodigoInterno;
    }
}