﻿namespace CaniaBrava
{
    partial class ui_pdtplame
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ui_pdtplame));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chkJorTrab = new System.Windows.Forms.CheckBox();
            this.chkIngTribDesc = new System.Windows.Forms.CheckBox();
            this.chkDiasSubsi = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbMes = new System.Windows.Forms.ComboBox();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.txtAnio = new System.Windows.Forms.MaskedTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbTipoPlan = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbTipoTrabajador = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkPeriodos = new System.Windows.Forms.CheckBox();
            this.chkDatosTrabajador = new System.Windows.Forms.CheckBox();
            this.chkTrabPen = new System.Windows.Forms.CheckBox();
            this.chkEmpDestacoPer = new System.Windows.Forms.CheckBox();
            this.chkEstPropios = new System.Windows.Forms.CheckBox();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.chkJorTrab);
            this.groupBox4.Controls.Add(this.chkIngTribDesc);
            this.groupBox4.Controls.Add(this.chkDiasSubsi);
            this.groupBox4.Location = new System.Drawing.Point(12, 335);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(653, 97);
            this.groupBox4.TabIndex = 109;
            this.groupBox4.TabStop = false;
            // 
            // chkJorTrab
            // 
            this.chkJorTrab.AutoSize = true;
            this.chkJorTrab.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkJorTrab.Location = new System.Drawing.Point(22, 19);
            this.chkJorTrab.Name = "chkJorTrab";
            this.chkJorTrab.Size = new System.Drawing.Size(226, 17);
            this.chkJorTrab.TabIndex = 99;
            this.chkJorTrab.Text = "Datos de la Jornada Laboral del trabajador";
            this.chkJorTrab.UseVisualStyleBackColor = true;
            // 
            // chkIngTribDesc
            // 
            this.chkIngTribDesc.AutoSize = true;
            this.chkIngTribDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIngTribDesc.Location = new System.Drawing.Point(22, 39);
            this.chkIngTribDesc.Name = "chkIngTribDesc";
            this.chkIngTribDesc.Size = new System.Drawing.Size(368, 17);
            this.chkIngTribDesc.TabIndex = 95;
            this.chkIngTribDesc.Text = "Datos del detalle de los Ingresos , Tributos y  Descuentos del Trabajador";
            this.chkIngTribDesc.UseVisualStyleBackColor = true;
            // 
            // chkDiasSubsi
            // 
            this.chkDiasSubsi.AutoSize = true;
            this.chkDiasSubsi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDiasSubsi.Location = new System.Drawing.Point(22, 62);
            this.chkDiasSubsi.Name = "chkDiasSubsi";
            this.chkDiasSubsi.Size = new System.Drawing.Size(278, 17);
            this.chkDiasSubsi.TabIndex = 100;
            this.chkDiasSubsi.Text = "Días Subsidiados y otros no laborados del Trabajador";
            this.chkDiasSubsi.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.cmbMes);
            this.groupBox3.Controls.Add(this.lblUsuario);
            this.groupBox3.Controls.Add(this.txtAnio);
            this.groupBox3.Location = new System.Drawing.Point(11, 101);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(654, 78);
            this.groupBox3.TabIndex = 106;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Periodo Tributario";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 103;
            this.label5.Text = "Mes :";
            // 
            // cmbMes
            // 
            this.cmbMes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMes.FormattingEnabled = true;
            this.cmbMes.Items.AddRange(new object[] {
            "01   ENERO",
            "02   FEBRERO",
            "03   MARZO",
            "04   ABRIL",
            "05   MAYO",
            "06   JUNIO",
            "07   JULIO",
            "08   AGOSTO",
            "09   SETIEMBRE",
            "10   OCTUBRE",
            "11   NOVIEMBRE",
            "12   DICIEMBRE",
            ""});
            this.cmbMes.Location = new System.Drawing.Point(92, 21);
            this.cmbMes.Name = "cmbMes";
            this.cmbMes.Size = new System.Drawing.Size(181, 21);
            this.cmbMes.TabIndex = 91;
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(6, 51);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(32, 13);
            this.lblUsuario.TabIndex = 96;
            this.lblUsuario.Text = "Año :";
            // 
            // txtAnio
            // 
            this.txtAnio.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAnio.Location = new System.Drawing.Point(92, 48);
            this.txtAnio.Mask = "9999";
            this.txtAnio.Name = "txtAnio";
            this.txtAnio.Size = new System.Drawing.Size(77, 20);
            this.txtAnio.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbTipoPlan);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cmbTipoTrabajador);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(366, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(299, 74);
            this.groupBox1.TabIndex = 105;
            this.groupBox1.TabStop = false;
            // 
            // cmbTipoPlan
            // 
            this.cmbTipoPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoPlan.FormattingEnabled = true;
            this.cmbTipoPlan.Location = new System.Drawing.Point(108, 42);
            this.cmbTipoPlan.Name = "cmbTipoPlan";
            this.cmbTipoPlan.Size = new System.Drawing.Size(164, 21);
            this.cmbTipoPlan.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 90;
            this.label4.Text = "Tipo de Planilla  :";
            // 
            // cmbTipoTrabajador
            // 
            this.cmbTipoTrabajador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoTrabajador.FormattingEnabled = true;
            this.cmbTipoTrabajador.Location = new System.Drawing.Point(108, 14);
            this.cmbTipoTrabajador.Name = "cmbTipoTrabajador";
            this.cmbTipoTrabajador.Size = new System.Drawing.Size(164, 21);
            this.cmbTipoTrabajador.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 88;
            this.label3.Text = "Tipo de Personal  :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(22, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 57);
            this.pictureBox1.TabIndex = 104;
            this.pictureBox1.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.toolStripSeparator1,
            this.toolStripButton1});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 476);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.ShowItemToolTips = false;
            this.toolStrip1.Size = new System.Drawing.Size(723, 29);
            this.toolStrip1.TabIndex = 110;
            // 
            // btnNuevo
            // 
            this.btnNuevo.Image = global::CaniaBrava.Properties.Resources.FILE;
            this.btnNuevo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(82, 26);
            this.btnNuevo.Text = "Exportar";
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click_1);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 29);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::CaniaBrava.Properties.Resources.CLOSE;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(49, 26);
            this.toolStripButton1.Text = "Salir";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(18, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 24);
            this.label1.TabIndex = 91;
            this.label1.Text = "PDT Planilla Electrónica PLAME";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkPeriodos);
            this.groupBox2.Controls.Add(this.chkDatosTrabajador);
            this.groupBox2.Controls.Add(this.chkTrabPen);
            this.groupBox2.Controls.Add(this.chkEmpDestacoPer);
            this.groupBox2.Controls.Add(this.chkEstPropios);
            this.groupBox2.Location = new System.Drawing.Point(11, 185);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(654, 144);
            this.groupBox2.TabIndex = 110;
            this.groupBox2.TabStop = false;
            // 
            // chkPeriodos
            // 
            this.chkPeriodos.AutoSize = true;
            this.chkPeriodos.Location = new System.Drawing.Point(23, 112);
            this.chkPeriodos.Name = "chkPeriodos";
            this.chkPeriodos.Size = new System.Drawing.Size(113, 17);
            this.chkPeriodos.TabIndex = 111;
            this.chkPeriodos.Text = "Datos de Periodos";
            this.chkPeriodos.UseVisualStyleBackColor = true;
            // 
            // chkDatosTrabajador
            // 
            this.chkDatosTrabajador.AutoSize = true;
            this.chkDatosTrabajador.Location = new System.Drawing.Point(23, 89);
            this.chkDatosTrabajador.Name = "chkDatosTrabajador";
            this.chkDatosTrabajador.Size = new System.Drawing.Size(125, 17);
            this.chkDatosTrabajador.TabIndex = 111;
            this.chkDatosTrabajador.Text = "Datos del Trabajador";
            this.chkDatosTrabajador.UseVisualStyleBackColor = true;
            // 
            // chkTrabPen
            // 
            this.chkTrabPen.AutoSize = true;
            this.chkTrabPen.Location = new System.Drawing.Point(23, 66);
            this.chkTrabPen.Name = "chkTrabPen";
            this.chkTrabPen.Size = new System.Drawing.Size(588, 17);
            this.chkTrabPen.TabIndex = 111;
            this.chkTrabPen.Text = "Datos personales del trabajador, pensionista, personal en formación - modalidad f" +
                "ormativa laboral y personal de terceros";
            this.chkTrabPen.UseVisualStyleBackColor = true;
            // 
            // chkEmpDestacoPer
            // 
            this.chkEmpDestacoPer.AutoSize = true;
            this.chkEmpDestacoPer.Location = new System.Drawing.Point(23, 42);
            this.chkEmpDestacoPer.Name = "chkEmpDestacoPer";
            this.chkEmpDestacoPer.Size = new System.Drawing.Size(274, 17);
            this.chkEmpDestacoPer.TabIndex = 111;
            this.chkEmpDestacoPer.Text = "Empleadores a quienes destaco o desplazo personal";
            this.chkEmpDestacoPer.UseVisualStyleBackColor = true;
            // 
            // chkEstPropios
            // 
            this.chkEstPropios.AutoSize = true;
            this.chkEstPropios.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEstPropios.Location = new System.Drawing.Point(23, 19);
            this.chkEstPropios.Name = "chkEstPropios";
            this.chkEstPropios.Size = new System.Drawing.Size(213, 17);
            this.chkEstPropios.TabIndex = 101;
            this.chkEstPropios.Text = "Establecimientos Propios del Empleador";
            this.chkEstPropios.UseVisualStyleBackColor = true;
            // 
            // ui_pdtplame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(723, 505);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "ui_pdtplame";
            this.Text = "PDT Planilla Electrónica PLAME - SUNAT";
            this.Load += new System.EventHandler(this.ui_pdtplame_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox chkJorTrab;
        private System.Windows.Forms.CheckBox chkIngTribDesc;
        private System.Windows.Forms.CheckBox chkDiasSubsi;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbMes;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.MaskedTextBox txtAnio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbTipoPlan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbTipoTrabajador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkEstPropios;
        private System.Windows.Forms.CheckBox chkEmpDestacoPer;
        private System.Windows.Forms.CheckBox chkTrabPen;
        private System.Windows.Forms.CheckBox chkDatosTrabajador;
        private System.Windows.Forms.CheckBox chkPeriodos;
    }
}
