﻿namespace CaniaBrava
{
    partial class ui_mdiprincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuMDI = new System.Windows.Forms.MenuStrip();
            this.TAMA = new System.Windows.Forms.ToolStripMenuItem();
            this.TAMA01 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA02 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA05 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA06 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA07 = new System.Windows.Forms.ToolStripMenuItem();
            this.TAMA0701 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator37 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA0702 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator71 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA08 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator74 = new System.Windows.Forms.ToolStripSeparator();
            this.TAMA09 = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL01 = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL0101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0102 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator61 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0103 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL05 = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL0501 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator48 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0502 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator46 = new System.Windows.Forms.ToolStripSeparator();
            this.GO = new System.Windows.Forms.ToolStripMenuItem();
            this.GO01 = new System.Windows.Forms.ToolStripMenuItem();
            this.GO0101 = new System.Windows.Forms.ToolStripMenuItem();
            this.GO02 = new System.Windows.Forms.ToolStripMenuItem();
            this.GO0201 = new System.Windows.Forms.ToolStripMenuItem();
            this.GO03 = new System.Windows.Forms.ToolStripMenuItem();
            this.GO0301 = new System.Windows.Forms.ToolStripMenuItem();
            this.GI = new System.Windows.Forms.ToolStripMenuItem();
            this.GI01 = new System.Windows.Forms.ToolStripMenuItem();
            this.GI0101 = new System.Windows.Forms.ToolStripMenuItem();
            this.GFACI = new System.Windows.Forms.ToolStripMenuItem();
            this.GFACI01 = new System.Windows.Forms.ToolStripMenuItem();
            this.GFACI0101 = new System.Windows.Forms.ToolStripMenuItem();
            this.GFACI0102 = new System.Windows.Forms.ToolStripMenuItem();
            this.MaquetaDeGastos = new System.Windows.Forms.ToolStripMenuItem();
            this.GFACI0103 = new System.Windows.Forms.ToolStripMenuItem();
            this.GFACI0104 = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS01 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator81 = new System.Windows.Forms.ToolStripSeparator();
            this.GGHS02 = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS0201 = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS020101 = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS020102 = new System.Windows.Forms.ToolStripMenuItem();
            this.ATRAC_SELEC = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL09 = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL0901 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0902 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0903 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator64 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0904 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator76 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0905 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator87 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0906 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL0907 = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL10 = new System.Windows.Forms.ToolStripMenuItem();
            this.MAPL1001 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator77 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL1002 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator78 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL1003 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator79 = new System.Windows.Forms.ToolStripSeparator();
            this.MAPL1004 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator82 = new System.Windows.Forms.ToolStripSeparator();
            this.GGHS03 = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS0301 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator83 = new System.Windows.Forms.ToolStripSeparator();
            this.GGHS04 = new System.Windows.Forms.ToolStripMenuItem();
            this.GGHS0401 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator75 = new System.Windows.Forms.ToolStripSeparator();
            this.GGHS0402 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator84 = new System.Windows.Forms.ToolStripSeparator();
            this.GGHS05 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator85 = new System.Windows.Forms.ToolStripSeparator();
            this.GGHS06 = new System.Windows.Forms.ToolStripMenuItem();
            this.COMED = new System.Windows.Forms.ToolStripMenuItem();
            this.COMED01 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator69 = new System.Windows.Forms.ToolStripSeparator();
            this.COMED02 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator70 = new System.Windows.Forms.ToolStripSeparator();
            this.COMED03 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator68 = new System.Windows.Forms.ToolStripSeparator();
            this.COMED04 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator72 = new System.Windows.Forms.ToolStripSeparator();
            this.COMED05 = new System.Windows.Forms.ToolStripMenuItem();
            this.COMED0501 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator80 = new System.Windows.Forms.ToolStripSeparator();
            this.COMED0502 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator73 = new System.Windows.Forms.ToolStripSeparator();
            this.COMED06 = new System.Windows.Forms.ToolStripMenuItem();
            this.COMED0601 = new System.Windows.Forms.ToolStripMenuItem();
            this.COMED0602 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.PLATOS = new System.Windows.Forms.ToolStripMenuItem();
            this.UTIL = new System.Windows.Forms.ToolStripMenuItem();
            this.UTIL01 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.UTIL02 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.UTIL03 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator30 = new System.Windows.Forms.ToolStripSeparator();
            this.UTIL06 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator65 = new System.Windows.Forms.ToolStripSeparator();
            this.UTIL08 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.UTIL09 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator88 = new System.Windows.Forms.ToolStripSeparator();
            this.UTIL10 = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripForm = new System.Windows.Forms.ToolStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnSincronizar = new System.Windows.Forms.ToolStripButton();
            this.mTrabajadores = new System.Windows.Forms.ToolStripButton();
            this.mTipoHorarios = new System.Windows.Forms.ToolStripButton();
            this.btnProgramacion = new System.Windows.Forms.ToolStripButton();
            this.btnReporteAsis = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.loadingNext1 = new System.Windows.Forms.PictureBox();
            this.lblCargando = new System.Windows.Forms.Label();
            this.GI0102 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMDI.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loadingNext1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuMDI
            // 
            this.menuMDI.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuMDI.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuMDI.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TAMA,
            this.MAPL,
            this.GO,
            this.GI,
            this.GFACI,
            this.GGHS,
            this.COMED,
            this.UTIL,
            this.salirToolStripMenuItem});
            this.menuMDI.Location = new System.Drawing.Point(0, 0);
            this.menuMDI.Name = "menuMDI";
            this.menuMDI.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuMDI.Size = new System.Drawing.Size(1255, 28);
            this.menuMDI.TabIndex = 1;
            this.menuMDI.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuMDI_ItemClicked);
            // 
            // TAMA
            // 
            this.TAMA.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TAMA01,
            this.toolStripSeparator4,
            this.TAMA02,
            this.toolStripSeparator18,
            this.TAMA05,
            this.toolStripSeparator3,
            this.TAMA06,
            this.toolStripSeparator2,
            this.TAMA07,
            this.toolStripSeparator71,
            this.TAMA08,
            this.toolStripSeparator74,
            this.TAMA09});
            this.TAMA.Name = "TAMA";
            this.TAMA.Size = new System.Drawing.Size(125, 24);
            this.TAMA.Text = "&Tablas Maestras";
            // 
            // TAMA01
            // 
            this.TAMA01.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TAMA01.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TAMA01.Name = "TAMA01";
            this.TAMA01.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.TAMA01.Size = new System.Drawing.Size(280, 26);
            this.TAMA01.Text = "Maestros Comunes ";
            this.TAMA01.Click += new System.EventHandler(this.TAMA01_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(277, 6);
            this.toolStripSeparator4.Visible = false;
            // 
            // TAMA02
            // 
            this.TAMA02.Name = "TAMA02";
            this.TAMA02.Size = new System.Drawing.Size(280, 26);
            this.TAMA02.Text = "PDT- Planilla Electrónica";
            this.TAMA02.Visible = false;
            this.TAMA02.Click += new System.EventHandler(this.TAMA02_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(277, 6);
            this.toolStripSeparator18.Visible = false;
            // 
            // TAMA05
            // 
            this.TAMA05.Name = "TAMA05";
            this.TAMA05.Size = new System.Drawing.Size(280, 26);
            this.TAMA05.Text = "Centros de Costo";
            this.TAMA05.Visible = false;
            this.TAMA05.Click += new System.EventHandler(this.TAMA05_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(277, 6);
            this.toolStripSeparator3.Visible = false;
            // 
            // TAMA06
            // 
            this.TAMA06.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TAMA06.Name = "TAMA06";
            this.TAMA06.Size = new System.Drawing.Size(280, 26);
            this.TAMA06.Text = "Labores de Planilla";
            this.TAMA06.Visible = false;
            this.TAMA06.Click += new System.EventHandler(this.TAMA06_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(277, 6);
            this.toolStripSeparator2.Visible = false;
            // 
            // TAMA07
            // 
            this.TAMA07.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TAMA0701,
            this.toolStripSeparator37,
            this.TAMA0702});
            this.TAMA07.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TAMA07.Name = "TAMA07";
            this.TAMA07.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.TAMA07.Size = new System.Drawing.Size(280, 26);
            this.TAMA07.Text = "Calendario de Planilla";
            this.TAMA07.Visible = false;
            this.TAMA07.Click += new System.EventHandler(this.calendarioDePlanillaToolStripMenuItem_Click);
            // 
            // TAMA0701
            // 
            this.TAMA0701.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TAMA0701.Name = "TAMA0701";
            this.TAMA0701.Size = new System.Drawing.Size(259, 26);
            this.TAMA0701.Text = "Calendario de Planilla";
            this.TAMA0701.Click += new System.EventHandler(this.TAMA0701_Click);
            // 
            // toolStripSeparator37
            // 
            this.toolStripSeparator37.Name = "toolStripSeparator37";
            this.toolStripSeparator37.Size = new System.Drawing.Size(256, 6);
            // 
            // TAMA0702
            // 
            this.TAMA0702.Name = "TAMA0702";
            this.TAMA0702.Size = new System.Drawing.Size(259, 26);
            this.TAMA0702.Text = "Activar Periodos Laborales";
            this.TAMA0702.Click += new System.EventHandler(this.TAMA0702_Click);
            // 
            // toolStripSeparator71
            // 
            this.toolStripSeparator71.Name = "toolStripSeparator71";
            this.toolStripSeparator71.Size = new System.Drawing.Size(277, 6);
            // 
            // TAMA08
            // 
            this.TAMA08.Name = "TAMA08";
            this.TAMA08.Size = new System.Drawing.Size(280, 26);
            this.TAMA08.Text = "Comedores";
            this.TAMA08.Click += new System.EventHandler(this.TAMA08_Click);
            // 
            // toolStripSeparator74
            // 
            this.toolStripSeparator74.Name = "toolStripSeparator74";
            this.toolStripSeparator74.Size = new System.Drawing.Size(277, 6);
            // 
            // TAMA09
            // 
            this.TAMA09.Name = "TAMA09";
            this.TAMA09.Size = new System.Drawing.Size(280, 26);
            this.TAMA09.Text = "Grupos Familia Comedor";
            this.TAMA09.Click += new System.EventHandler(this.TAMA09_Click);
            // 
            // MAPL
            // 
            this.MAPL.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MAPL01,
            this.toolStripSeparator15,
            this.MAPL05,
            this.toolStripSeparator46});
            this.MAPL.Name = "MAPL";
            this.MAPL.Size = new System.Drawing.Size(162, 24);
            this.MAPL.Text = "Maestros del Sistema";
            this.MAPL.Click += new System.EventHandler(this.reportesToolStripMenuItem_Click);
            // 
            // MAPL01
            // 
            this.MAPL01.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MAPL0101,
            this.toolStripSeparator16,
            this.MAPL0102,
            this.toolStripSeparator61,
            this.MAPL0103});
            this.MAPL01.Name = "MAPL01";
            this.MAPL01.Size = new System.Drawing.Size(222, 26);
            this.MAPL01.Text = "Maestro del Personal";
            // 
            // MAPL0101
            // 
            this.MAPL0101.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MAPL0101.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MAPL0101.Name = "MAPL0101";
            this.MAPL0101.Size = new System.Drawing.Size(296, 26);
            this.MAPL0101.Text = "Información del Personal";
            this.MAPL0101.Click += new System.EventHandler(this.actualizaciónDelPersonalToolStripMenuItem_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(293, 6);
            this.toolStripSeparator16.Visible = false;
            this.toolStripSeparator16.Click += new System.EventHandler(this.toolStripSeparator16_Click);
            // 
            // MAPL0102
            // 
            this.MAPL0102.Name = "MAPL0102";
            this.MAPL0102.Size = new System.Drawing.Size(296, 26);
            this.MAPL0102.Text = "Descuentos Judiciales";
            this.MAPL0102.Visible = false;
            this.MAPL0102.Click += new System.EventHandler(this.descuentosJudicialesToolStripMenuItem1_Click);
            // 
            // toolStripSeparator61
            // 
            this.toolStripSeparator61.Name = "toolStripSeparator61";
            this.toolStripSeparator61.Size = new System.Drawing.Size(293, 6);
            this.toolStripSeparator61.Visible = false;
            // 
            // MAPL0103
            // 
            this.MAPL0103.Name = "MAPL0103";
            this.MAPL0103.Size = new System.Drawing.Size(296, 26);
            this.MAPL0103.Text = "Reporte de Maestro de Personal";
            this.MAPL0103.Visible = false;
            this.MAPL0103.Click += new System.EventHandler(this.reporteDelPersonalToolStripMenuItem_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(219, 6);
            this.toolStripSeparator15.Visible = false;
            // 
            // MAPL05
            // 
            this.MAPL05.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MAPL0501,
            this.toolStripSeparator48,
            this.MAPL0502});
            this.MAPL05.Name = "MAPL05";
            this.MAPL05.Size = new System.Drawing.Size(222, 26);
            this.MAPL05.Text = "Registro Vacacional";
            this.MAPL05.Visible = false;
            this.MAPL05.Click += new System.EventHandler(this.toolStripMenuItem12_Click_1);
            // 
            // MAPL0501
            // 
            this.MAPL0501.Name = "MAPL0501";
            this.MAPL0501.Size = new System.Drawing.Size(238, 26);
            this.MAPL0501.Text = "Registro de Vacaciones";
            this.MAPL0501.Click += new System.EventHandler(this.registroDeVacacionesToolStripMenuItem_Click);
            // 
            // toolStripSeparator48
            // 
            this.toolStripSeparator48.Name = "toolStripSeparator48";
            this.toolStripSeparator48.Size = new System.Drawing.Size(235, 6);
            // 
            // MAPL0502
            // 
            this.MAPL0502.Name = "MAPL0502";
            this.MAPL0502.Size = new System.Drawing.Size(238, 26);
            this.MAPL0502.Text = "Historial de Vacaciones";
            this.MAPL0502.Click += new System.EventHandler(this.historialDeVacacionesToolStripMenuItem_Click);
            // 
            // toolStripSeparator46
            // 
            this.toolStripSeparator46.Name = "toolStripSeparator46";
            this.toolStripSeparator46.Size = new System.Drawing.Size(219, 6);
            this.toolStripSeparator46.Visible = false;
            // 
            // GO
            // 
            this.GO.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GO01,
            this.GO02,
            this.GO03});
            this.GO.Name = "GO";
            this.GO.Size = new System.Drawing.Size(117, 24);
            this.GO.Text = "G.Operaciones";
            // 
            // GO01
            // 
            this.GO01.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GO0101});
            this.GO01.Name = "GO01";
            this.GO01.Size = new System.Drawing.Size(154, 26);
            this.GO01.Text = "Ventas";
            // 
            // GO0101
            // 
            this.GO0101.Name = "GO0101";
            this.GO0101.Size = new System.Drawing.Size(151, 26);
            this.GO0101.Text = "PB vs Real";
            this.GO0101.Click += new System.EventHandler(this.GO0101_Click);
            // 
            // GO02
            // 
            this.GO02.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GO0201});
            this.GO02.Name = "GO02";
            this.GO02.Size = new System.Drawing.Size(154, 26);
            this.GO02.Text = "Cosecha";
            // 
            // GO0201
            // 
            this.GO0201.Name = "GO0201";
            this.GO0201.Size = new System.Drawing.Size(184, 26);
            this.GO0201.Text = "Datos OEE CAT";
            this.GO0201.Click += new System.EventHandler(this.GO0201_Click);
            // 
            // GO03
            // 
            this.GO03.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GO0301});
            this.GO03.Name = "GO03";
            this.GO03.Size = new System.Drawing.Size(154, 26);
            this.GO03.Text = "Transporte";
            // 
            // GO0301
            // 
            this.GO0301.Name = "GO0301";
            this.GO0301.Size = new System.Drawing.Size(225, 26);
            this.GO0301.Text = "Checklist Neumaticos";
            this.GO0301.Click += new System.EventHandler(this.GO0301_Click);
            // 
            // GI
            // 
            this.GI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GI01});
            this.GI.Name = "GI";
            this.GI.Size = new System.Drawing.Size(99, 24);
            this.GI.Text = "G. Industrial";
            // 
            // GI01
            // 
            this.GI01.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GI0101,
            this.GI0102});
            this.GI01.Name = "GI01";
            this.GI01.Size = new System.Drawing.Size(216, 26);
            this.GI01.Text = "Produccion";
            // 
            // GI0101
            // 
            this.GI0101.Name = "GI0101";
            this.GI0101.Size = new System.Drawing.Size(248, 26);
            this.GI0101.Text = "Datos Rendimiento";
            this.GI0101.Click += new System.EventHandler(this.GI0101_Click);
            // 
            // GFACI
            // 
            this.GFACI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GFACI01});
            this.GFACI.Name = "GFACI";
            this.GFACI.Size = new System.Drawing.Size(91, 24);
            this.GFACI.Text = "G.F.A. y C.I.";
            // 
            // GFACI01
            // 
            this.GFACI01.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GFACI0101,
            this.GFACI0102,
            this.MaquetaDeGastos});
            this.GFACI01.Name = "GFACI01";
            this.GFACI01.Size = new System.Drawing.Size(170, 26);
            this.GFACI01.Text = "Contabilidad";
            // 
            // GFACI0101
            // 
            this.GFACI0101.Name = "GFACI0101";
            this.GFACI0101.Size = new System.Drawing.Size(219, 26);
            this.GFACI0101.Text = "Registro PB y PY";
            this.GFACI0101.Click += new System.EventHandler(this.GFACI0101_Click);
            // 
            // GFACI0102
            // 
            this.GFACI0102.Name = "GFACI0102";
            this.GFACI0102.Size = new System.Drawing.Size(219, 26);
            this.GFACI0102.Text = "Maestro Actividades";
            this.GFACI0102.Click += new System.EventHandler(this.GFACI0102_Click);
            // 
            // MaquetaDeGastos
            // 
            this.MaquetaDeGastos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GFACI0103,
            this.GFACI0104});
            this.MaquetaDeGastos.Name = "MaquetaDeGastos";
            this.MaquetaDeGastos.Size = new System.Drawing.Size(219, 26);
            this.MaquetaDeGastos.Text = "Maqueta de Gastos";
            // 
            // GFACI0103
            // 
            this.GFACI0103.Name = "GFACI0103";
            this.GFACI0103.Size = new System.Drawing.Size(227, 26);
            this.GFACI0103.Text = "Registro PB, PY y Real";
            this.GFACI0103.Click += new System.EventHandler(this.GFACI0103_Click);
            // 
            // GFACI0104
            // 
            this.GFACI0104.Name = "GFACI0104";
            this.GFACI0104.Size = new System.Drawing.Size(227, 26);
            this.GFACI0104.Text = "Maestros";
            this.GFACI0104.Click += new System.EventHandler(this.GFACI0104_Click);
            // 
            // GGHS
            // 
            this.GGHS.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GGHS01,
            this.toolStripSeparator81,
            this.GGHS02,
            this.toolStripSeparator82,
            this.GGHS03,
            this.toolStripSeparator83,
            this.GGHS04,
            this.toolStripSeparator84,
            this.GGHS05,
            this.toolStripSeparator85,
            this.GGHS06});
            this.GGHS.Name = "GGHS";
            this.GGHS.Size = new System.Drawing.Size(87, 24);
            this.GGHS.Text = "G.G.H. y S.";
            // 
            // GGHS01
            // 
            this.GGHS01.Name = "GGHS01";
            this.GGHS01.Size = new System.Drawing.Size(304, 26);
            this.GGHS01.Text = "Sostenibilidad";
            this.GGHS01.Visible = false;
            // 
            // toolStripSeparator81
            // 
            this.toolStripSeparator81.Name = "toolStripSeparator81";
            this.toolStripSeparator81.Size = new System.Drawing.Size(301, 6);
            this.toolStripSeparator81.Visible = false;
            // 
            // GGHS02
            // 
            this.GGHS02.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GGHS0201,
            this.MAPL09,
            this.MAPL10});
            this.GGHS02.Name = "GGHS02";
            this.GGHS02.Size = new System.Drawing.Size(304, 26);
            this.GGHS02.Text = "Gestion del Talento";
            // 
            // GGHS0201
            // 
            this.GGHS0201.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GGHS020101,
            this.GGHS020102,
            this.ATRAC_SELEC});
            this.GGHS0201.Name = "GGHS0201";
            this.GGHS0201.Size = new System.Drawing.Size(224, 26);
            this.GGHS0201.Text = "Capacitaciones";
            // 
            // GGHS020101
            // 
            this.GGHS020101.Name = "GGHS020101";
            this.GGHS020101.Size = new System.Drawing.Size(358, 26);
            this.GGHS020101.Text = "Programacion de Capacitaciones Internas";
            this.GGHS020101.Click += new System.EventHandler(this.GGHS020101_Click);
            // 
            // GGHS020102
            // 
            this.GGHS020102.Name = "GGHS020102";
            this.GGHS020102.Size = new System.Drawing.Size(358, 26);
            this.GGHS020102.Text = "Solicitud de Capacitaciones Externas";
            this.GGHS020102.Click += new System.EventHandler(this.GGHS020102_Click);
            // 
            // ATRAC_SELEC
            // 
            this.ATRAC_SELEC.Name = "ATRAC_SELEC";
            this.ATRAC_SELEC.Size = new System.Drawing.Size(358, 26);
            this.ATRAC_SELEC.Text = "Atracciòn y Selecciòn";
            this.ATRAC_SELEC.Click += new System.EventHandler(this.ATRAC_SELEC_Click);
            // 
            // MAPL09
            // 
            this.MAPL09.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MAPL0901,
            this.toolStripSeparator22,
            this.MAPL0902,
            this.toolStripSeparator23,
            this.MAPL0903,
            this.toolStripSeparator64,
            this.MAPL0904,
            this.toolStripSeparator76,
            this.MAPL0905,
            this.toolStripSeparator87,
            this.MAPL0906,
            this.toolStripSeparator21,
            this.MAPL0907});
            this.MAPL09.Name = "MAPL09";
            this.MAPL09.Size = new System.Drawing.Size(224, 26);
            this.MAPL09.Text = "Control de Asistencia";
            // 
            // MAPL0901
            // 
            this.MAPL0901.Name = "MAPL0901";
            this.MAPL0901.Size = new System.Drawing.Size(502, 26);
            this.MAPL0901.Text = "Control Diario de Asistencia";
            this.MAPL0901.Visible = false;
            this.MAPL0901.Click += new System.EventHandler(this.btnReporteAsis_Click);
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(499, 6);
            this.toolStripSeparator22.Visible = false;
            // 
            // MAPL0902
            // 
            this.MAPL0902.Name = "MAPL0902";
            this.MAPL0902.Size = new System.Drawing.Size(502, 26);
            this.MAPL0902.Text = "Transferencia de Información- Control Diario a Parte de Planilla";
            this.MAPL0902.Visible = false;
            this.MAPL0902.Click += new System.EventHandler(this.transferenciaDeInformaciónControlDiarioAParteDePlanillaToolStripMenuItem_Click);
            // 
            // toolStripSeparator23
            // 
            this.toolStripSeparator23.Name = "toolStripSeparator23";
            this.toolStripSeparator23.Size = new System.Drawing.Size(499, 6);
            this.toolStripSeparator23.Visible = false;
            // 
            // MAPL0903
            // 
            this.MAPL0903.Name = "MAPL0903";
            this.MAPL0903.Size = new System.Drawing.Size(502, 26);
            this.MAPL0903.Text = "Tipos de Horarios Asistencia";
            this.MAPL0903.Click += new System.EventHandler(this.mTipoHorarios_Click);
            // 
            // toolStripSeparator64
            // 
            this.toolStripSeparator64.Name = "toolStripSeparator64";
            this.toolStripSeparator64.Size = new System.Drawing.Size(499, 6);
            // 
            // MAPL0904
            // 
            this.MAPL0904.Name = "MAPL0904";
            this.MAPL0904.Size = new System.Drawing.Size(502, 26);
            this.MAPL0904.Text = "Reporte de Asistencias";
            this.MAPL0904.Click += new System.EventHandler(this.MAPL0904_Click);
            // 
            // toolStripSeparator76
            // 
            this.toolStripSeparator76.Name = "toolStripSeparator76";
            this.toolStripSeparator76.Size = new System.Drawing.Size(499, 6);
            // 
            // MAPL0905
            // 
            this.MAPL0905.Name = "MAPL0905";
            this.MAPL0905.Size = new System.Drawing.Size(502, 26);
            this.MAPL0905.Text = "Reporte para SUNAFIL";
            this.MAPL0905.Click += new System.EventHandler(this.MAPL0905_Click);
            // 
            // toolStripSeparator87
            // 
            this.toolStripSeparator87.Name = "toolStripSeparator87";
            this.toolStripSeparator87.Size = new System.Drawing.Size(499, 6);
            // 
            // MAPL0906
            // 
            this.MAPL0906.Name = "MAPL0906";
            this.MAPL0906.Size = new System.Drawing.Size(502, 26);
            this.MAPL0906.Text = "Reporte Asistencias vs Tareos";
            this.MAPL0906.Click += new System.EventHandler(this.MAPL0906_Click);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(499, 6);
            // 
            // MAPL0907
            // 
            this.MAPL0907.Name = "MAPL0907";
            this.MAPL0907.Size = new System.Drawing.Size(502, 26);
            this.MAPL0907.Text = "Reporte de personal ausente";
            this.MAPL0907.Click += new System.EventHandler(this.MAPL0907_Click);
            // 
            // MAPL10
            // 
            this.MAPL10.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MAPL1001,
            this.toolStripSeparator77,
            this.MAPL1002,
            this.toolStripSeparator78,
            this.MAPL1003,
            this.toolStripSeparator79,
            this.MAPL1004});
            this.MAPL10.Name = "MAPL10";
            this.MAPL10.Size = new System.Drawing.Size(224, 26);
            this.MAPL10.Text = "Programaciones";
            this.MAPL10.ToolTipText = "Lista de Programaciones";
            // 
            // MAPL1001
            // 
            this.MAPL1001.Name = "MAPL1001";
            this.MAPL1001.Size = new System.Drawing.Size(445, 26);
            this.MAPL1001.Text = "Programaciones de Horarios o Actividades";
            this.MAPL1001.Click += new System.EventHandler(this.MAPL1001_Click);
            // 
            // toolStripSeparator77
            // 
            this.toolStripSeparator77.Name = "toolStripSeparator77";
            this.toolStripSeparator77.Size = new System.Drawing.Size(442, 6);
            // 
            // MAPL1002
            // 
            this.MAPL1002.Name = "MAPL1002";
            this.MAPL1002.Size = new System.Drawing.Size(445, 26);
            this.MAPL1002.Text = "Reprogramaciones de Horarios x Trabajador";
            this.MAPL1002.Visible = false;
            this.MAPL1002.Click += new System.EventHandler(this.MAPL1002_Click);
            // 
            // toolStripSeparator78
            // 
            this.toolStripSeparator78.Name = "toolStripSeparator78";
            this.toolStripSeparator78.Size = new System.Drawing.Size(442, 6);
            this.toolStripSeparator78.Visible = false;
            // 
            // MAPL1003
            // 
            this.MAPL1003.Name = "MAPL1003";
            this.MAPL1003.Size = new System.Drawing.Size(445, 26);
            this.MAPL1003.Text = "Control de Asistencia Manual de Trabajadores";
            this.MAPL1003.Click += new System.EventHandler(this.MAPL1003_Click);
            // 
            // toolStripSeparator79
            // 
            this.toolStripSeparator79.Name = "toolStripSeparator79";
            this.toolStripSeparator79.Size = new System.Drawing.Size(442, 6);
            // 
            // MAPL1004
            // 
            this.MAPL1004.Name = "MAPL1004";
            this.MAPL1004.Size = new System.Drawing.Size(445, 26);
            this.MAPL1004.Text = "Agrupamiento de Trabajadores para Prog. de Horarios";
            this.MAPL1004.Click += new System.EventHandler(this.MAPL1004_Click);
            // 
            // toolStripSeparator82
            // 
            this.toolStripSeparator82.Name = "toolStripSeparator82";
            this.toolStripSeparator82.Size = new System.Drawing.Size(301, 6);
            // 
            // GGHS03
            // 
            this.GGHS03.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GGHS0301});
            this.GGHS03.Name = "GGHS03";
            this.GGHS03.Size = new System.Drawing.Size(304, 26);
            this.GGHS03.Text = "Gestion Humana y Sostenibilidad";
            // 
            // GGHS0301
            // 
            this.GGHS0301.Name = "GGHS0301";
            this.GGHS0301.Size = new System.Drawing.Size(304, 26);
            this.GGHS0301.Text = "Planner de Gest. y C. Presupuestal";
            this.GGHS0301.Click += new System.EventHandler(this.GGHS0301_Click);
            // 
            // toolStripSeparator83
            // 
            this.toolStripSeparator83.Name = "toolStripSeparator83";
            this.toolStripSeparator83.Size = new System.Drawing.Size(301, 6);
            // 
            // GGHS04
            // 
            this.GGHS04.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GGHS0401,
            this.toolStripSeparator75,
            this.GGHS0402});
            this.GGHS04.Name = "GGHS04";
            this.GGHS04.Size = new System.Drawing.Size(304, 26);
            this.GGHS04.Text = "Bienestar del Trabajador";
            // 
            // GGHS0401
            // 
            this.GGHS0401.Name = "GGHS0401";
            this.GGHS0401.Size = new System.Drawing.Size(363, 26);
            this.GGHS0401.Text = "Registro de Descansos Medicos";
            this.GGHS0401.Click += new System.EventHandler(this.GGHS0401_Click);
            // 
            // toolStripSeparator75
            // 
            this.toolStripSeparator75.Name = "toolStripSeparator75";
            this.toolStripSeparator75.Size = new System.Drawing.Size(360, 6);
            // 
            // GGHS0402
            // 
            this.GGHS0402.Name = "GGHS0402";
            this.GGHS0402.Size = new System.Drawing.Size(363, 26);
            this.GGHS0402.Text = "Historial de Desc. Medicos por Trabajador";
            this.GGHS0402.Click += new System.EventHandler(this.GGHS0402_Click);
            // 
            // toolStripSeparator84
            // 
            this.toolStripSeparator84.Name = "toolStripSeparator84";
            this.toolStripSeparator84.Size = new System.Drawing.Size(301, 6);
            // 
            // GGHS05
            // 
            this.GGHS05.Name = "GGHS05";
            this.GGHS05.Size = new System.Drawing.Size(304, 26);
            this.GGHS05.Text = "Compensaciones y Nominas";
            this.GGHS05.Visible = false;
            // 
            // toolStripSeparator85
            // 
            this.toolStripSeparator85.Name = "toolStripSeparator85";
            this.toolStripSeparator85.Size = new System.Drawing.Size(301, 6);
            this.toolStripSeparator85.Visible = false;
            // 
            // GGHS06
            // 
            this.GGHS06.Name = "GGHS06";
            this.GGHS06.Size = new System.Drawing.Size(304, 26);
            this.GGHS06.Text = "Relaciones Laborales";
            this.GGHS06.Visible = false;
            // 
            // COMED
            // 
            this.COMED.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.COMED01,
            this.toolStripSeparator69,
            this.COMED02,
            this.toolStripSeparator70,
            this.COMED03,
            this.toolStripSeparator68,
            this.COMED04,
            this.toolStripSeparator72,
            this.COMED05,
            this.toolStripSeparator73,
            this.COMED06,
            this.toolStripSeparator1,
            this.PLATOS});
            this.COMED.Name = "COMED";
            this.COMED.Size = new System.Drawing.Size(97, 24);
            this.COMED.Text = "Comedores";
            // 
            // COMED01
            // 
            this.COMED01.Name = "COMED01";
            this.COMED01.Size = new System.Drawing.Size(289, 26);
            this.COMED01.Text = "Registro de Proveedores";
            this.COMED01.Click += new System.EventHandler(this.COMED01_Click);
            // 
            // toolStripSeparator69
            // 
            this.toolStripSeparator69.Name = "toolStripSeparator69";
            this.toolStripSeparator69.Size = new System.Drawing.Size(286, 6);
            // 
            // COMED02
            // 
            this.COMED02.Name = "COMED02";
            this.COMED02.Size = new System.Drawing.Size(289, 26);
            this.COMED02.Text = "Registro de Insumos";
            this.COMED02.Click += new System.EventHandler(this.COMED02_Click);
            // 
            // toolStripSeparator70
            // 
            this.toolStripSeparator70.Name = "toolStripSeparator70";
            this.toolStripSeparator70.Size = new System.Drawing.Size(286, 6);
            // 
            // COMED03
            // 
            this.COMED03.Name = "COMED03";
            this.COMED03.Size = new System.Drawing.Size(289, 26);
            this.COMED03.Text = "Pedido de Insumos";
            this.COMED03.Click += new System.EventHandler(this.COMED03_Click);
            // 
            // toolStripSeparator68
            // 
            this.toolStripSeparator68.Name = "toolStripSeparator68";
            this.toolStripSeparator68.Size = new System.Drawing.Size(286, 6);
            // 
            // COMED04
            // 
            this.COMED04.Name = "COMED04";
            this.COMED04.Size = new System.Drawing.Size(289, 26);
            this.COMED04.Text = "Ingreso y Consumo de Insumos";
            this.COMED04.Click += new System.EventHandler(this.COMED04_Click);
            // 
            // toolStripSeparator72
            // 
            this.toolStripSeparator72.Name = "toolStripSeparator72";
            this.toolStripSeparator72.Size = new System.Drawing.Size(286, 6);
            // 
            // COMED05
            // 
            this.COMED05.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.COMED0501,
            this.toolStripSeparator80,
            this.COMED0502});
            this.COMED05.Name = "COMED05";
            this.COMED05.Size = new System.Drawing.Size(289, 26);
            this.COMED05.Text = "Registro de Invitados";
            // 
            // COMED0501
            // 
            this.COMED0501.Name = "COMED0501";
            this.COMED0501.Size = new System.Drawing.Size(249, 26);
            this.COMED0501.Text = "Registro de Invitados";
            this.COMED0501.Click += new System.EventHandler(this.COMED0501_Click);
            // 
            // toolStripSeparator80
            // 
            this.toolStripSeparator80.Name = "toolStripSeparator80";
            this.toolStripSeparator80.Size = new System.Drawing.Size(246, 6);
            // 
            // COMED0502
            // 
            this.COMED0502.Name = "COMED0502";
            this.COMED0502.Size = new System.Drawing.Size(249, 26);
            this.COMED0502.Text = "Comensal como Invitado";
            this.COMED0502.Click += new System.EventHandler(this.COMED0502_Click);
            // 
            // toolStripSeparator73
            // 
            this.toolStripSeparator73.Name = "toolStripSeparator73";
            this.toolStripSeparator73.Size = new System.Drawing.Size(286, 6);
            // 
            // COMED06
            // 
            this.COMED06.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.COMED0601,
            this.COMED0602});
            this.COMED06.Name = "COMED06";
            this.COMED06.Size = new System.Drawing.Size(289, 26);
            this.COMED06.Text = "Reportes";
            // 
            // COMED0601
            // 
            this.COMED0601.Name = "COMED0601";
            this.COMED0601.Size = new System.Drawing.Size(241, 26);
            this.COMED0601.Text = "Reporte de Insumos";
            this.COMED0601.Click += new System.EventHandler(this.COMED0601_Click);
            // 
            // COMED0602
            // 
            this.COMED0602.Name = "COMED0602";
            this.COMED0602.Size = new System.Drawing.Size(241, 26);
            this.COMED0602.Text = "Reporte de Comensales";
            this.COMED0602.Click += new System.EventHandler(this.COMED0602_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(286, 6);
            // 
            // PLATOS
            // 
            this.PLATOS.Name = "PLATOS";
            this.PLATOS.Size = new System.Drawing.Size(289, 26);
            this.PLATOS.Text = "Registro de Platos";
            this.PLATOS.Click += new System.EventHandler(this.PLATOS_Click);
            // 
            // UTIL
            // 
            this.UTIL.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UTIL01,
            this.toolStripSeparator7,
            this.UTIL02,
            this.toolStripSeparator35,
            this.UTIL03,
            this.toolStripSeparator30,
            this.UTIL06,
            this.toolStripSeparator65,
            this.UTIL08,
            this.toolStripSeparator26,
            this.UTIL09,
            this.toolStripSeparator88,
            this.UTIL10});
            this.UTIL.Name = "UTIL";
            this.UTIL.Size = new System.Drawing.Size(85, 24);
            this.UTIL.Text = "&Utilitarios";
            this.UTIL.Click += new System.EventHandler(this.herramientasToolStripMenuItem_Click);
            // 
            // UTIL01
            // 
            this.UTIL01.Name = "UTIL01";
            this.UTIL01.Size = new System.Drawing.Size(249, 26);
            this.UTIL01.Text = "Empresas";
            this.UTIL01.Click += new System.EventHandler(this.mantenimientoDeCompañíasToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(246, 6);
            // 
            // UTIL02
            // 
            this.UTIL02.Name = "UTIL02";
            this.UTIL02.Size = new System.Drawing.Size(249, 26);
            this.UTIL02.Text = "Usuarios del Sistema";
            this.UTIL02.Click += new System.EventHandler(this.administraciónDeUsuariosToolStripMenuItem_Click);
            // 
            // toolStripSeparator35
            // 
            this.toolStripSeparator35.Name = "toolStripSeparator35";
            this.toolStripSeparator35.Size = new System.Drawing.Size(246, 6);
            this.toolStripSeparator35.Visible = false;
            // 
            // UTIL03
            // 
            this.UTIL03.Name = "UTIL03";
            this.UTIL03.Size = new System.Drawing.Size(249, 26);
            this.UTIL03.Text = "Copia de Seguridad";
            this.UTIL03.Visible = false;
            this.UTIL03.Click += new System.EventHandler(this.copiaDeSeguridadToolStripMenuItem_Click);
            // 
            // toolStripSeparator30
            // 
            this.toolStripSeparator30.Name = "toolStripSeparator30";
            this.toolStripSeparator30.Size = new System.Drawing.Size(246, 6);
            this.toolStripSeparator30.Visible = false;
            // 
            // UTIL06
            // 
            this.UTIL06.Name = "UTIL06";
            this.UTIL06.Size = new System.Drawing.Size(249, 26);
            this.UTIL06.Text = "Parámetros de Impresión";
            this.UTIL06.Visible = false;
            this.UTIL06.Click += new System.EventHandler(this.parámetrosDeImpresiónToolStripMenuItem_Click);
            // 
            // toolStripSeparator65
            // 
            this.toolStripSeparator65.Name = "toolStripSeparator65";
            this.toolStripSeparator65.Size = new System.Drawing.Size(246, 6);
            // 
            // UTIL08
            // 
            this.UTIL08.Name = "UTIL08";
            this.UTIL08.Size = new System.Drawing.Size(249, 26);
            this.UTIL08.Text = "Cambiar Contraseña";
            this.UTIL08.ToolTipText = "Cambiar Contraseña";
            this.UTIL08.Click += new System.EventHandler(this.btnCambiarPass_Click);
            // 
            // toolStripSeparator26
            // 
            this.toolStripSeparator26.Name = "toolStripSeparator26";
            this.toolStripSeparator26.Size = new System.Drawing.Size(246, 6);
            // 
            // UTIL09
            // 
            this.UTIL09.Name = "UTIL09";
            this.UTIL09.Size = new System.Drawing.Size(249, 26);
            this.UTIL09.Text = "Sincronizar SAP/SISASIS";
            this.UTIL09.Click += new System.EventHandler(this.UTIL09_Click);
            // 
            // toolStripSeparator88
            // 
            this.toolStripSeparator88.Name = "toolStripSeparator88";
            this.toolStripSeparator88.Size = new System.Drawing.Size(246, 6);
            // 
            // UTIL10
            // 
            this.UTIL10.Name = "UTIL10";
            this.UTIL10.Size = new System.Drawing.Size(249, 26);
            this.UTIL10.Text = "Balanza";
            this.UTIL10.Click += new System.EventHandler(this.UTIL10_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(50, 24);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // toolStripForm
            // 
            this.toolStripForm.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStripForm.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripForm.Location = new System.Drawing.Point(0, 550);
            this.toolStripForm.Name = "toolStripForm";
            this.toolStripForm.Size = new System.Drawing.Size(1255, 25);
            this.toolStripForm.TabIndex = 3;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSincronizar,
            this.mTrabajadores,
            this.mTipoHorarios,
            this.btnProgramacion,
            this.btnReporteAsis,
            this.toolStripButton12});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1255, 39);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnSincronizar
            // 
            this.btnSincronizar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSincronizar.Image = global::CaniaBrava.Properties.Resources.synchronize;
            this.btnSincronizar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnSincronizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSincronizar.Name = "btnSincronizar";
            this.btnSincronizar.Size = new System.Drawing.Size(36, 36);
            this.btnSincronizar.Text = "Sincronizacion con SAP";
            this.btnSincronizar.Click += new System.EventHandler(this.btnSincronizar_Click);
            // 
            // mTrabajadores
            // 
            this.mTrabajadores.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.mTrabajadores.Image = global::CaniaBrava.Properties.Resources.employee;
            this.mTrabajadores.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mTrabajadores.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.mTrabajadores.Name = "mTrabajadores";
            this.mTrabajadores.Size = new System.Drawing.Size(36, 36);
            this.mTrabajadores.Text = "Lista de Trabajadores";
            this.mTrabajadores.Click += new System.EventHandler(this.mTrabajadores_Click);
            // 
            // mTipoHorarios
            // 
            this.mTipoHorarios.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.mTipoHorarios.Image = global::CaniaBrava.Properties.Resources.horario;
            this.mTipoHorarios.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mTipoHorarios.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.mTipoHorarios.Name = "mTipoHorarios";
            this.mTipoHorarios.Size = new System.Drawing.Size(36, 36);
            this.mTipoHorarios.Text = "Tipos de Horarios";
            this.mTipoHorarios.Click += new System.EventHandler(this.mTipoHorarios_Click);
            // 
            // btnProgramacion
            // 
            this.btnProgramacion.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnProgramacion.Image = global::CaniaBrava.Properties.Resources.calendar_clock;
            this.btnProgramacion.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnProgramacion.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnProgramacion.Name = "btnProgramacion";
            this.btnProgramacion.Size = new System.Drawing.Size(36, 36);
            this.btnProgramacion.ToolTipText = "Lista de Programaciones";
            this.btnProgramacion.Click += new System.EventHandler(this.btnProgramacion_Click);
            // 
            // btnReporteAsis
            // 
            this.btnReporteAsis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnReporteAsis.Image = global::CaniaBrava.Properties.Resources.reporte;
            this.btnReporteAsis.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnReporteAsis.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnReporteAsis.Name = "btnReporteAsis";
            this.btnReporteAsis.Size = new System.Drawing.Size(36, 36);
            this.btnReporteAsis.Text = "Reporte de Asistencia";
            this.btnReporteAsis.Click += new System.EventHandler(this.btnReporteAsis_Click);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = global::CaniaBrava.Properties.Resources.exit_closet;
            this.toolStripButton12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton12.Text = "Salir";
            this.toolStripButton12.Click += new System.EventHandler(this.toolStripButton12_Click);
            // 
            // loadingNext1
            // 
            this.loadingNext1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.loadingNext1.BackColor = System.Drawing.Color.Transparent;
            this.loadingNext1.ErrorImage = null;
            this.loadingNext1.Image = global::CaniaBrava.Properties.Resources.loading;
            this.loadingNext1.Location = new System.Drawing.Point(464, 208);
            this.loadingNext1.Margin = new System.Windows.Forms.Padding(4);
            this.loadingNext1.MaximumSize = new System.Drawing.Size(161, 127);
            this.loadingNext1.MinimumSize = new System.Drawing.Size(161, 127);
            this.loadingNext1.Name = "loadingNext1";
            this.loadingNext1.Size = new System.Drawing.Size(161, 127);
            this.loadingNext1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loadingNext1.TabIndex = 101;
            this.loadingNext1.TabStop = false;
            this.loadingNext1.Visible = false;
            // 
            // lblCargando
            // 
            this.lblCargando.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCargando.AutoSize = true;
            this.lblCargando.BackColor = System.Drawing.Color.Transparent;
            this.lblCargando.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblCargando.Location = new System.Drawing.Point(507, 263);
            this.lblCargando.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCargando.Name = "lblCargando";
            this.lblCargando.Size = new System.Drawing.Size(78, 17);
            this.lblCargando.TabIndex = 102;
            this.lblCargando.Text = "Cargando..";
            this.lblCargando.Visible = false;
            // 
            // GI0102
            // 
            this.GI0102.Name = "GI0102";
            this.GI0102.Size = new System.Drawing.Size(248, 26);
            this.GI0102.Text = "Objetivos De Produccion";
            this.GI0102.Click += new System.EventHandler(this.GI0102_Click);
            // 
            // ui_mdiprincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::CaniaBrava.Properties.Resources.cania;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1255, 575);
            this.ControlBox = false;
            this.Controls.Add(this.lblCargando);
            this.Controls.Add(this.loadingNext1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.toolStripForm);
            this.Controls.Add(this.menuMDI);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuMDI;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ui_mdiprincipal";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = " ";
            this.Text = "Software Empresarial - Módulo de Planillas";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ui_mdiprincipal_Load);
            this.menuMDI.ResumeLayout(false);
            this.menuMDI.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loadingNext1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuMDI;
        private System.Windows.Forms.ToolStripMenuItem TAMA;
        private System.Windows.Forms.ToolStripMenuItem MAPL;
        private System.Windows.Forms.ToolStripMenuItem UTIL;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStripForm;
        private System.Windows.Forms.ToolStripMenuItem UTIL01;
        private System.Windows.Forms.ToolStripMenuItem TAMA01;
        private System.Windows.Forms.ToolStripMenuItem TAMA05;
        private System.Windows.Forms.ToolStripMenuItem TAMA06;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem TAMA07;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripMenuItem TAMA02;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem UTIL02;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator35;
        private System.Windows.Forms.ToolStripMenuItem UTIL03;
        private System.Windows.Forms.ToolStripMenuItem TAMA0701;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator37;
        private System.Windows.Forms.ToolStripMenuItem TAMA0702;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator30;
        private System.Windows.Forms.ToolStripMenuItem MAPL05;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator46;
        private System.Windows.Forms.ToolStripMenuItem MAPL0501;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator48;
        private System.Windows.Forms.ToolStripMenuItem MAPL0502;
        private System.Windows.Forms.ToolStripMenuItem UTIL06;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator65;
        private System.Windows.Forms.ToolStripButton mTrabajadores;
        private System.Windows.Forms.ToolStripButton mTipoHorarios;
        private System.Windows.Forms.ToolStripButton btnProgramacion;
        private System.Windows.Forms.ToolStripButton btnReporteAsis;
        private System.Windows.Forms.ToolStripButton btnSincronizar;
        private System.Windows.Forms.ToolStripMenuItem UTIL08;
        private System.Windows.Forms.ToolStripMenuItem COMED;
        private System.Windows.Forms.ToolStripMenuItem COMED05;
        private System.Windows.Forms.ToolStripMenuItem UTIL09;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator26;
        private System.Windows.Forms.PictureBox loadingNext1;
        private System.Windows.Forms.Label lblCargando;
        private System.Windows.Forms.ToolStripMenuItem COMED01;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator69;
        private System.Windows.Forms.ToolStripMenuItem COMED02;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator70;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator68;
        private System.Windows.Forms.ToolStripMenuItem COMED04;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator71;
        private System.Windows.Forms.ToolStripMenuItem TAMA08;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator72;
        private System.Windows.Forms.ToolStripMenuItem COMED03;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator73;
        private System.Windows.Forms.ToolStripMenuItem COMED06;
        private System.Windows.Forms.ToolStripMenuItem COMED0601;
        private System.Windows.Forms.ToolStripMenuItem COMED0602;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator74;
        private System.Windows.Forms.ToolStripMenuItem TAMA09;
        private System.Windows.Forms.ToolStripMenuItem COMED0501;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator80;
        private System.Windows.Forms.ToolStripMenuItem COMED0502;
        private System.Windows.Forms.ToolStripMenuItem GGHS;
        private System.Windows.Forms.ToolStripMenuItem GGHS01;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator81;
        private System.Windows.Forms.ToolStripMenuItem GGHS02;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator82;
        private System.Windows.Forms.ToolStripMenuItem GGHS03;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator83;
        private System.Windows.Forms.ToolStripMenuItem GGHS04;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator84;
        private System.Windows.Forms.ToolStripMenuItem GGHS05;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator85;
        private System.Windows.Forms.ToolStripMenuItem GGHS06;
        private System.Windows.Forms.ToolStripMenuItem GGHS0401;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator75;
        private System.Windows.Forms.ToolStripMenuItem GGHS0402;
        private System.Windows.Forms.ToolStripMenuItem GGHS0301;
        private System.Windows.Forms.ToolStripMenuItem GO;
        private System.Windows.Forms.ToolStripMenuItem GO01;
        private System.Windows.Forms.ToolStripMenuItem GO0101;
        private System.Windows.Forms.ToolStripMenuItem GFACI;
        private System.Windows.Forms.ToolStripMenuItem GFACI01;
        private System.Windows.Forms.ToolStripMenuItem GFACI0101;
        private System.Windows.Forms.ToolStripMenuItem GFACI0102;
        private System.Windows.Forms.ToolStripMenuItem GI;
        private System.Windows.Forms.ToolStripMenuItem GI01;
        private System.Windows.Forms.ToolStripMenuItem GI0101;
        private System.Windows.Forms.ToolStripMenuItem GO02;
        private System.Windows.Forms.ToolStripMenuItem GO0201;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator88;
        private System.Windows.Forms.ToolStripMenuItem UTIL10;
        private System.Windows.Forms.ToolStripMenuItem GO03;
        private System.Windows.Forms.ToolStripMenuItem GO0301;
        private System.Windows.Forms.ToolStripMenuItem GGHS0201;
        private System.Windows.Forms.ToolStripMenuItem GGHS020101;
        private System.Windows.Forms.ToolStripMenuItem GGHS020102;
        private System.Windows.Forms.ToolStripMenuItem MAPL01;
        private System.Windows.Forms.ToolStripMenuItem MAPL0101;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem MAPL0102;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator61;
        private System.Windows.Forms.ToolStripMenuItem MAPL0103;
        private System.Windows.Forms.ToolStripMenuItem MAPL09;
        private System.Windows.Forms.ToolStripMenuItem MAPL0901;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator22;
        private System.Windows.Forms.ToolStripMenuItem MAPL0902;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator23;
        private System.Windows.Forms.ToolStripMenuItem MAPL0903;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator64;
        private System.Windows.Forms.ToolStripMenuItem MAPL0904;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator76;
        private System.Windows.Forms.ToolStripMenuItem MAPL0905;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator87;
        private System.Windows.Forms.ToolStripMenuItem MAPL0906;
        private System.Windows.Forms.ToolStripMenuItem MAPL10;
        private System.Windows.Forms.ToolStripMenuItem MAPL1001;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator77;
        private System.Windows.Forms.ToolStripMenuItem MAPL1002;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator78;
        private System.Windows.Forms.ToolStripMenuItem MAPL1003;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator79;
        private System.Windows.Forms.ToolStripMenuItem MAPL1004;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripMenuItem MAPL0907;
        private System.Windows.Forms.ToolStripMenuItem PLATOSPRODUCIDOS;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem PLATOS;
        private System.Windows.Forms.ToolStripMenuItem ATRAC_SELEC;
        private System.Windows.Forms.ToolStripMenuItem MaquetaDeGastos;
        private System.Windows.Forms.ToolStripMenuItem GFACI0103;
        private System.Windows.Forms.ToolStripMenuItem GFACI0104;
        private System.Windows.Forms.ToolStripMenuItem GI0102;
    }
}