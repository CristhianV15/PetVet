﻿namespace CaniaBrava.ds
{


    public partial class boleta
    {
        partial class dtboletaDataTable
        {
        }
    }
}
