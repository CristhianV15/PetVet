﻿namespace CaniaBrava.ds
{


    public partial class dspardiades
    {
        partial class dtpardiadesDataTable
        {
        }
    }
}
