﻿namespace CaniaBrava.ds
{


    public partial class subsidiados
    {
    }
}
namespace CaniaBrava.ds {
    
    
    public partial class subsidiados {
    }
}
