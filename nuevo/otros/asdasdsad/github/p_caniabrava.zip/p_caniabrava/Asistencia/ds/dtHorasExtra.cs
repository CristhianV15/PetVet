﻿namespace CaniaBrava.ds
{


    public partial class dtHorasExtra
    {
    }
}
