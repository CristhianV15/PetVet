﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaniaBrava
{
    class HorarioPer
    {
        public int dias_semana { get; set; }
        public string h_entrada { get; set; }
        public string h_salida { get; set; }
        public string nominas { get; set; }
    }
}
