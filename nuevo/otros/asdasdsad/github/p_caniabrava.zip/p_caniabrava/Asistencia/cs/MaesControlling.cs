﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaniaBrava
{
    public class MaesControlling
    {
        public int id { get; set; }
        public string idmaescon { get; set; }
        public string um { get; set; }
        public string cuencon { get; set; }
        public string cod { get; set; }
        public string rubro { get; set; }
        public string drubro { get; set; }
        public string dactividad { get; set; }
        public string actividad { get; set; }
        public string drecurso { get; set; }
        public string recurso { get; set; }
    }
}