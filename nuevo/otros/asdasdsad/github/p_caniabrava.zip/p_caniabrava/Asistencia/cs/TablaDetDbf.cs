﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaniaBrava.cs
{
    public class TablaDetDbf
    {
        public string dsubdia { get; set; }
        public string dcompro { get; set; }
        public string dsecue { get; set; }
        public string dfeccom { get; set; }
        public string dcuenta { get; set; }
        public string dcodane { get; set; }
        public string dcencos { get; set; }
        public string dcodmon { get; set; }
        public string ddh { get; set; }
        public float dimport { get; set; }
        public string dtipdoc { get; set; }
        public string dnumdoc { get; set; }
        public string dflag { get; set; }
        public string ddate { get; set; }
        public string dxglosa { get; set; }
        public float dusimpor { get; set; }
        public float dmnimpor { get; set; }
        public string dfeccom2 { get; set; }
        public string dvanexo { get; set; }
        public float dtipcam { get; set; }
        public float debe { get; set; }
        public float haber { get; set; }
        public string dcodane2 { get; set; }
        public string dvanexo2 { get; set; }
        public string dfecdoc2 { get; set; }
        public string dfecdoc { get; set; }
    }
}