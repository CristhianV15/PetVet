﻿namespace CaniaBrava.ds
{


    public partial class dsresdesper
    {
        partial class dtresdesperDataTable
        {
        }
    }
}
