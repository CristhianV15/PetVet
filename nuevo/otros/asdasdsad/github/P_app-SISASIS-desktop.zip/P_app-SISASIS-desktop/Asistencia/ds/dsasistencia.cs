﻿namespace CaniaBrava.ds
{
}

namespace CaniaBrava.ds
{


    public partial class dsasistencia
    {
    }
}
namespace CaniaBrava.ds {
    
    
    public partial class dsasistencia {
    }
}
