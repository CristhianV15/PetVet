﻿namespace CaniaBrava.ds
{
}

namespace CaniaBrava.ds
{
}

namespace CaniaBrava.ds
{
    public partial class dtcomedor
    {
        
    }
}

namespace CaniaBrava.ds
{


    partial class dscomedor
    {
        partial class dtcomedorDataTable
        {
        }
    }
}
