﻿namespace CaniaBrava
{
    partial class ui_confmotivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnEditarEstAne = new System.Windows.Forms.Button();
            this.btnGrabar = new System.Windows.Forms.Button();
            this.btnEliminarEstAne = new System.Windows.Forms.Button();
            this.btnNuevoEstAne = new System.Windows.Forms.Button();
            this.grp1 = new System.Windows.Forms.GroupBox();
            this.cmbConceptoPdt = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbColPlan = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDesBol = new System.Windows.Forms.TextBox();
            this.cmbTipoPer = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.chkDestajo = new System.Windows.Forms.CheckBox();
            this.dgvDetalle = new System.Windows.Forms.DataGridView();
            this.btnSalir = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDebe = new System.Windows.Forms.TextBox();
            this.btnFormulaTopeMax = new System.Windows.Forms.Button();
            this.cmbTopeMax = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtValorTopeMax = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnFormulaTopeMin = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFormulaTopeMin = new System.Windows.Forms.TextBox();
            this.cmbTopeMin = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnFormula = new System.Windows.Forms.Button();
            this.chkGeneracion = new System.Windows.Forms.CheckBox();
            this.txtValorTopeMin = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtFormula = new System.Windows.Forms.TextBox();
            this.grp2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFormulaTopeMax = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtHaber = new System.Windows.Forms.TextBox();
            this.cmbEstado = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.grp3 = new System.Windows.Forms.GroupBox();
            this.grp6 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtAneRefHa = new System.Windows.Forms.TextBox();
            this.txtTipoAneRefHa = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtAneHa = new System.Windows.Forms.TextBox();
            this.txtTipoAneHa = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.grp5 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtAneRefDe = new System.Windows.Forms.TextBox();
            this.txtTipoAneRefDe = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAneDe = new System.Windows.Forms.TextBox();
            this.txtTipoAneDe = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBoxBuscar = new System.Windows.Forms.PictureBox();
            this.lblF2 = new System.Windows.Forms.Label();
            this.grp4 = new System.Windows.Forms.GroupBox();
            this.chkPresta = new System.Windows.Forms.CheckBox();
            this.chkCero = new System.Windows.Forms.CheckBox();
            this.chkProy5taCat = new System.Windows.Forms.CheckBox();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.radioButtonSi = new System.Windows.Forms.RadioButton();
            this.radioButtonNo = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkQuinta = new System.Windows.Forms.CheckBox();
            this.chkRemProm = new System.Windows.Forms.CheckBox();
            this.chkAsegurable = new System.Windows.Forms.CheckBox();
            this.grp1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).BeginInit();
            this.grp2.SuspendLayout();
            this.grp3.SuspendLayout();
            this.grp6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grp5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuscar)).BeginInit();
            this.grp4.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnEditarEstAne
            // 
            this.btnEditarEstAne.Location = new System.Drawing.Point(603, 550);
            this.btnEditarEstAne.Name = "btnEditarEstAne";
            this.btnEditarEstAne.Size = new System.Drawing.Size(75, 27);
            this.btnEditarEstAne.TabIndex = 76;
            this.btnEditarEstAne.Text = "Modificar";
            this.btnEditarEstAne.UseVisualStyleBackColor = true;
            this.btnEditarEstAne.Click += new System.EventHandler(this.btnEditarEstAne_Click);
            // 
            // btnGrabar
            // 
            this.btnGrabar.Location = new System.Drawing.Point(684, 550);
            this.btnGrabar.Name = "btnGrabar";
            this.btnGrabar.Size = new System.Drawing.Size(75, 27);
            this.btnGrabar.TabIndex = 72;
            this.btnGrabar.Text = "Grabar";
            this.btnGrabar.UseVisualStyleBackColor = true;
            this.btnGrabar.Click += new System.EventHandler(this.btnGrabar_Click);
            // 
            // btnEliminarEstAne
            // 
            this.btnEliminarEstAne.Location = new System.Drawing.Point(769, 550);
            this.btnEliminarEstAne.Name = "btnEliminarEstAne";
            this.btnEliminarEstAne.Size = new System.Drawing.Size(75, 27);
            this.btnEliminarEstAne.TabIndex = 75;
            this.btnEliminarEstAne.Text = "Eliminar";
            this.btnEliminarEstAne.UseVisualStyleBackColor = true;
            this.btnEliminarEstAne.Click += new System.EventHandler(this.btnEliminarEstAne_Click);
            // 
            // btnNuevoEstAne
            // 
            this.btnNuevoEstAne.Location = new System.Drawing.Point(518, 550);
            this.btnNuevoEstAne.Name = "btnNuevoEstAne";
            this.btnNuevoEstAne.Size = new System.Drawing.Size(75, 27);
            this.btnNuevoEstAne.TabIndex = 74;
            this.btnNuevoEstAne.Text = "Nuevo";
            this.btnNuevoEstAne.UseVisualStyleBackColor = true;
            this.btnNuevoEstAne.Click += new System.EventHandler(this.btnNuevoEstAne_Click);
            // 
            // grp1
            // 
            this.grp1.Controls.Add(this.cmbConceptoPdt);
            this.grp1.Controls.Add(this.label3);
            this.grp1.Controls.Add(this.cmbColPlan);
            this.grp1.Controls.Add(this.label2);
            this.grp1.Controls.Add(this.label1);
            this.grp1.Controls.Add(this.txtDesBol);
            this.grp1.Controls.Add(this.cmbTipoPer);
            this.grp1.Controls.Add(this.label16);
            this.grp1.Location = new System.Drawing.Point(32, 99);
            this.grp1.Name = "grp1";
            this.grp1.Size = new System.Drawing.Size(631, 127);
            this.grp1.TabIndex = 0;
            this.grp1.TabStop = false;
            this.grp1.Text = "Configuración";
            // 
            // cmbConceptoPdt
            // 
            this.cmbConceptoPdt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbConceptoPdt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbConceptoPdt.DropDownWidth = 650;
            this.cmbConceptoPdt.Enabled = false;
            this.cmbConceptoPdt.FormattingEnabled = true;
            this.cmbConceptoPdt.Location = new System.Drawing.Point(162, 92);
            this.cmbConceptoPdt.Name = "cmbConceptoPdt";
            this.cmbConceptoPdt.Size = new System.Drawing.Size(451, 21);
            this.cmbConceptoPdt.TabIndex = 76;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 13);
            this.label3.TabIndex = 75;
            this.label3.Text = "Código en Planilla Electrónica :";
            // 
            // cmbColPlan
            // 
            this.cmbColPlan.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbColPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbColPlan.Enabled = false;
            this.cmbColPlan.FormattingEnabled = true;
            this.cmbColPlan.Location = new System.Drawing.Point(162, 65);
            this.cmbColPlan.Name = "cmbColPlan";
            this.cmbColPlan.Size = new System.Drawing.Size(449, 21);
            this.cmbColPlan.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 73;
            this.label2.Text = "Columna en Planilla :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 13);
            this.label1.TabIndex = 71;
            this.label1.Text = "Descripción en Boleta de Pago :";
            // 
            // txtDesBol
            // 
            this.txtDesBol.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtDesBol.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDesBol.Enabled = false;
            this.txtDesBol.Location = new System.Drawing.Point(162, 40);
            this.txtDesBol.MaxLength = 20;
            this.txtDesBol.Name = "txtDesBol";
            this.txtDesBol.Size = new System.Drawing.Size(449, 20);
            this.txtDesBol.TabIndex = 1;
            // 
            // cmbTipoPer
            // 
            this.cmbTipoPer.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbTipoPer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoPer.Enabled = false;
            this.cmbTipoPer.FormattingEnabled = true;
            this.cmbTipoPer.Location = new System.Drawing.Point(162, 15);
            this.cmbTipoPer.Name = "cmbTipoPer";
            this.cmbTipoPer.Size = new System.Drawing.Size(197, 21);
            this.cmbTipoPer.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1, 19);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 13);
            this.label16.TabIndex = 23;
            this.label16.Text = "Tipo de Personal :";
            // 
            // chkDestajo
            // 
            this.chkDestajo.AutoSize = true;
            this.chkDestajo.Enabled = false;
            this.chkDestajo.Location = new System.Drawing.Point(10, 19);
            this.chkDestajo.Name = "chkDestajo";
            this.chkDestajo.Size = new System.Drawing.Size(208, 17);
            this.chkDestajo.TabIndex = 113;
            this.chkDestajo.Text = "Concepto para Información de Destajo";
            this.chkDestajo.UseVisualStyleBackColor = true;
            this.chkDestajo.CheckedChanged += new System.EventHandler(this.chkDestajo_CheckedChanged);
            // 
            // dgvDetalle
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDetalle.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDetalle.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDetalle.Location = new System.Drawing.Point(1, 0);
            this.dgvDetalle.Name = "dgvDetalle";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDetalle.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDetalle.Size = new System.Drawing.Size(1081, 97);
            this.dgvDetalle.TabIndex = 0;
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(859, 550);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 27);
            this.btnSalir.TabIndex = 77;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 92;
            this.label9.Text = "Cuenta  :";
            // 
            // txtDebe
            // 
            this.txtDebe.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtDebe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDebe.Enabled = false;
            this.txtDebe.Location = new System.Drawing.Point(105, 16);
            this.txtDebe.MaxLength = 30;
            this.txtDebe.Name = "txtDebe";
            this.txtDebe.Size = new System.Drawing.Size(126, 20);
            this.txtDebe.TabIndex = 0;
            this.txtDebe.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDebe_KeyDown);
            // 
            // btnFormulaTopeMax
            // 
            this.btnFormulaTopeMax.Enabled = false;
            this.btnFormulaTopeMax.Location = new System.Drawing.Point(789, 117);
            this.btnFormulaTopeMax.Name = "btnFormulaTopeMax";
            this.btnFormulaTopeMax.Size = new System.Drawing.Size(75, 27);
            this.btnFormulaTopeMax.TabIndex = 10;
            this.btnFormulaTopeMax.Text = "Constructor";
            this.btnFormulaTopeMax.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnFormulaTopeMax.UseVisualStyleBackColor = true;
            this.btnFormulaTopeMax.Click += new System.EventHandler(this.btnFormulaTopeMax_Click);
            // 
            // cmbTopeMax
            // 
            this.cmbTopeMax.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbTopeMax.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTopeMax.Enabled = false;
            this.cmbTopeMax.FormattingEnabled = true;
            this.cmbTopeMax.Items.AddRange(new object[] {
            "SI",
            "NO",
            "  "});
            this.cmbTopeMax.Location = new System.Drawing.Point(160, 113);
            this.cmbTopeMax.Name = "cmbTopeMax";
            this.cmbTopeMax.Size = new System.Drawing.Size(58, 21);
            this.cmbTopeMax.TabIndex = 7;
            this.cmbTopeMax.SelectedIndexChanged += new System.EventHandler(this.cmbTopeMax_SelectedIndexChanged);
            this.cmbTopeMax.SelectionChangeCommitted += new System.EventHandler(this.cmbTopeMax_SelectionChangeCommitted);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 13);
            this.label7.TabIndex = 107;
            this.label7.Text = "Posee Tope Máximo :";
            // 
            // txtValorTopeMax
            // 
            this.txtValorTopeMax.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtValorTopeMax.Enabled = false;
            this.txtValorTopeMax.Location = new System.Drawing.Point(307, 114);
            this.txtValorTopeMax.Name = "txtValorTopeMax";
            this.txtValorTopeMax.Size = new System.Drawing.Size(141, 20);
            this.txtValorTopeMax.TabIndex = 8;
            this.txtValorTopeMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(229, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 105;
            this.label8.Text = "Tope Máximo";
            // 
            // btnFormulaTopeMin
            // 
            this.btnFormulaTopeMin.Enabled = false;
            this.btnFormulaTopeMin.Location = new System.Drawing.Point(789, 70);
            this.btnFormulaTopeMin.Name = "btnFormulaTopeMin";
            this.btnFormulaTopeMin.Size = new System.Drawing.Size(75, 27);
            this.btnFormulaTopeMin.TabIndex = 6;
            this.btnFormulaTopeMin.Text = "Constructor";
            this.btnFormulaTopeMin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnFormulaTopeMin.UseVisualStyleBackColor = true;
            this.btnFormulaTopeMin.Click += new System.EventHandler(this.btnFormulaTopeMin_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(452, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 39);
            this.label5.TabIndex = 102;
            this.label5.Text = "Si el resultado de la Fórmula es menor al Tope Mínimo colocar :";
            // 
            // txtFormulaTopeMin
            // 
            this.txtFormulaTopeMin.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtFormulaTopeMin.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFormulaTopeMin.Enabled = false;
            this.txtFormulaTopeMin.Location = new System.Drawing.Point(612, 66);
            this.txtFormulaTopeMin.MaxLength = 500;
            this.txtFormulaTopeMin.Multiline = true;
            this.txtFormulaTopeMin.Name = "txtFormulaTopeMin";
            this.txtFormulaTopeMin.ReadOnly = true;
            this.txtFormulaTopeMin.Size = new System.Drawing.Size(174, 42);
            this.txtFormulaTopeMin.TabIndex = 5;
            // 
            // cmbTopeMin
            // 
            this.cmbTopeMin.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbTopeMin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTopeMin.Enabled = false;
            this.cmbTopeMin.FormattingEnabled = true;
            this.cmbTopeMin.Items.AddRange(new object[] {
            "SI",
            "NO",
            "  "});
            this.cmbTopeMin.Location = new System.Drawing.Point(160, 66);
            this.cmbTopeMin.Name = "cmbTopeMin";
            this.cmbTopeMin.Size = new System.Drawing.Size(58, 21);
            this.cmbTopeMin.TabIndex = 3;
            this.cmbTopeMin.SelectedIndexChanged += new System.EventHandler(this.cmbTopeMin_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 13);
            this.label4.TabIndex = 100;
            this.label4.Text = "Posee Tope Mínimo :";
            // 
            // btnFormula
            // 
            this.btnFormula.Enabled = false;
            this.btnFormula.Location = new System.Drawing.Point(789, 23);
            this.btnFormula.Name = "btnFormula";
            this.btnFormula.Size = new System.Drawing.Size(75, 27);
            this.btnFormula.TabIndex = 2;
            this.btnFormula.Text = "Constructor";
            this.btnFormula.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnFormula.UseVisualStyleBackColor = true;
            this.btnFormula.Click += new System.EventHandler(this.btnFormula_Click);
            // 
            // chkGeneracion
            // 
            this.chkGeneracion.AutoSize = true;
            this.chkGeneracion.Enabled = false;
            this.chkGeneracion.Location = new System.Drawing.Point(6, -1);
            this.chkGeneracion.Name = "chkGeneracion";
            this.chkGeneracion.Size = new System.Drawing.Size(223, 17);
            this.chkGeneracion.TabIndex = 0;
            this.chkGeneracion.Text = "Generación Automática mediante Fórmula";
            this.chkGeneracion.UseVisualStyleBackColor = true;
            this.chkGeneracion.CheckedChanged += new System.EventHandler(this.chkGeneracion_CheckedChanged);
            // 
            // txtValorTopeMin
            // 
            this.txtValorTopeMin.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtValorTopeMin.Enabled = false;
            this.txtValorTopeMin.Location = new System.Drawing.Point(307, 67);
            this.txtValorTopeMin.Name = "txtValorTopeMin";
            this.txtValorTopeMin.Size = new System.Drawing.Size(141, 20);
            this.txtValorTopeMin.TabIndex = 4;
            this.txtValorTopeMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(229, 70);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 13);
            this.label14.TabIndex = 96;
            this.label14.Text = "Tope Mínimo :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(34, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 13);
            this.label18.TabIndex = 95;
            this.label18.Text = "Fórmula :";
            // 
            // txtFormula
            // 
            this.txtFormula.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtFormula.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFormula.Enabled = false;
            this.txtFormula.Location = new System.Drawing.Point(160, 20);
            this.txtFormula.MaxLength = 500;
            this.txtFormula.Multiline = true;
            this.txtFormula.Name = "txtFormula";
            this.txtFormula.ReadOnly = true;
            this.txtFormula.Size = new System.Drawing.Size(626, 42);
            this.txtFormula.TabIndex = 1;
            // 
            // grp2
            // 
            this.grp2.Controls.Add(this.label6);
            this.grp2.Controls.Add(this.txtFormulaTopeMax);
            this.grp2.Controls.Add(this.btnFormulaTopeMax);
            this.grp2.Controls.Add(this.cmbTopeMax);
            this.grp2.Controls.Add(this.label7);
            this.grp2.Controls.Add(this.txtValorTopeMax);
            this.grp2.Controls.Add(this.label8);
            this.grp2.Controls.Add(this.btnFormulaTopeMin);
            this.grp2.Controls.Add(this.label5);
            this.grp2.Controls.Add(this.txtFormulaTopeMin);
            this.grp2.Controls.Add(this.cmbTopeMin);
            this.grp2.Controls.Add(this.label4);
            this.grp2.Controls.Add(this.btnFormula);
            this.grp2.Controls.Add(this.chkGeneracion);
            this.grp2.Controls.Add(this.txtValorTopeMin);
            this.grp2.Controls.Add(this.label14);
            this.grp2.Controls.Add(this.label18);
            this.grp2.Controls.Add(this.txtFormula);
            this.grp2.Location = new System.Drawing.Point(34, 255);
            this.grp2.Name = "grp2";
            this.grp2.Size = new System.Drawing.Size(1016, 161);
            this.grp2.TabIndex = 1;
            this.grp2.TabStop = false;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(452, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 39);
            this.label6.TabIndex = 112;
            this.label6.Text = "Si el resultado de la Fórmula es mayor al Tope Máximo colocar :";
            // 
            // txtFormulaTopeMax
            // 
            this.txtFormulaTopeMax.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtFormulaTopeMax.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFormulaTopeMax.Enabled = false;
            this.txtFormulaTopeMax.Location = new System.Drawing.Point(612, 113);
            this.txtFormulaTopeMax.MaxLength = 500;
            this.txtFormulaTopeMax.Multiline = true;
            this.txtFormulaTopeMax.Name = "txtFormulaTopeMax";
            this.txtFormulaTopeMax.ReadOnly = true;
            this.txtFormulaTopeMax.Size = new System.Drawing.Size(174, 42);
            this.txtFormulaTopeMax.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 113;
            this.label10.Text = "Cuenta  :";
            // 
            // txtHaber
            // 
            this.txtHaber.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtHaber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtHaber.Enabled = false;
            this.txtHaber.Location = new System.Drawing.Point(99, 12);
            this.txtHaber.MaxLength = 30;
            this.txtHaber.Name = "txtHaber";
            this.txtHaber.Size = new System.Drawing.Size(126, 20);
            this.txtHaber.TabIndex = 1;
            this.txtHaber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtHaber_KeyDown);
            // 
            // cmbEstado
            // 
            this.cmbEstado.BackColor = System.Drawing.SystemColors.HighlightText;
            this.cmbEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstado.Enabled = false;
            this.cmbEstado.FormattingEnabled = true;
            this.cmbEstado.Items.AddRange(new object[] {
            "V    VIGENTE",
            "A    ANULADO"});
            this.cmbEstado.Location = new System.Drawing.Point(125, 100);
            this.cmbEstado.Name = "cmbEstado";
            this.cmbEstado.Size = new System.Drawing.Size(124, 21);
            this.cmbEstado.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 103);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 13);
            this.label11.TabIndex = 78;
            this.label11.Text = "Estado del Concepto :";
            // 
            // grp3
            // 
            this.grp3.Controls.Add(this.grp6);
            this.grp3.Controls.Add(this.grp5);
            this.grp3.Location = new System.Drawing.Point(36, 420);
            this.grp3.Name = "grp3";
            this.grp3.Size = new System.Drawing.Size(750, 125);
            this.grp3.TabIndex = 2;
            this.grp3.TabStop = false;
            this.grp3.Text = "Asiento Contable";
            // 
            // grp6
            // 
            this.grp6.Controls.Add(this.label22);
            this.grp6.Controls.Add(this.txtAneRefHa);
            this.grp6.Controls.Add(this.txtTipoAneRefHa);
            this.grp6.Controls.Add(this.label23);
            this.grp6.Controls.Add(this.label17);
            this.grp6.Controls.Add(this.txtAneHa);
            this.grp6.Controls.Add(this.txtTipoAneHa);
            this.grp6.Controls.Add(this.label19);
            this.grp6.Controls.Add(this.pictureBox1);
            this.grp6.Controls.Add(this.label12);
            this.grp6.Controls.Add(this.txtHaber);
            this.grp6.Controls.Add(this.label10);
            this.grp6.Location = new System.Drawing.Point(373, 15);
            this.grp6.Name = "grp6";
            this.grp6.Size = new System.Drawing.Size(360, 95);
            this.grp6.TabIndex = 137;
            this.grp6.TabStop = false;
            this.grp6.Text = "Haber";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(136, 66);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 13);
            this.label22.TabIndex = 135;
            this.label22.Text = "Ane.Ref. :";
            // 
            // txtAneRefHa
            // 
            this.txtAneRefHa.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAneRefHa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAneRefHa.Enabled = false;
            this.txtAneRefHa.Location = new System.Drawing.Point(194, 62);
            this.txtAneRefHa.MaxLength = 18;
            this.txtAneRefHa.Name = "txtAneRefHa";
            this.txtAneRefHa.Size = new System.Drawing.Size(156, 20);
            this.txtAneRefHa.TabIndex = 134;
            // 
            // txtTipoAneRefHa
            // 
            this.txtTipoAneRefHa.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTipoAneRefHa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTipoAneRefHa.Enabled = false;
            this.txtTipoAneRefHa.Location = new System.Drawing.Point(99, 62);
            this.txtTipoAneRefHa.MaxLength = 1;
            this.txtTipoAneRefHa.Name = "txtTipoAneRefHa";
            this.txtTipoAneRefHa.Size = new System.Drawing.Size(34, 20);
            this.txtTipoAneRefHa.TabIndex = 132;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 66);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(91, 13);
            this.label23.TabIndex = 133;
            this.label23.Text = "Tipo de Ane.Ref :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(136, 41);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 13);
            this.label17.TabIndex = 127;
            this.label17.Text = "Anexo :";
            // 
            // txtAneHa
            // 
            this.txtAneHa.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAneHa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAneHa.Enabled = false;
            this.txtAneHa.Location = new System.Drawing.Point(194, 37);
            this.txtAneHa.MaxLength = 18;
            this.txtAneHa.Name = "txtAneHa";
            this.txtAneHa.Size = new System.Drawing.Size(156, 20);
            this.txtAneHa.TabIndex = 126;
            // 
            // txtTipoAneHa
            // 
            this.txtTipoAneHa.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTipoAneHa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTipoAneHa.Enabled = false;
            this.txtTipoAneHa.Location = new System.Drawing.Point(99, 37);
            this.txtTipoAneHa.MaxLength = 1;
            this.txtTipoAneHa.Name = "txtTipoAneHa";
            this.txtTipoAneHa.Size = new System.Drawing.Size(34, 20);
            this.txtTipoAneHa.TabIndex = 124;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 41);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 13);
            this.label19.TabIndex = 125;
            this.label19.Text = "Tipo de Anexo :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CaniaBrava.Properties.Resources.LOCATE;
            this.pictureBox1.Location = new System.Drawing.Point(251, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 21);
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(230, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 13);
            this.label12.TabIndex = 118;
            this.label12.Text = "F2";
            // 
            // grp5
            // 
            this.grp5.Controls.Add(this.label20);
            this.grp5.Controls.Add(this.txtAneRefDe);
            this.grp5.Controls.Add(this.txtTipoAneRefDe);
            this.grp5.Controls.Add(this.label21);
            this.grp5.Controls.Add(this.label15);
            this.grp5.Controls.Add(this.txtAneDe);
            this.grp5.Controls.Add(this.txtTipoAneDe);
            this.grp5.Controls.Add(this.label13);
            this.grp5.Controls.Add(this.pictureBoxBuscar);
            this.grp5.Controls.Add(this.lblF2);
            this.grp5.Controls.Add(this.txtDebe);
            this.grp5.Controls.Add(this.label9);
            this.grp5.Location = new System.Drawing.Point(7, 15);
            this.grp5.Name = "grp5";
            this.grp5.Size = new System.Drawing.Size(355, 95);
            this.grp5.TabIndex = 136;
            this.grp5.TabStop = false;
            this.grp5.Text = "Debe";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(141, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 13);
            this.label20.TabIndex = 131;
            this.label20.Text = "Ane.Ref :";
            // 
            // txtAneRefDe
            // 
            this.txtAneRefDe.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAneRefDe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAneRefDe.Enabled = false;
            this.txtAneRefDe.Location = new System.Drawing.Point(193, 66);
            this.txtAneRefDe.MaxLength = 18;
            this.txtAneRefDe.Name = "txtAneRefDe";
            this.txtAneRefDe.Size = new System.Drawing.Size(156, 20);
            this.txtAneRefDe.TabIndex = 130;
            // 
            // txtTipoAneRefDe
            // 
            this.txtTipoAneRefDe.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTipoAneRefDe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTipoAneRefDe.Enabled = false;
            this.txtTipoAneRefDe.Location = new System.Drawing.Point(105, 66);
            this.txtTipoAneRefDe.MaxLength = 1;
            this.txtTipoAneRefDe.Name = "txtTipoAneRefDe";
            this.txtTipoAneRefDe.Size = new System.Drawing.Size(33, 20);
            this.txtTipoAneRefDe.TabIndex = 128;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 70);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(97, 13);
            this.label21.TabIndex = 129;
            this.label21.Text = "Tipo de Ane. Ref. :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(141, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 123;
            this.label15.Text = "Anexo :";
            // 
            // txtAneDe
            // 
            this.txtAneDe.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAneDe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAneDe.Enabled = false;
            this.txtAneDe.Location = new System.Drawing.Point(193, 41);
            this.txtAneDe.MaxLength = 18;
            this.txtAneDe.Name = "txtAneDe";
            this.txtAneDe.Size = new System.Drawing.Size(156, 20);
            this.txtAneDe.TabIndex = 122;
            // 
            // txtTipoAneDe
            // 
            this.txtTipoAneDe.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtTipoAneDe.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTipoAneDe.Enabled = false;
            this.txtTipoAneDe.Location = new System.Drawing.Point(105, 41);
            this.txtTipoAneDe.MaxLength = 1;
            this.txtTipoAneDe.Name = "txtTipoAneDe";
            this.txtTipoAneDe.Size = new System.Drawing.Size(33, 20);
            this.txtTipoAneDe.TabIndex = 120;
            this.txtTipoAneDe.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 13);
            this.label13.TabIndex = 121;
            this.label13.Text = "Tipo de Anexo :";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // pictureBoxBuscar
            // 
            this.pictureBoxBuscar.Image = global::CaniaBrava.Properties.Resources.LOCATE;
            this.pictureBoxBuscar.Location = new System.Drawing.Point(258, 14);
            this.pictureBoxBuscar.Name = "pictureBoxBuscar";
            this.pictureBoxBuscar.Size = new System.Drawing.Size(24, 21);
            this.pictureBoxBuscar.TabIndex = 117;
            this.pictureBoxBuscar.TabStop = false;
            // 
            // lblF2
            // 
            this.lblF2.AutoSize = true;
            this.lblF2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF2.Location = new System.Drawing.Point(236, 18);
            this.lblF2.Name = "lblF2";
            this.lblF2.Size = new System.Drawing.Size(21, 13);
            this.lblF2.TabIndex = 116;
            this.lblF2.Text = "F2";
            // 
            // grp4
            // 
            this.grp4.Controls.Add(this.chkAsegurable);
            this.grp4.Controls.Add(this.chkPresta);
            this.grp4.Controls.Add(this.chkCero);
            this.grp4.Controls.Add(this.chkProy5taCat);
            this.grp4.Controls.Add(this.cmbEstado);
            this.grp4.Controls.Add(this.label11);
            this.grp4.Location = new System.Drawing.Point(792, 416);
            this.grp4.Name = "grp4";
            this.grp4.Size = new System.Drawing.Size(258, 129);
            this.grp4.TabIndex = 3;
            this.grp4.TabStop = false;
            // 
            // chkPresta
            // 
            this.chkPresta.AutoSize = true;
            this.chkPresta.Enabled = false;
            this.chkPresta.Location = new System.Drawing.Point(5, 54);
            this.chkPresta.Name = "chkPresta";
            this.chkPresta.Size = new System.Drawing.Size(183, 17);
            this.chkPresta.TabIndex = 117;
            this.chkPresta.Text = "Incluir en el Control de Préstamos";
            this.chkPresta.UseVisualStyleBackColor = true;
            // 
            // chkCero
            // 
            this.chkCero.AutoSize = true;
            this.chkCero.Enabled = false;
            this.chkCero.Location = new System.Drawing.Point(5, 77);
            this.chkCero.Name = "chkCero";
            this.chkCero.Size = new System.Drawing.Size(244, 17);
            this.chkCero.TabIndex = 116;
            this.chkCero.Text = "Registrar motivo aún cuando el valor sea Cero";
            this.chkCero.UseVisualStyleBackColor = true;
            // 
            // chkProy5taCat
            // 
            this.chkProy5taCat.AutoSize = true;
            this.chkProy5taCat.Enabled = false;
            this.chkProy5taCat.Location = new System.Drawing.Point(5, 31);
            this.chkProy5taCat.Name = "chkProy5taCat";
            this.chkProy5taCat.Size = new System.Drawing.Size(153, 17);
            this.chkProy5taCat.TabIndex = 113;
            this.chkProy5taCat.Text = "Proyectable 5ta. Categoría";
            this.chkProy5taCat.UseVisualStyleBackColor = true;
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.radioButtonSi);
            this.groupBox39.Controls.Add(this.radioButtonNo);
            this.groupBox39.Location = new System.Drawing.Point(672, 99);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(378, 63);
            this.groupBox39.TabIndex = 78;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "¿ El concepto se imprimirá en la Boleta de Pago ?";
            // 
            // radioButtonSi
            // 
            this.radioButtonSi.AutoSize = true;
            this.radioButtonSi.BackColor = System.Drawing.SystemColors.HighlightText;
            this.radioButtonSi.Enabled = false;
            this.radioButtonSi.Location = new System.Drawing.Point(63, 38);
            this.radioButtonSi.Name = "radioButtonSi";
            this.radioButtonSi.Size = new System.Drawing.Size(34, 17);
            this.radioButtonSi.TabIndex = 60;
            this.radioButtonSi.Text = "Si";
            this.radioButtonSi.UseVisualStyleBackColor = false;
            // 
            // radioButtonNo
            // 
            this.radioButtonNo.AutoSize = true;
            this.radioButtonNo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.radioButtonNo.Enabled = false;
            this.radioButtonNo.Location = new System.Drawing.Point(134, 38);
            this.radioButtonNo.Name = "radioButtonNo";
            this.radioButtonNo.Size = new System.Drawing.Size(39, 17);
            this.radioButtonNo.TabIndex = 61;
            this.radioButtonNo.Text = "No";
            this.radioButtonNo.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkDestajo);
            this.groupBox1.Location = new System.Drawing.Point(672, 171);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(378, 55);
            this.groupBox1.TabIndex = 79;
            this.groupBox1.TabStop = false;
            // 
            // chkQuinta
            // 
            this.chkQuinta.AutoSize = true;
            this.chkQuinta.Enabled = false;
            this.chkQuinta.Location = new System.Drawing.Point(40, 230);
            this.chkQuinta.Name = "chkQuinta";
            this.chkQuinta.Size = new System.Drawing.Size(288, 17);
            this.chkQuinta.TabIndex = 114;
            this.chkQuinta.Text = "Concepto perteneciente al Cálculo de Quinta Categoría";
            this.chkQuinta.UseVisualStyleBackColor = true;
            this.chkQuinta.CheckedChanged += new System.EventHandler(this.chkQuinta_CheckedChanged);
            // 
            // chkRemProm
            // 
            this.chkRemProm.AutoSize = true;
            this.chkRemProm.Enabled = false;
            this.chkRemProm.Location = new System.Drawing.Point(349, 230);
            this.chkRemProm.Name = "chkRemProm";
            this.chkRemProm.Size = new System.Drawing.Size(294, 17);
            this.chkRemProm.TabIndex = 115;
            this.chkRemProm.Text = "Considerar para el Cálculo de la Remuneración Promedio";
            this.chkRemProm.UseVisualStyleBackColor = true;
            // 
            // chkAsegurable
            // 
            this.chkAsegurable.AutoSize = true;
            this.chkAsegurable.Enabled = false;
            this.chkAsegurable.Location = new System.Drawing.Point(5, 8);
            this.chkAsegurable.Name = "chkAsegurable";
            this.chkAsegurable.Size = new System.Drawing.Size(164, 17);
            this.chkAsegurable.TabIndex = 118;
            this.chkAsegurable.Text = "Asegurable Fondo Pensiones";
            this.chkAsegurable.UseVisualStyleBackColor = true;
            // 
            // ui_confmotivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(1082, 581);
            this.ControlBox = false;
            this.Controls.Add(this.chkQuinta);
            this.Controls.Add(this.chkRemProm);
            this.Controls.Add(this.grp4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox39);
            this.Controls.Add(this.grp3);
            this.Controls.Add(this.grp2);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnEditarEstAne);
            this.Controls.Add(this.btnGrabar);
            this.Controls.Add(this.btnEliminarEstAne);
            this.Controls.Add(this.btnNuevoEstAne);
            this.Controls.Add(this.grp1);
            this.Controls.Add(this.dgvDetalle);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ui_confmotivos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuración de Conceptos de Planilla";
            this.Load += new System.EventHandler(this.ui_confmotivos_Load);
            this.grp1.ResumeLayout(false);
            this.grp1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).EndInit();
            this.grp2.ResumeLayout(false);
            this.grp2.PerformLayout();
            this.grp3.ResumeLayout(false);
            this.grp6.ResumeLayout(false);
            this.grp6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grp5.ResumeLayout(false);
            this.grp5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuscar)).EndInit();
            this.grp4.ResumeLayout(false);
            this.grp4.PerformLayout();
            this.groupBox39.ResumeLayout(false);
            this.groupBox39.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEditarEstAne;
        private System.Windows.Forms.Button btnGrabar;
        private System.Windows.Forms.Button btnEliminarEstAne;
        private System.Windows.Forms.Button btnNuevoEstAne;
        private System.Windows.Forms.GroupBox grp1;
        private System.Windows.Forms.ComboBox cmbTipoPer;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView dgvDetalle;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDesBol;
        private System.Windows.Forms.ComboBox cmbColPlan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDebe;
        private System.Windows.Forms.Button btnFormulaTopeMax;
        private System.Windows.Forms.ComboBox cmbTopeMax;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox txtValorTopeMax;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnFormulaTopeMin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFormulaTopeMin;
        private System.Windows.Forms.ComboBox cmbTopeMin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnFormula;
        private System.Windows.Forms.CheckBox chkGeneracion;
        private System.Windows.Forms.MaskedTextBox txtValorTopeMin;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtFormula;
        private System.Windows.Forms.GroupBox grp2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFormulaTopeMax;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtHaber;
        private System.Windows.Forms.ComboBox cmbEstado;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox grp3;
        private System.Windows.Forms.GroupBox grp4;
        private System.Windows.Forms.CheckBox chkProy5taCat;
        private System.Windows.Forms.CheckBox chkDestajo;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.RadioButton radioButtonSi;
        private System.Windows.Forms.RadioButton radioButtonNo;
        private System.Windows.Forms.ComboBox cmbConceptoPdt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkQuinta;
        private System.Windows.Forms.CheckBox chkRemProm;
        private System.Windows.Forms.CheckBox chkCero;
        private System.Windows.Forms.CheckBox chkPresta;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBoxBuscar;
        private System.Windows.Forms.Label lblF2;
        private System.Windows.Forms.TextBox txtTipoAneDe;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtAneDe;
        private System.Windows.Forms.GroupBox grp5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtAneRefDe;
        private System.Windows.Forms.TextBox txtTipoAneRefDe;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtAneRefHa;
        private System.Windows.Forms.TextBox txtTipoAneRefHa;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtAneHa;
        private System.Windows.Forms.TextBox txtTipoAneHa;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox grp6;
        private System.Windows.Forms.CheckBox chkAsegurable;
    }
}