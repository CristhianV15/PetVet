﻿namespace CaniaBrava.Interface
{
    partial class ui_controllingagregaractiv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbdesrecurso = new System.Windows.Forms.ComboBox();
            this.cmbrecurso = new System.Windows.Forms.ComboBox();
            this.cmbrubro = new System.Windows.Forms.ComboBox();
            this.txtactividad = new System.Windows.Forms.TextBox();
            this.txtdesactividad = new System.Windows.Forms.TextBox();
            this.txtcuencon = new System.Windows.Forms.TextBox();
            this.txtdescuencon = new System.Windows.Forms.TextBox();
            this.txtcod = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdescod = new System.Windows.Forms.TextBox();
            this.lblAbrevia = new System.Windows.Forms.Label();
            this.cmbUM = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.toolStripForm = new System.Windows.Forms.ToolStrip();
            this.btnAceptar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnbuscar = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.toolStripForm.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnbuscar);
            this.groupBox2.Controls.Add(this.cmbdesrecurso);
            this.groupBox2.Controls.Add(this.cmbrecurso);
            this.groupBox2.Controls.Add(this.cmbrubro);
            this.groupBox2.Controls.Add(this.txtactividad);
            this.groupBox2.Controls.Add(this.txtdesactividad);
            this.groupBox2.Controls.Add(this.txtcuencon);
            this.groupBox2.Controls.Add(this.txtdescuencon);
            this.groupBox2.Controls.Add(this.txtcod);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtdescod);
            this.groupBox2.Controls.Add(this.lblAbrevia);
            this.groupBox2.Controls.Add(this.cmbUM);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtcodigo);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblEstado);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(585, 246);
            this.groupBox2.TabIndex = 83;
            this.groupBox2.TabStop = false;
            // 
            // cmbdesrecurso
            // 
            this.cmbdesrecurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbdesrecurso.FormattingEnabled = true;
            this.cmbdesrecurso.Location = new System.Drawing.Point(236, 195);
            this.cmbdesrecurso.MaxLength = 100;
            this.cmbdesrecurso.Name = "cmbdesrecurso";
            this.cmbdesrecurso.Size = new System.Drawing.Size(343, 21);
            this.cmbdesrecurso.Sorted = true;
            this.cmbdesrecurso.TabIndex = 101;
            this.cmbdesrecurso.SelectedIndexChanged += new System.EventHandler(this.cmbdesrecurso_SelectedIndexChanged);
            this.cmbdesrecurso.SelectionChangeCommitted += new System.EventHandler(this.cmbdesrecurso_SelectionChangeCommitted);
            // 
            // cmbrecurso
            // 
            this.cmbrecurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbrecurso.FormattingEnabled = true;
            this.cmbrecurso.Location = new System.Drawing.Point(134, 195);
            this.cmbrecurso.MaxLength = 2;
            this.cmbrecurso.Name = "cmbrecurso";
            this.cmbrecurso.Size = new System.Drawing.Size(96, 21);
            this.cmbrecurso.Sorted = true;
            this.cmbrecurso.TabIndex = 100;
            this.cmbrecurso.SelectionChangeCommitted += new System.EventHandler(this.cmbrecurso_SelectionChangeCommitted);
            // 
            // cmbrubro
            // 
            this.cmbrubro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbrubro.FormattingEnabled = true;
            this.cmbrubro.Location = new System.Drawing.Point(134, 136);
            this.cmbrubro.MaxLength = 3;
            this.cmbrubro.Name = "cmbrubro";
            this.cmbrubro.Size = new System.Drawing.Size(96, 21);
            this.cmbrubro.Sorted = true;
            this.cmbrubro.TabIndex = 99;
            // 
            // txtactividad
            // 
            this.txtactividad.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtactividad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtactividad.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtactividad.Location = new System.Drawing.Point(134, 168);
            this.txtactividad.MaxLength = 2;
            this.txtactividad.Name = "txtactividad";
            this.txtactividad.Size = new System.Drawing.Size(96, 18);
            this.txtactividad.TabIndex = 96;
            // 
            // txtdesactividad
            // 
            this.txtdesactividad.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtdesactividad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdesactividad.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdesactividad.Location = new System.Drawing.Point(236, 168);
            this.txtdesactividad.MaxLength = 100;
            this.txtdesactividad.Name = "txtdesactividad";
            this.txtdesactividad.Size = new System.Drawing.Size(343, 18);
            this.txtdesactividad.TabIndex = 95;
            // 
            // txtcuencon
            // 
            this.txtcuencon.BackColor = System.Drawing.SystemColors.Control;
            this.txtcuencon.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcuencon.Enabled = false;
            this.txtcuencon.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcuencon.Location = new System.Drawing.Point(134, 79);
            this.txtcuencon.MaxLength = 11;
            this.txtcuencon.Name = "txtcuencon";
            this.txtcuencon.Size = new System.Drawing.Size(96, 18);
            this.txtcuencon.TabIndex = 92;
            // 
            // txtdescuencon
            // 
            this.txtdescuencon.BackColor = System.Drawing.SystemColors.Control;
            this.txtdescuencon.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdescuencon.Enabled = false;
            this.txtdescuencon.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescuencon.Location = new System.Drawing.Point(236, 79);
            this.txtdescuencon.MaxLength = 100;
            this.txtdescuencon.Name = "txtdescuencon";
            this.txtdescuencon.Size = new System.Drawing.Size(309, 18);
            this.txtdescuencon.TabIndex = 91;
            // 
            // txtcod
            // 
            this.txtcod.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtcod.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcod.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcod.Location = new System.Drawing.Point(134, 17);
            this.txtcod.MaxLength = 100;
            this.txtcod.Name = "txtcod";
            this.txtcod.Size = new System.Drawing.Size(96, 18);
            this.txtcod.TabIndex = 90;
            this.txtcod.TextChanged += new System.EventHandler(this.txtcod_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 88;
            this.label5.Text = "Rubro : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 87;
            this.label4.Text = "Codigo : ";
            // 
            // txtdescod
            // 
            this.txtdescod.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtdescod.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdescod.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescod.Location = new System.Drawing.Point(236, 17);
            this.txtdescod.MaxLength = 150;
            this.txtdescod.Name = "txtdescod";
            this.txtdescod.Size = new System.Drawing.Size(343, 18);
            this.txtdescod.TabIndex = 83;
            // 
            // lblAbrevia
            // 
            this.lblAbrevia.AutoSize = true;
            this.lblAbrevia.Location = new System.Drawing.Point(6, 48);
            this.lblAbrevia.Name = "lblAbrevia";
            this.lblAbrevia.Size = new System.Drawing.Size(33, 13);
            this.lblAbrevia.TabIndex = 81;
            this.lblAbrevia.Text = "UM : ";
            // 
            // cmbUM
            // 
            this.cmbUM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUM.FormattingEnabled = true;
            this.cmbUM.Location = new System.Drawing.Point(134, 45);
            this.cmbUM.MaxLength = 5;
            this.cmbUM.Name = "cmbUM";
            this.cmbUM.Size = new System.Drawing.Size(96, 21);
            this.cmbUM.Sorted = true;
            this.cmbUM.TabIndex = 6;
            this.cmbUM.TextChanged += new System.EventHandler(this.cmbUM_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 77;
            this.label3.Text = "Actividad : ";
            // 
            // txtcodigo
            // 
            this.txtcodigo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcodigo.Enabled = false;
            this.txtcodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcodigo.Location = new System.Drawing.Point(134, 109);
            this.txtcodigo.MaxLength = 20;
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.ReadOnly = true;
            this.txtcodigo.Size = new System.Drawing.Size(445, 18);
            this.txtcodigo.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 75;
            this.label2.Text = "COD : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 73;
            this.label1.Text = "Cuenta Contable : ";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(6, 201);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(56, 13);
            this.lblEstado.TabIndex = 65;
            this.lblEstado.Text = "Recurso : ";
            // 
            // toolStripForm
            // 
            this.toolStripForm.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripForm.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStripForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAceptar,
            this.btnCancelar});
            this.toolStripForm.Location = new System.Drawing.Point(0, 263);
            this.toolStripForm.Name = "toolStripForm";
            this.toolStripForm.ShowItemToolTips = false;
            this.toolStripForm.Size = new System.Drawing.Size(609, 25);
            this.toolStripForm.TabIndex = 84;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Image = global::CaniaBrava.Properties.Resources.SAVE;
            this.btnAceptar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(68, 22);
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = global::CaniaBrava.Properties.Resources.UNDO;
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(73, 22);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnbuscar
            // 
            this.btnbuscar.Image = global::CaniaBrava.Properties.Resources.LOCATE;
            this.btnbuscar.Location = new System.Drawing.Point(551, 76);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(28, 23);
            this.btnbuscar.TabIndex = 102;
            this.btnbuscar.UseVisualStyleBackColor = true;
            this.btnbuscar.Click += new System.EventHandler(this.btnbuscar_Click);
            // 
            // ui_controllingagregaractiv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 288);
            this.Controls.Add(this.toolStripForm);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ui_controllingagregaractiv";
            this.Text = "Ingreso de Actividades";
            this.Load += new System.EventHandler(this.ui_controllingagregaractiv_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.toolStripForm.ResumeLayout(false);
            this.toolStripForm.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdescod;
        private System.Windows.Forms.Label lblAbrevia;
        private System.Windows.Forms.ComboBox cmbUM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcodigo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.ToolStrip toolStripForm;
        private System.Windows.Forms.ToolStripButton btnAceptar;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.TextBox txtactividad;
        private System.Windows.Forms.TextBox txtdesactividad;
        private System.Windows.Forms.TextBox txtcuencon;
        private System.Windows.Forms.TextBox txtdescuencon;
        private System.Windows.Forms.TextBox txtcod;
        private System.Windows.Forms.ComboBox cmbrubro;
        private System.Windows.Forms.ComboBox cmbdesrecurso;
        private System.Windows.Forms.ComboBox cmbrecurso;
        private System.Windows.Forms.Button btnbuscar;
    }
}