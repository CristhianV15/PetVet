﻿namespace CaniaBrava
{
    partial class ui_asgHorUpd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIdTipHor = new System.Windows.Forms.TextBox();
            this.grNormal = new System.Windows.Forms.GroupBox();
            this.lbl_Do = new System.Windows.Forms.Label();
            this.lbl_Sa = new System.Windows.Forms.Label();
            this.lbl_Vi = new System.Windows.Forms.Label();
            this.lbl_Ju = new System.Windows.Forms.Label();
            this.lbl_Mi = new System.Windows.Forms.Label();
            this.lbl_Ma = new System.Windows.Forms.Label();
            this.lbl_Lu = new System.Windows.Forms.Label();
            this.dtpDo2 = new System.Windows.Forms.DateTimePicker();
            this.dtpSa2 = new System.Windows.Forms.DateTimePicker();
            this.dtpVi2 = new System.Windows.Forms.DateTimePicker();
            this.dtpJu2 = new System.Windows.Forms.DateTimePicker();
            this.dtpMi2 = new System.Windows.Forms.DateTimePicker();
            this.dtpMa2 = new System.Windows.Forms.DateTimePicker();
            this.dtpLu2 = new System.Windows.Forms.DateTimePicker();
            this.dtpDo1 = new System.Windows.Forms.DateTimePicker();
            this.dtpSa1 = new System.Windows.Forms.DateTimePicker();
            this.dtpVi1 = new System.Windows.Forms.DateTimePicker();
            this.dtpJu1 = new System.Windows.Forms.DateTimePicker();
            this.dtpMi1 = new System.Windows.Forms.DateTimePicker();
            this.dtpMa1 = new System.Windows.Forms.DateTimePicker();
            this.dtpLu1 = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.chkJu = new System.Windows.Forms.CheckBox();
            this.chkDo = new System.Windows.Forms.CheckBox();
            this.chkSa = new System.Windows.Forms.CheckBox();
            this.chkVi = new System.Windows.Forms.CheckBox();
            this.chkMi = new System.Windows.Forms.CheckBox();
            this.chkMa = new System.Windows.Forms.CheckBox();
            this.chkLu = new System.Windows.Forms.CheckBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.btnAsignar = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNameTipHor = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chkListNominas = new System.Windows.Forms.CheckedListBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.grTipo = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rdRotativo = new System.Windows.Forms.RadioButton();
            this.rdNormal = new System.Windows.Forms.RadioButton();
            this.grNormal.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grTipo.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtIdTipHor
            // 
            this.txtIdTipHor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtIdTipHor.Location = new System.Drawing.Point(84, 19);
            this.txtIdTipHor.MaxLength = 3;
            this.txtIdTipHor.Name = "txtIdTipHor";
            this.txtIdTipHor.Size = new System.Drawing.Size(40, 20);
            this.txtIdTipHor.TabIndex = 1;
            this.txtIdTipHor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdTipHor_KeyPress);
            // 
            // grNormal
            // 
            this.grNormal.Controls.Add(this.lbl_Do);
            this.grNormal.Controls.Add(this.lbl_Sa);
            this.grNormal.Controls.Add(this.lbl_Vi);
            this.grNormal.Controls.Add(this.lbl_Ju);
            this.grNormal.Controls.Add(this.lbl_Mi);
            this.grNormal.Controls.Add(this.lbl_Ma);
            this.grNormal.Controls.Add(this.lbl_Lu);
            this.grNormal.Controls.Add(this.dtpDo2);
            this.grNormal.Controls.Add(this.dtpSa2);
            this.grNormal.Controls.Add(this.dtpVi2);
            this.grNormal.Controls.Add(this.dtpJu2);
            this.grNormal.Controls.Add(this.dtpMi2);
            this.grNormal.Controls.Add(this.dtpMa2);
            this.grNormal.Controls.Add(this.dtpLu2);
            this.grNormal.Controls.Add(this.dtpDo1);
            this.grNormal.Controls.Add(this.dtpSa1);
            this.grNormal.Controls.Add(this.dtpVi1);
            this.grNormal.Controls.Add(this.dtpJu1);
            this.grNormal.Controls.Add(this.dtpMi1);
            this.grNormal.Controls.Add(this.dtpMa1);
            this.grNormal.Controls.Add(this.dtpLu1);
            this.grNormal.Controls.Add(this.label19);
            this.grNormal.Controls.Add(this.label18);
            this.grNormal.Controls.Add(this.chkJu);
            this.grNormal.Controls.Add(this.chkDo);
            this.grNormal.Controls.Add(this.chkSa);
            this.grNormal.Controls.Add(this.chkVi);
            this.grNormal.Controls.Add(this.chkMi);
            this.grNormal.Controls.Add(this.chkMa);
            this.grNormal.Controls.Add(this.chkLu);
            this.grNormal.Controls.Add(this.chkAll);
            this.grNormal.Location = new System.Drawing.Point(12, 157);
            this.grNormal.Name = "grNormal";
            this.grNormal.Size = new System.Drawing.Size(487, 208);
            this.grNormal.TabIndex = 119;
            this.grNormal.TabStop = false;
            // 
            // lbl_Do
            // 
            this.lbl_Do.AutoSize = true;
            this.lbl_Do.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Do.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Do.ForeColor = System.Drawing.Color.White;
            this.lbl_Do.Location = new System.Drawing.Point(336, 184);
            this.lbl_Do.Name = "lbl_Do";
            this.lbl_Do.Size = new System.Drawing.Size(0, 13);
            this.lbl_Do.TabIndex = 112;
            // 
            // lbl_Sa
            // 
            this.lbl_Sa.AutoSize = true;
            this.lbl_Sa.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Sa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sa.ForeColor = System.Drawing.Color.White;
            this.lbl_Sa.Location = new System.Drawing.Point(336, 161);
            this.lbl_Sa.Name = "lbl_Sa";
            this.lbl_Sa.Size = new System.Drawing.Size(0, 13);
            this.lbl_Sa.TabIndex = 111;
            // 
            // lbl_Vi
            // 
            this.lbl_Vi.AutoSize = true;
            this.lbl_Vi.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Vi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vi.ForeColor = System.Drawing.Color.White;
            this.lbl_Vi.Location = new System.Drawing.Point(336, 138);
            this.lbl_Vi.Name = "lbl_Vi";
            this.lbl_Vi.Size = new System.Drawing.Size(0, 13);
            this.lbl_Vi.TabIndex = 110;
            // 
            // lbl_Ju
            // 
            this.lbl_Ju.AutoSize = true;
            this.lbl_Ju.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Ju.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ju.ForeColor = System.Drawing.Color.White;
            this.lbl_Ju.Location = new System.Drawing.Point(336, 115);
            this.lbl_Ju.Name = "lbl_Ju";
            this.lbl_Ju.Size = new System.Drawing.Size(0, 13);
            this.lbl_Ju.TabIndex = 109;
            // 
            // lbl_Mi
            // 
            this.lbl_Mi.AutoSize = true;
            this.lbl_Mi.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mi.ForeColor = System.Drawing.Color.White;
            this.lbl_Mi.Location = new System.Drawing.Point(336, 92);
            this.lbl_Mi.Name = "lbl_Mi";
            this.lbl_Mi.Size = new System.Drawing.Size(0, 13);
            this.lbl_Mi.TabIndex = 108;
            // 
            // lbl_Ma
            // 
            this.lbl_Ma.AutoSize = true;
            this.lbl_Ma.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Ma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ma.ForeColor = System.Drawing.Color.White;
            this.lbl_Ma.Location = new System.Drawing.Point(336, 69);
            this.lbl_Ma.Name = "lbl_Ma";
            this.lbl_Ma.Size = new System.Drawing.Size(0, 13);
            this.lbl_Ma.TabIndex = 107;
            // 
            // lbl_Lu
            // 
            this.lbl_Lu.AutoSize = true;
            this.lbl_Lu.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Lu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lu.ForeColor = System.Drawing.Color.White;
            this.lbl_Lu.Location = new System.Drawing.Point(336, 46);
            this.lbl_Lu.Name = "lbl_Lu";
            this.lbl_Lu.Size = new System.Drawing.Size(0, 13);
            this.lbl_Lu.TabIndex = 106;
            // 
            // dtpDo2
            // 
            this.dtpDo2.CustomFormat = "HH:mm";
            this.dtpDo2.Enabled = false;
            this.dtpDo2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDo2.Location = new System.Drawing.Point(255, 180);
            this.dtpDo2.Name = "dtpDo2";
            this.dtpDo2.ShowUpDown = true;
            this.dtpDo2.Size = new System.Drawing.Size(56, 20);
            this.dtpDo2.TabIndex = 24;
            this.dtpDo2.ValueChanged += new System.EventHandler(this.dtpDo2_ValueChanged);
            // 
            // dtpSa2
            // 
            this.dtpSa2.CustomFormat = "HH:mm";
            this.dtpSa2.Enabled = false;
            this.dtpSa2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSa2.Location = new System.Drawing.Point(255, 157);
            this.dtpSa2.Name = "dtpSa2";
            this.dtpSa2.ShowUpDown = true;
            this.dtpSa2.Size = new System.Drawing.Size(56, 20);
            this.dtpSa2.TabIndex = 21;
            this.dtpSa2.ValueChanged += new System.EventHandler(this.dtpSa2_ValueChanged);
            // 
            // dtpVi2
            // 
            this.dtpVi2.CustomFormat = "HH:mm";
            this.dtpVi2.Enabled = false;
            this.dtpVi2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpVi2.Location = new System.Drawing.Point(255, 134);
            this.dtpVi2.Name = "dtpVi2";
            this.dtpVi2.ShowUpDown = true;
            this.dtpVi2.Size = new System.Drawing.Size(56, 20);
            this.dtpVi2.TabIndex = 18;
            this.dtpVi2.ValueChanged += new System.EventHandler(this.dtpVi2_ValueChanged);
            // 
            // dtpJu2
            // 
            this.dtpJu2.CustomFormat = "HH:mm";
            this.dtpJu2.Enabled = false;
            this.dtpJu2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpJu2.Location = new System.Drawing.Point(255, 111);
            this.dtpJu2.Name = "dtpJu2";
            this.dtpJu2.ShowUpDown = true;
            this.dtpJu2.Size = new System.Drawing.Size(56, 20);
            this.dtpJu2.TabIndex = 15;
            this.dtpJu2.ValueChanged += new System.EventHandler(this.dtpJu2_ValueChanged);
            // 
            // dtpMi2
            // 
            this.dtpMi2.CustomFormat = "HH:mm";
            this.dtpMi2.Enabled = false;
            this.dtpMi2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpMi2.Location = new System.Drawing.Point(255, 88);
            this.dtpMi2.Name = "dtpMi2";
            this.dtpMi2.ShowUpDown = true;
            this.dtpMi2.Size = new System.Drawing.Size(56, 20);
            this.dtpMi2.TabIndex = 12;
            this.dtpMi2.ValueChanged += new System.EventHandler(this.dtpMi2_ValueChanged);
            // 
            // dtpMa2
            // 
            this.dtpMa2.CustomFormat = "HH:mm";
            this.dtpMa2.Enabled = false;
            this.dtpMa2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpMa2.Location = new System.Drawing.Point(255, 65);
            this.dtpMa2.Name = "dtpMa2";
            this.dtpMa2.ShowUpDown = true;
            this.dtpMa2.Size = new System.Drawing.Size(56, 20);
            this.dtpMa2.TabIndex = 9;
            this.dtpMa2.ValueChanged += new System.EventHandler(this.dtpMa2_ValueChanged);
            // 
            // dtpLu2
            // 
            this.dtpLu2.CustomFormat = "HH:mm";
            this.dtpLu2.Enabled = false;
            this.dtpLu2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLu2.Location = new System.Drawing.Point(255, 42);
            this.dtpLu2.Name = "dtpLu2";
            this.dtpLu2.ShowUpDown = true;
            this.dtpLu2.Size = new System.Drawing.Size(56, 20);
            this.dtpLu2.TabIndex = 6;
            this.dtpLu2.ValueChanged += new System.EventHandler(this.dtpLu2_ValueChanged);
            // 
            // dtpDo1
            // 
            this.dtpDo1.CustomFormat = "HH:mm";
            this.dtpDo1.Enabled = false;
            this.dtpDo1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDo1.Location = new System.Drawing.Point(149, 180);
            this.dtpDo1.Name = "dtpDo1";
            this.dtpDo1.ShowUpDown = true;
            this.dtpDo1.Size = new System.Drawing.Size(56, 20);
            this.dtpDo1.TabIndex = 23;
            this.dtpDo1.ValueChanged += new System.EventHandler(this.dtpDo1_ValueChanged);
            // 
            // dtpSa1
            // 
            this.dtpSa1.CustomFormat = "HH:mm";
            this.dtpSa1.Enabled = false;
            this.dtpSa1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSa1.Location = new System.Drawing.Point(149, 157);
            this.dtpSa1.Name = "dtpSa1";
            this.dtpSa1.ShowUpDown = true;
            this.dtpSa1.Size = new System.Drawing.Size(56, 20);
            this.dtpSa1.TabIndex = 20;
            this.dtpSa1.ValueChanged += new System.EventHandler(this.dtpSa1_ValueChanged);
            // 
            // dtpVi1
            // 
            this.dtpVi1.CustomFormat = "HH:mm";
            this.dtpVi1.Enabled = false;
            this.dtpVi1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpVi1.Location = new System.Drawing.Point(149, 134);
            this.dtpVi1.Name = "dtpVi1";
            this.dtpVi1.ShowUpDown = true;
            this.dtpVi1.Size = new System.Drawing.Size(56, 20);
            this.dtpVi1.TabIndex = 17;
            this.dtpVi1.ValueChanged += new System.EventHandler(this.dtpVi1_ValueChanged);
            // 
            // dtpJu1
            // 
            this.dtpJu1.CustomFormat = "HH:mm";
            this.dtpJu1.Enabled = false;
            this.dtpJu1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpJu1.Location = new System.Drawing.Point(149, 111);
            this.dtpJu1.Name = "dtpJu1";
            this.dtpJu1.ShowUpDown = true;
            this.dtpJu1.Size = new System.Drawing.Size(56, 20);
            this.dtpJu1.TabIndex = 14;
            this.dtpJu1.ValueChanged += new System.EventHandler(this.dtpJu1_ValueChanged);
            // 
            // dtpMi1
            // 
            this.dtpMi1.CustomFormat = "HH:mm";
            this.dtpMi1.Enabled = false;
            this.dtpMi1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpMi1.Location = new System.Drawing.Point(149, 88);
            this.dtpMi1.Name = "dtpMi1";
            this.dtpMi1.ShowUpDown = true;
            this.dtpMi1.Size = new System.Drawing.Size(56, 20);
            this.dtpMi1.TabIndex = 11;
            this.dtpMi1.ValueChanged += new System.EventHandler(this.dtpMi1_ValueChanged);
            // 
            // dtpMa1
            // 
            this.dtpMa1.CustomFormat = "HH:mm";
            this.dtpMa1.Enabled = false;
            this.dtpMa1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpMa1.Location = new System.Drawing.Point(149, 65);
            this.dtpMa1.Name = "dtpMa1";
            this.dtpMa1.ShowUpDown = true;
            this.dtpMa1.Size = new System.Drawing.Size(56, 20);
            this.dtpMa1.TabIndex = 8;
            this.dtpMa1.ValueChanged += new System.EventHandler(this.dtpMa1_ValueChanged);
            // 
            // dtpLu1
            // 
            this.dtpLu1.CustomFormat = "HH:mm";
            this.dtpLu1.Enabled = false;
            this.dtpLu1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLu1.Location = new System.Drawing.Point(149, 42);
            this.dtpLu1.Name = "dtpLu1";
            this.dtpLu1.ShowUpDown = true;
            this.dtpLu1.Size = new System.Drawing.Size(56, 20);
            this.dtpLu1.TabIndex = 5;
            this.dtpLu1.ValueChanged += new System.EventHandler(this.dtpLu1_ValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(258, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 13);
            this.label19.TabIndex = 82;
            this.label19.Text = "Salida";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(152, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 13);
            this.label18.TabIndex = 74;
            this.label18.Text = "Entrada";
            // 
            // chkJu
            // 
            this.chkJu.AutoSize = true;
            this.chkJu.Location = new System.Drawing.Point(14, 111);
            this.chkJu.Name = "chkJu";
            this.chkJu.Size = new System.Drawing.Size(60, 17);
            this.chkJu.TabIndex = 13;
            this.chkJu.Text = "Jueves";
            this.chkJu.UseVisualStyleBackColor = true;
            this.chkJu.Click += new System.EventHandler(this.chkJu_Click);
            // 
            // chkDo
            // 
            this.chkDo.AutoSize = true;
            this.chkDo.Location = new System.Drawing.Point(14, 180);
            this.chkDo.Name = "chkDo";
            this.chkDo.Size = new System.Drawing.Size(68, 17);
            this.chkDo.TabIndex = 22;
            this.chkDo.Text = "Domingo";
            this.chkDo.UseVisualStyleBackColor = true;
            this.chkDo.Click += new System.EventHandler(this.chkDo_Click);
            // 
            // chkSa
            // 
            this.chkSa.AutoSize = true;
            this.chkSa.Location = new System.Drawing.Point(14, 157);
            this.chkSa.Name = "chkSa";
            this.chkSa.Size = new System.Drawing.Size(63, 17);
            this.chkSa.TabIndex = 19;
            this.chkSa.Text = "Sabado";
            this.chkSa.UseVisualStyleBackColor = true;
            this.chkSa.Click += new System.EventHandler(this.chkSa_Click);
            // 
            // chkVi
            // 
            this.chkVi.AutoSize = true;
            this.chkVi.Location = new System.Drawing.Point(14, 134);
            this.chkVi.Name = "chkVi";
            this.chkVi.Size = new System.Drawing.Size(61, 17);
            this.chkVi.TabIndex = 16;
            this.chkVi.Text = "Viernes";
            this.chkVi.UseVisualStyleBackColor = true;
            this.chkVi.Click += new System.EventHandler(this.chkVi_Click);
            // 
            // chkMi
            // 
            this.chkMi.AutoSize = true;
            this.chkMi.Location = new System.Drawing.Point(14, 88);
            this.chkMi.Name = "chkMi";
            this.chkMi.Size = new System.Drawing.Size(71, 17);
            this.chkMi.TabIndex = 10;
            this.chkMi.Text = "Miercoles";
            this.chkMi.UseVisualStyleBackColor = true;
            this.chkMi.Click += new System.EventHandler(this.chkMi_Click);
            // 
            // chkMa
            // 
            this.chkMa.AutoSize = true;
            this.chkMa.Location = new System.Drawing.Point(14, 65);
            this.chkMa.Name = "chkMa";
            this.chkMa.Size = new System.Drawing.Size(58, 17);
            this.chkMa.TabIndex = 7;
            this.chkMa.Text = "Martes";
            this.chkMa.UseVisualStyleBackColor = true;
            this.chkMa.Click += new System.EventHandler(this.chkMa_Click);
            // 
            // chkLu
            // 
            this.chkLu.AutoSize = true;
            this.chkLu.Location = new System.Drawing.Point(14, 42);
            this.chkLu.Name = "chkLu";
            this.chkLu.Size = new System.Drawing.Size(55, 17);
            this.chkLu.TabIndex = 4;
            this.chkLu.Text = "Lunes";
            this.chkLu.UseVisualStyleBackColor = true;
            this.chkLu.Click += new System.EventHandler(this.chkLu_Click);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAll.Location = new System.Drawing.Point(13, 19);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(61, 17);
            this.chkAll.TabIndex = 3;
            this.chkAll.Text = "Todos";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.Click += new System.EventHandler(this.chkAll_Click);
            // 
            // btnAsignar
            // 
            this.btnAsignar.Image = global::CaniaBrava.Properties.Resources.SAVE;
            this.btnAsignar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAsignar.Location = new System.Drawing.Point(313, 371);
            this.btnAsignar.Name = "btnAsignar";
            this.btnAsignar.Size = new System.Drawing.Size(90, 26);
            this.btnAsignar.TabIndex = 25;
            this.btnAsignar.Text = "       Grabar";
            this.btnAsignar.UseVisualStyleBackColor = true;
            this.btnAsignar.Click += new System.EventHandler(this.btnAsignar_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtIdTipHor);
            this.groupBox3.Controls.Add(this.txtNameTipHor);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(12, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(327, 97);
            this.groupBox3.TabIndex = 118;
            this.groupBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(5, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 32);
            this.label3.TabIndex = 122;
            this.label3.Text = "(max. 60 caracteres)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 121;
            this.label1.Text = "Descripcion  :";
            // 
            // txtNameTipHor
            // 
            this.txtNameTipHor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNameTipHor.Location = new System.Drawing.Point(84, 46);
            this.txtNameTipHor.MaxLength = 60;
            this.txtNameTipHor.Multiline = true;
            this.txtNameTipHor.Name = "txtNameTipHor";
            this.txtNameTipHor.Size = new System.Drawing.Size(233, 41);
            this.txtNameTipHor.TabIndex = 2;
            this.txtNameTipHor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNameTipHor_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Codigo  :";
            // 
            // chkListNominas
            // 
            this.chkListNominas.FormattingEnabled = true;
            this.chkListNominas.Location = new System.Drawing.Point(345, 12);
            this.chkListNominas.Name = "chkListNominas";
            this.chkListNominas.Size = new System.Drawing.Size(154, 139);
            this.chkListNominas.TabIndex = 120;
            // 
            // btnSalir
            // 
            this.btnSalir.Image = global::CaniaBrava.Properties.Resources.CLOSE;
            this.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalir.Location = new System.Drawing.Point(409, 371);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(90, 26);
            this.btnSalir.TabIndex = 121;
            this.btnSalir.Text = "   Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // grTipo
            // 
            this.grTipo.Controls.Add(this.label2);
            this.grTipo.Controls.Add(this.rdRotativo);
            this.grTipo.Controls.Add(this.rdNormal);
            this.grTipo.Location = new System.Drawing.Point(12, 109);
            this.grTipo.Name = "grTipo";
            this.grTipo.Size = new System.Drawing.Size(327, 42);
            this.grTipo.TabIndex = 122;
            this.grTipo.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tipo  :";
            // 
            // rdRotativo
            // 
            this.rdRotativo.AutoSize = true;
            this.rdRotativo.Location = new System.Drawing.Point(147, 16);
            this.rdRotativo.Name = "rdRotativo";
            this.rdRotativo.Size = new System.Drawing.Size(65, 17);
            this.rdRotativo.TabIndex = 1;
            this.rdRotativo.Text = "Rotativo";
            this.rdRotativo.UseVisualStyleBackColor = true;
            this.rdRotativo.CheckedChanged += new System.EventHandler(this.rdRotativo_CheckedChanged);
            // 
            // rdNormal
            // 
            this.rdNormal.AutoSize = true;
            this.rdNormal.Checked = true;
            this.rdNormal.Location = new System.Drawing.Point(83, 16);
            this.rdNormal.Name = "rdNormal";
            this.rdNormal.Size = new System.Drawing.Size(58, 17);
            this.rdNormal.TabIndex = 0;
            this.rdNormal.TabStop = true;
            this.rdNormal.Text = "Normal";
            this.rdNormal.UseVisualStyleBackColor = true;
            this.rdNormal.CheckedChanged += new System.EventHandler(this.rdNormal_CheckedChanged);
            // 
            // ui_asgHorUpd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 403);
            this.Controls.Add(this.grTipo);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.chkListNominas);
            this.Controls.Add(this.grNormal);
            this.Controls.Add(this.btnAsignar);
            this.Controls.Add(this.groupBox3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(524, 442);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(524, 442);
            this.Name = "ui_asgHorUpd";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tipo de Horario";
            this.grNormal.ResumeLayout(false);
            this.grNormal.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grTipo.ResumeLayout(false);
            this.grTipo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtIdTipHor;
        private System.Windows.Forms.GroupBox grNormal;
        private System.Windows.Forms.DateTimePicker dtpDo2;
        private System.Windows.Forms.DateTimePicker dtpSa2;
        private System.Windows.Forms.DateTimePicker dtpVi2;
        private System.Windows.Forms.DateTimePicker dtpJu2;
        private System.Windows.Forms.DateTimePicker dtpMi2;
        private System.Windows.Forms.DateTimePicker dtpMa2;
        private System.Windows.Forms.DateTimePicker dtpLu2;
        private System.Windows.Forms.DateTimePicker dtpDo1;
        private System.Windows.Forms.DateTimePicker dtpSa1;
        private System.Windows.Forms.DateTimePicker dtpVi1;
        private System.Windows.Forms.DateTimePicker dtpJu1;
        private System.Windows.Forms.DateTimePicker dtpMi1;
        private System.Windows.Forms.DateTimePicker dtpMa1;
        private System.Windows.Forms.DateTimePicker dtpLu1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox chkJu;
        private System.Windows.Forms.CheckBox chkDo;
        private System.Windows.Forms.CheckBox chkSa;
        private System.Windows.Forms.CheckBox chkVi;
        private System.Windows.Forms.CheckBox chkMi;
        private System.Windows.Forms.CheckBox chkMa;
        private System.Windows.Forms.CheckBox chkLu;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.Button btnAsignar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtNameTipHor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_Do;
        private System.Windows.Forms.Label lbl_Sa;
        private System.Windows.Forms.Label lbl_Vi;
        private System.Windows.Forms.Label lbl_Ju;
        private System.Windows.Forms.Label lbl_Mi;
        private System.Windows.Forms.Label lbl_Ma;
        private System.Windows.Forms.Label lbl_Lu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox chkListNominas;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.GroupBox grTipo;
        private System.Windows.Forms.RadioButton rdRotativo;
        private System.Windows.Forms.RadioButton rdNormal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}