﻿namespace CaniaBrava.Interface
{
    partial class ui_atraccion_seleccion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlPer = new Dotnetrix.Controls.TabControlEX();
            this.tabPageEX1 = new Dotnetrix.Controls.TabPageEX();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.txtreferencia = new System.Windows.Forms.TextBox();
            this.txtdepartamento = new System.Windows.Forms.TextBox();
            this.txtdistrito = new System.Windows.Forms.TextBox();
            this.txtprovincia = new System.Windows.Forms.TextBox();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.cmbNivelEducativo = new System.Windows.Forms.ComboBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.cmbSexo = new System.Windows.Forms.ComboBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.txtidmax = new System.Windows.Forms.TextBox();
            this.txtregistro = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtcodempleado = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbCategoriaBrevete = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNroLicenciaConductor = new System.Windows.Forms.TextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.cmbEstadoCivil = new System.Windows.Forms.ComboBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.cmbNacionalidad = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.txtTelFijo = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.txtFechaNac = new System.Windows.Forms.DateTimePicker();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.txtNombres = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.txtNroDoc = new System.Windows.Forms.TextBox();
            this.cmbTipoDocumento = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.tabPageEX3 = new Dotnetrix.Controls.TabPageEX();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cmbsede = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtnomsoc = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbPosicion = new System.Windows.Forms.ComboBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.cmbnivorganizacional = new System.Windows.Forms.ComboBox();
            this.groupBox58 = new System.Windows.Forms.GroupBox();
            this.txtjefatura = new System.Windows.Forms.TextBox();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.cmbGerencia = new System.Windows.Forms.ComboBox();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.cmbunidorg = new System.Windows.Forms.ComboBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.cmbsoc = new System.Windows.Forms.ComboBox();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.txtrrhh = new System.Windows.Forms.TextBox();
            this.tabPageEX11 = new Dotnetrix.Controls.TabPageEX();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.txtcomentarios = new System.Windows.Forms.TextBox();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.txtsatisfaccion = new System.Windows.Forms.TextBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.txtnrolistenvi = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbdInduccionSI = new System.Windows.Forms.RadioButton();
            this.rbdInduccionNo = new System.Windows.Forms.RadioButton();
            this.groupBox57 = new System.Windows.Forms.GroupBox();
            this.rdbcartaSi = new System.Windows.Forms.RadioButton();
            this.rdbcartaNo = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.cmbestatusocupacion = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.cmbestadoproceso = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtproveedor = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.cmbtipocontrato = new System.Windows.Forms.ComboBox();
            this.cmbmodalidad = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.cmbmedioate = new System.Windows.Forms.ComboBox();
            this.cmbtipoproceso = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtfuentepostulacion = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.txtcantevaluados = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.cmborigen = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtreemplazo = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.cmbprioridad = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtvacantes = new System.Windows.Forms.TextBox();
            this.tabPageEX5 = new Dotnetrix.Controls.TabPageEX();
            this.tabPlame = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.txttotaldias = new System.Windows.Forms.TextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.txtfecierre = new System.Windows.Forms.DateTimePicker();
            this.txtfeestimacion = new System.Windows.Forms.DateTimePicker();
            this.txtfeinicioproceso = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtfeincorporacion = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolstripform = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.excel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSalir = new System.Windows.Forms.ToolStripButton();
            this.tabControlPer.SuspendLayout();
            this.tabPageEX1.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.tabPageEX3.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.groupBox58.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tabPageEX11.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox57.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPageEX5.SuspendLayout();
            this.tabPlame.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.toolstripform.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlPer
            // 
            this.tabControlPer.Controls.Add(this.tabPageEX1);
            this.tabControlPer.Controls.Add(this.tabPageEX3);
            this.tabControlPer.Controls.Add(this.tabPageEX11);
            this.tabControlPer.Controls.Add(this.tabPageEX5);
            this.tabControlPer.Enabled = false;
            this.tabControlPer.Location = new System.Drawing.Point(21, 50);
            this.tabControlPer.Name = "tabControlPer";
            this.tabControlPer.SelectedIndex = 0;
            this.tabControlPer.SelectedTabColor = System.Drawing.SystemColors.HighlightText;
            this.tabControlPer.SelectedTabFontStyle = System.Drawing.FontStyle.Regular;
            this.tabControlPer.Size = new System.Drawing.Size(785, 620);
            this.tabControlPer.TabColor = System.Drawing.SystemColors.HighlightText;
            this.tabControlPer.TabIndex = 10;
            this.tabControlPer.UseVisualStyles = false;
            // 
            // tabPageEX1
            // 
            this.tabPageEX1.Controls.Add(this.groupBox37);
            this.tabPageEX1.Controls.Add(this.groupBox34);
            this.tabPageEX1.Controls.Add(this.groupBox11);
            this.tabPageEX1.Controls.Add(this.groupBox20);
            this.tabPageEX1.Controls.Add(this.groupBox21);
            this.tabPageEX1.Controls.Add(this.groupBox22);
            this.tabPageEX1.Controls.Add(this.groupBox24);
            this.tabPageEX1.Controls.Add(this.groupBox25);
            this.tabPageEX1.Controls.Add(this.groupBox26);
            this.tabPageEX1.Controls.Add(this.groupBox27);
            this.tabPageEX1.Controls.Add(this.groupBox28);
            this.tabPageEX1.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX1.Name = "tabPageEX1";
            this.tabPageEX1.Size = new System.Drawing.Size(777, 591);
            this.tabPageEX1.TabIndex = 0;
            this.tabPageEX1.Text = "Datos Personales";
            this.tabPageEX1.Click += new System.EventHandler(this.tabPageEX1_Click);
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.label4);
            this.groupBox37.Controls.Add(this.label3);
            this.groupBox37.Controls.Add(this.label2);
            this.groupBox37.Controls.Add(this.button5);
            this.groupBox37.Controls.Add(this.txtreferencia);
            this.groupBox37.Controls.Add(this.txtdepartamento);
            this.groupBox37.Controls.Add(this.txtdistrito);
            this.groupBox37.Controls.Add(this.txtprovincia);
            this.groupBox37.Location = new System.Drawing.Point(30, 440);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(680, 132);
            this.groupBox37.TabIndex = 73;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Direcciòn";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(464, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 55;
            this.label4.Text = "Departamento :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(225, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 54;
            this.label3.Text = "Provincia :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Distrito :";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(16, 88);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(93, 23);
            this.button5.TabIndex = 53;
            this.button5.Text = "Referencia";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // txtreferencia
            // 
            this.txtreferencia.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtreferencia.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtreferencia.Location = new System.Drawing.Point(115, 90);
            this.txtreferencia.MaxLength = 50;
            this.txtreferencia.Name = "txtreferencia";
            this.txtreferencia.Size = new System.Drawing.Size(550, 20);
            this.txtreferencia.TabIndex = 52;
            // 
            // txtdepartamento
            // 
            this.txtdepartamento.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtdepartamento.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdepartamento.Location = new System.Drawing.Point(461, 50);
            this.txtdepartamento.MaxLength = 50;
            this.txtdepartamento.Name = "txtdepartamento";
            this.txtdepartamento.Size = new System.Drawing.Size(204, 20);
            this.txtdepartamento.TabIndex = 50;
            // 
            // txtdistrito
            // 
            this.txtdistrito.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtdistrito.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdistrito.Location = new System.Drawing.Point(16, 50);
            this.txtdistrito.MaxLength = 50;
            this.txtdistrito.Name = "txtdistrito";
            this.txtdistrito.Size = new System.Drawing.Size(191, 20);
            this.txtdistrito.TabIndex = 46;
            // 
            // txtprovincia
            // 
            this.txtprovincia.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtprovincia.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtprovincia.Location = new System.Drawing.Point(222, 50);
            this.txtprovincia.MaxLength = 50;
            this.txtprovincia.Name = "txtprovincia";
            this.txtprovincia.Size = new System.Drawing.Size(218, 20);
            this.txtprovincia.TabIndex = 46;
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.cmbNivelEducativo);
            this.groupBox34.Location = new System.Drawing.Point(29, 113);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(492, 59);
            this.groupBox34.TabIndex = 72;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "Nivel Educativo";
            // 
            // cmbNivelEducativo
            // 
            this.cmbNivelEducativo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNivelEducativo.DropDownWidth = 450;
            this.cmbNivelEducativo.FormattingEnabled = true;
            this.cmbNivelEducativo.Location = new System.Drawing.Point(13, 17);
            this.cmbNivelEducativo.Name = "cmbNivelEducativo";
            this.cmbNivelEducativo.Size = new System.Drawing.Size(473, 21);
            this.cmbNivelEducativo.TabIndex = 0;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.cmbSexo);
            this.groupBox11.Location = new System.Drawing.Point(540, 178);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(170, 58);
            this.groupBox11.TabIndex = 54;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Sexo";
            // 
            // cmbSexo
            // 
            this.cmbSexo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSexo.FormattingEnabled = true;
            this.cmbSexo.Location = new System.Drawing.Point(16, 23);
            this.cmbSexo.Name = "cmbSexo";
            this.cmbSexo.Size = new System.Drawing.Size(139, 21);
            this.cmbSexo.TabIndex = 0;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.txtidmax);
            this.groupBox20.Controls.Add(this.txtregistro);
            this.groupBox20.Controls.Add(this.label8);
            this.groupBox20.Controls.Add(this.txtcodempleado);
            this.groupBox20.Controls.Add(this.label79);
            this.groupBox20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox20.Location = new System.Drawing.Point(29, 24);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(208, 83);
            this.groupBox20.TabIndex = 54;
            this.groupBox20.TabStop = false;
            // 
            // txtidmax
            // 
            this.txtidmax.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtidmax.Enabled = false;
            this.txtidmax.Location = new System.Drawing.Point(158, 22);
            this.txtidmax.MaxLength = 20;
            this.txtidmax.Name = "txtidmax";
            this.txtidmax.ReadOnly = true;
            this.txtidmax.Size = new System.Drawing.Size(44, 20);
            this.txtidmax.TabIndex = 47;
            this.txtidmax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtidmax.Visible = false;
            // 
            // txtregistro
            // 
            this.txtregistro.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtregistro.Enabled = false;
            this.txtregistro.Location = new System.Drawing.Point(98, 22);
            this.txtregistro.MaxLength = 20;
            this.txtregistro.Name = "txtregistro";
            this.txtregistro.ReadOnly = true;
            this.txtregistro.Size = new System.Drawing.Size(54, 20);
            this.txtregistro.TabIndex = 45;
            this.txtregistro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 46;
            this.label8.Text = "Nº Registro:";
            // 
            // txtcodempleado
            // 
            this.txtcodempleado.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcodempleado.Location = new System.Drawing.Point(98, 51);
            this.txtcodempleado.MaxLength = 10;
            this.txtcodempleado.Name = "txtcodempleado";
            this.txtcodempleado.Size = new System.Drawing.Size(104, 20);
            this.txtcodempleado.TabIndex = 24;
            this.txtcodempleado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(14, 54);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(82, 13);
            this.label79.TabIndex = 44;
            this.label79.Text = "Cod. Empleado:";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.label9);
            this.groupBox21.Controls.Add(this.cmbCategoriaBrevete);
            this.groupBox21.Controls.Add(this.label13);
            this.groupBox21.Controls.Add(this.txtNroLicenciaConductor);
            this.groupBox21.Location = new System.Drawing.Point(540, 321);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(170, 110);
            this.groupBox21.TabIndex = 51;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Licencia de Conducir";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 13);
            this.label9.TabIndex = 52;
            this.label9.Text = "Nro. Licencia :";
            // 
            // cmbCategoriaBrevete
            // 
            this.cmbCategoriaBrevete.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategoriaBrevete.FormattingEnabled = true;
            this.cmbCategoriaBrevete.Location = new System.Drawing.Point(16, 40);
            this.cmbCategoriaBrevete.Name = "cmbCategoriaBrevete";
            this.cmbCategoriaBrevete.Size = new System.Drawing.Size(139, 21);
            this.cmbCategoriaBrevete.TabIndex = 51;
            this.cmbCategoriaBrevete.SelectedIndexChanged += new System.EventHandler(this.cmbCategoriaBrevete_SelectedIndexChanged);
            this.cmbCategoriaBrevete.SelectedValueChanged += new System.EventHandler(this.cmbCategoriaBrevete_SelectedValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 48;
            this.label13.Text = "Categoría :";
            // 
            // txtNroLicenciaConductor
            // 
            this.txtNroLicenciaConductor.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtNroLicenciaConductor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNroLicenciaConductor.Location = new System.Drawing.Point(16, 82);
            this.txtNroLicenciaConductor.MaxLength = 20;
            this.txtNroLicenciaConductor.Name = "txtNroLicenciaConductor";
            this.txtNroLicenciaConductor.Size = new System.Drawing.Size(139, 20);
            this.txtNroLicenciaConductor.TabIndex = 50;
            this.txtNroLicenciaConductor.TextChanged += new System.EventHandler(this.txtNroLicenciaConductor_TextChanged);
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.cmbEstadoCivil);
            this.groupBox22.Location = new System.Drawing.Point(540, 252);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(170, 58);
            this.groupBox22.TabIndex = 53;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Estado Civil";
            // 
            // cmbEstadoCivil
            // 
            this.cmbEstadoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstadoCivil.FormattingEnabled = true;
            this.cmbEstadoCivil.Location = new System.Drawing.Point(16, 23);
            this.cmbEstadoCivil.Name = "cmbEstadoCivil";
            this.cmbEstadoCivil.Size = new System.Drawing.Size(139, 21);
            this.cmbEstadoCivil.TabIndex = 0;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.cmbNacionalidad);
            this.groupBox24.Controls.Add(this.label32);
            this.groupBox24.Location = new System.Drawing.Point(30, 376);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(491, 58);
            this.groupBox24.TabIndex = 55;
            this.groupBox24.TabStop = false;
            // 
            // cmbNacionalidad
            // 
            this.cmbNacionalidad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNacionalidad.FormattingEnabled = true;
            this.cmbNacionalidad.Location = new System.Drawing.Point(111, 16);
            this.cmbNacionalidad.Name = "cmbNacionalidad";
            this.cmbNacionalidad.Size = new System.Drawing.Size(374, 21);
            this.cmbNacionalidad.TabIndex = 35;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 19);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(75, 13);
            this.label32.TabIndex = 34;
            this.label32.Text = "Nacionalidad :";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.txtCelular);
            this.groupBox25.Controls.Add(this.txtTelFijo);
            this.groupBox25.Controls.Add(this.label33);
            this.groupBox25.Controls.Add(this.label34);
            this.groupBox25.Location = new System.Drawing.Point(29, 282);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(492, 88);
            this.groupBox25.TabIndex = 52;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Teléfonos de Contacto";
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(112, 23);
            this.txtCelular.MaxLength = 20;
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(374, 20);
            this.txtCelular.TabIndex = 41;
            // 
            // txtTelFijo
            // 
            this.txtTelFijo.Location = new System.Drawing.Point(112, 51);
            this.txtTelFijo.MaxLength = 20;
            this.txtTelFijo.Name = "txtTelFijo";
            this.txtTelFijo.Size = new System.Drawing.Size(374, 20);
            this.txtTelFijo.TabIndex = 40;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(10, 58);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(78, 13);
            this.label33.TabIndex = 37;
            this.label33.Text = "Teléfono Nro. :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(10, 30);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(45, 13);
            this.label34.TabIndex = 38;
            this.label34.Text = "Celular :";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.txtFechaNac);
            this.groupBox26.Location = new System.Drawing.Point(540, 113);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(170, 58);
            this.groupBox26.TabIndex = 50;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Fecha de Nacimiento";
            // 
            // txtFechaNac
            // 
            this.txtFechaNac.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtFechaNac.Location = new System.Drawing.Point(16, 19);
            this.txtFechaNac.Name = "txtFechaNac";
            this.txtFechaNac.Size = new System.Drawing.Size(139, 20);
            this.txtFechaNac.TabIndex = 74;
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.txtNombres);
            this.groupBox27.Controls.Add(this.label36);
            this.groupBox27.Location = new System.Drawing.Point(244, 24);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(466, 83);
            this.groupBox27.TabIndex = 49;
            this.groupBox27.TabStop = false;
            // 
            // txtNombres
            // 
            this.txtNombres.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombres.Location = new System.Drawing.Point(16, 47);
            this.txtNombres.MaxLength = 80;
            this.txtNombres.Name = "txtNombres";
            this.txtNombres.Size = new System.Drawing.Size(435, 20);
            this.txtNombres.TabIndex = 4;
            this.txtNombres.TextChanged += new System.EventHandler(this.txtNombres_TextChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(13, 25);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 13);
            this.label36.TabIndex = 23;
            this.label36.Text = "Nombres :";
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.txtNroDoc);
            this.groupBox28.Controls.Add(this.cmbTipoDocumento);
            this.groupBox28.Controls.Add(this.label39);
            this.groupBox28.Controls.Add(this.label40);
            this.groupBox28.Location = new System.Drawing.Point(29, 178);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(492, 98);
            this.groupBox28.TabIndex = 48;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Documento de Identificación";
            // 
            // txtNroDoc
            // 
            this.txtNroDoc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNroDoc.Location = new System.Drawing.Point(315, 47);
            this.txtNroDoc.MaxLength = 10;
            this.txtNroDoc.Name = "txtNroDoc";
            this.txtNroDoc.Size = new System.Drawing.Size(171, 20);
            this.txtNroDoc.TabIndex = 24;
            // 
            // cmbTipoDocumento
            // 
            this.cmbTipoDocumento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoDocumento.FormattingEnabled = true;
            this.cmbTipoDocumento.Location = new System.Drawing.Point(9, 46);
            this.cmbTipoDocumento.Name = "cmbTipoDocumento";
            this.cmbTipoDocumento.Size = new System.Drawing.Size(290, 21);
            this.cmbTipoDocumento.TabIndex = 5;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(312, 26);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(88, 13);
            this.label39.TabIndex = 41;
            this.label39.Text = "Nro.Documento :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(9, 29);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(92, 13);
            this.label40.TabIndex = 25;
            this.label40.Text = "Tipo Documento :";
            // 
            // tabPageEX3
            // 
            this.tabPageEX3.Controls.Add(this.button1);
            this.tabPageEX3.Controls.Add(this.groupBox14);
            this.tabPageEX3.Controls.Add(this.groupBox7);
            this.tabPageEX3.Controls.Add(this.groupBox2);
            this.tabPageEX3.Controls.Add(this.groupBox23);
            this.tabPageEX3.Controls.Add(this.groupBox35);
            this.tabPageEX3.Controls.Add(this.groupBox58);
            this.tabPageEX3.Controls.Add(this.groupBox47);
            this.tabPageEX3.Controls.Add(this.groupBox29);
            this.tabPageEX3.Controls.Add(this.groupBox33);
            this.tabPageEX3.Controls.Add(this.groupBox36);
            this.tabPageEX3.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX3.Name = "tabPageEX3";
            this.tabPageEX3.Size = new System.Drawing.Size(777, 591);
            this.tabPageEX3.TabIndex = 2;
            this.tabPageEX3.Text = "Datos Laborales";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(412, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 31);
            this.button1.TabIndex = 76;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cmbsede);
            this.groupBox14.Location = new System.Drawing.Point(480, 178);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(280, 46);
            this.groupBox14.TabIndex = 63;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Sede:";
            // 
            // cmbsede
            // 
            this.cmbsede.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbsede.FormattingEnabled = true;
            this.cmbsede.Location = new System.Drawing.Point(14, 17);
            this.cmbsede.Name = "cmbsede";
            this.cmbsede.Size = new System.Drawing.Size(259, 21);
            this.cmbsede.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtnomsoc);
            this.groupBox7.Location = new System.Drawing.Point(151, 178);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(322, 46);
            this.groupBox7.TabIndex = 66;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Nombre de Sociedad";
            // 
            // txtnomsoc
            // 
            this.txtnomsoc.Enabled = false;
            this.txtnomsoc.Location = new System.Drawing.Point(17, 18);
            this.txtnomsoc.MaxLength = 100;
            this.txtnomsoc.Name = "txtnomsoc";
            this.txtnomsoc.Size = new System.Drawing.Size(291, 20);
            this.txtnomsoc.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbPosicion);
            this.groupBox2.Location = new System.Drawing.Point(18, 126);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(387, 46);
            this.groupBox2.TabIndex = 75;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Nombre de la Posiciòn";
            // 
            // cmbPosicion
            // 
            this.cmbPosicion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPosicion.DropDownWidth = 450;
            this.cmbPosicion.FormattingEnabled = true;
            this.cmbPosicion.Location = new System.Drawing.Point(13, 17);
            this.cmbPosicion.Name = "cmbPosicion";
            this.cmbPosicion.Size = new System.Drawing.Size(368, 21);
            this.cmbPosicion.TabIndex = 1;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.txtEmail);
            this.groupBox23.Controls.Add(this.label14);
            this.groupBox23.Location = new System.Drawing.Point(17, 230);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(456, 47);
            this.groupBox23.TabIndex = 74;
            this.groupBox23.TabStop = false;
            // 
            // txtEmail
            // 
            this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtEmail.Location = new System.Drawing.Point(53, 17);
            this.txtEmail.MaxLength = 100;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(390, 20);
            this.txtEmail.TabIndex = 35;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "E-mail :";
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.cmbnivorganizacional);
            this.groupBox35.Location = new System.Drawing.Point(480, 126);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(280, 46);
            this.groupBox35.TabIndex = 62;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "Nivel Organizacional:";
            // 
            // cmbnivorganizacional
            // 
            this.cmbnivorganizacional.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbnivorganizacional.FormattingEnabled = true;
            this.cmbnivorganizacional.Location = new System.Drawing.Point(14, 17);
            this.cmbnivorganizacional.Name = "cmbnivorganizacional";
            this.cmbnivorganizacional.Size = new System.Drawing.Size(259, 21);
            this.cmbnivorganizacional.TabIndex = 0;
            // 
            // groupBox58
            // 
            this.groupBox58.Controls.Add(this.txtjefatura);
            this.groupBox58.Location = new System.Drawing.Point(480, 14);
            this.groupBox58.Name = "groupBox58";
            this.groupBox58.Size = new System.Drawing.Size(280, 52);
            this.groupBox58.TabIndex = 62;
            this.groupBox58.TabStop = false;
            this.groupBox58.Text = "Jefatura:";
            // 
            // txtjefatura
            // 
            this.txtjefatura.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtjefatura.Location = new System.Drawing.Point(13, 19);
            this.txtjefatura.MaxLength = 80;
            this.txtjefatura.Name = "txtjefatura";
            this.txtjefatura.Size = new System.Drawing.Size(261, 20);
            this.txtjefatura.TabIndex = 36;
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.cmbGerencia);
            this.groupBox47.Location = new System.Drawing.Point(17, 14);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(456, 52);
            this.groupBox47.TabIndex = 68;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "Gerencia";
            // 
            // cmbGerencia
            // 
            this.cmbGerencia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGerencia.FormattingEnabled = true;
            this.cmbGerencia.Location = new System.Drawing.Point(15, 19);
            this.cmbGerencia.Name = "cmbGerencia";
            this.cmbGerencia.Size = new System.Drawing.Size(427, 21);
            this.cmbGerencia.TabIndex = 46;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.cmbunidorg);
            this.groupBox29.Location = new System.Drawing.Point(18, 72);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(455, 48);
            this.groupBox29.TabIndex = 67;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Unidad Organizativa";
            // 
            // cmbunidorg
            // 
            this.cmbunidorg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbunidorg.FormattingEnabled = true;
            this.cmbunidorg.Location = new System.Drawing.Point(14, 18);
            this.cmbunidorg.Name = "cmbunidorg";
            this.cmbunidorg.Size = new System.Drawing.Size(428, 21);
            this.cmbunidorg.TabIndex = 2;
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.cmbsoc);
            this.groupBox33.Location = new System.Drawing.Point(18, 178);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(127, 46);
            this.groupBox33.TabIndex = 65;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Sociedad";
            // 
            // cmbsoc
            // 
            this.cmbsoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbsoc.DropDownWidth = 450;
            this.cmbsoc.FormattingEnabled = true;
            this.cmbsoc.Location = new System.Drawing.Point(13, 17);
            this.cmbsoc.Name = "cmbsoc";
            this.cmbsoc.Size = new System.Drawing.Size(108, 21);
            this.cmbsoc.TabIndex = 1;
            this.cmbsoc.SelectedIndexChanged += new System.EventHandler(this.cmbsoc_SelectedIndexChanged);
            this.cmbsoc.SelectedValueChanged += new System.EventHandler(this.cmbsoc_SelectedValueChanged);
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.txtrrhh);
            this.groupBox36.Location = new System.Drawing.Point(480, 72);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(280, 48);
            this.groupBox36.TabIndex = 61;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Responsable de RR.HH:";
            // 
            // txtrrhh
            // 
            this.txtrrhh.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtrrhh.Location = new System.Drawing.Point(13, 18);
            this.txtrrhh.MaxLength = 80;
            this.txtrrhh.Name = "txtrrhh";
            this.txtrrhh.Size = new System.Drawing.Size(261, 20);
            this.txtrrhh.TabIndex = 37;
            // 
            // tabPageEX11
            // 
            this.tabPageEX11.Controls.Add(this.groupBox32);
            this.tabPageEX11.Controls.Add(this.groupBox31);
            this.tabPageEX11.Controls.Add(this.groupBox30);
            this.tabPageEX11.Controls.Add(this.groupBox1);
            this.tabPageEX11.Controls.Add(this.groupBox57);
            this.tabPageEX11.Controls.Add(this.groupBox19);
            this.tabPageEX11.Controls.Add(this.groupBox12);
            this.tabPageEX11.Controls.Add(this.groupBox8);
            this.tabPageEX11.Controls.Add(this.groupBox9);
            this.tabPageEX11.Controls.Add(this.groupBox18);
            this.tabPageEX11.Controls.Add(this.groupBox17);
            this.tabPageEX11.Controls.Add(this.groupBox16);
            this.tabPageEX11.Controls.Add(this.groupBox13);
            this.tabPageEX11.Controls.Add(this.groupBox10);
            this.tabPageEX11.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX11.Name = "tabPageEX11";
            this.tabPageEX11.Size = new System.Drawing.Size(777, 591);
            this.tabPageEX11.TabIndex = 7;
            this.tabPageEX11.Text = "Información Adicional";
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.txtcomentarios);
            this.groupBox32.Location = new System.Drawing.Point(340, 277);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(427, 173);
            this.groupBox32.TabIndex = 74;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Comentarios:";
            // 
            // txtcomentarios
            // 
            this.txtcomentarios.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtcomentarios.Location = new System.Drawing.Point(13, 19);
            this.txtcomentarios.MaxLength = 200;
            this.txtcomentarios.Multiline = true;
            this.txtcomentarios.Name = "txtcomentarios";
            this.txtcomentarios.Size = new System.Drawing.Size(396, 146);
            this.txtcomentarios.TabIndex = 66;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.txtsatisfaccion);
            this.groupBox31.Location = new System.Drawing.Point(538, 209);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(229, 53);
            this.groupBox31.TabIndex = 74;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Satisfacciòn del Proceso:";
            // 
            // txtsatisfaccion
            // 
            this.txtsatisfaccion.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtsatisfaccion.Location = new System.Drawing.Point(13, 19);
            this.txtsatisfaccion.MaxLength = 50;
            this.txtsatisfaccion.Name = "txtsatisfaccion";
            this.txtsatisfaccion.Size = new System.Drawing.Size(198, 20);
            this.txtsatisfaccion.TabIndex = 66;
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.txtnrolistenvi);
            this.groupBox30.Location = new System.Drawing.Point(538, 147);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(229, 53);
            this.groupBox30.TabIndex = 76;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Nro de Long List Enviados:";
            // 
            // txtnrolistenvi
            // 
            this.txtnrolistenvi.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtnrolistenvi.Location = new System.Drawing.Point(13, 19);
            this.txtnrolistenvi.MaxLength = 5;
            this.txtnrolistenvi.Name = "txtnrolistenvi";
            this.txtnrolistenvi.Size = new System.Drawing.Size(198, 20);
            this.txtnrolistenvi.TabIndex = 68;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbdInduccionSI);
            this.groupBox1.Controls.Add(this.rbdInduccionNo);
            this.groupBox1.Location = new System.Drawing.Point(18, 409);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(294, 41);
            this.groupBox1.TabIndex = 77;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cumplimiento de Inducciòn";
            // 
            // rbdInduccionSI
            // 
            this.rbdInduccionSI.AutoSize = true;
            this.rbdInduccionSI.BackColor = System.Drawing.Color.Transparent;
            this.rbdInduccionSI.Location = new System.Drawing.Point(74, 16);
            this.rbdInduccionSI.Name = "rbdInduccionSI";
            this.rbdInduccionSI.Size = new System.Drawing.Size(34, 17);
            this.rbdInduccionSI.TabIndex = 60;
            this.rbdInduccionSI.Text = "Si";
            this.rbdInduccionSI.UseVisualStyleBackColor = false;
            // 
            // rbdInduccionNo
            // 
            this.rbdInduccionNo.AutoSize = true;
            this.rbdInduccionNo.BackColor = System.Drawing.Color.Transparent;
            this.rbdInduccionNo.Checked = true;
            this.rbdInduccionNo.Location = new System.Drawing.Point(145, 16);
            this.rbdInduccionNo.Name = "rbdInduccionNo";
            this.rbdInduccionNo.Size = new System.Drawing.Size(39, 17);
            this.rbdInduccionNo.TabIndex = 61;
            this.rbdInduccionNo.TabStop = true;
            this.rbdInduccionNo.Text = "No";
            this.rbdInduccionNo.UseVisualStyleBackColor = false;
            // 
            // groupBox57
            // 
            this.groupBox57.Controls.Add(this.rdbcartaSi);
            this.groupBox57.Controls.Add(this.rdbcartaNo);
            this.groupBox57.Location = new System.Drawing.Point(20, 362);
            this.groupBox57.Name = "groupBox57";
            this.groupBox57.Size = new System.Drawing.Size(292, 41);
            this.groupBox57.TabIndex = 76;
            this.groupBox57.TabStop = false;
            this.groupBox57.Text = "Envio Carta Oferta";
            // 
            // rdbcartaSi
            // 
            this.rdbcartaSi.AutoSize = true;
            this.rdbcartaSi.BackColor = System.Drawing.Color.Transparent;
            this.rdbcartaSi.Location = new System.Drawing.Point(74, 16);
            this.rdbcartaSi.Name = "rdbcartaSi";
            this.rdbcartaSi.Size = new System.Drawing.Size(34, 17);
            this.rdbcartaSi.TabIndex = 60;
            this.rdbcartaSi.Text = "Si";
            this.rdbcartaSi.UseVisualStyleBackColor = false;
            // 
            // rdbcartaNo
            // 
            this.rdbcartaNo.AutoSize = true;
            this.rdbcartaNo.BackColor = System.Drawing.Color.Transparent;
            this.rdbcartaNo.Checked = true;
            this.rdbcartaNo.Location = new System.Drawing.Point(145, 16);
            this.rdbcartaNo.Name = "rdbcartaNo";
            this.rdbcartaNo.Size = new System.Drawing.Size(39, 17);
            this.rdbcartaNo.TabIndex = 61;
            this.rdbcartaNo.TabStop = true;
            this.rdbcartaNo.Text = "No";
            this.rdbcartaNo.UseVisualStyleBackColor = false;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.cmbestatusocupacion);
            this.groupBox19.Location = new System.Drawing.Point(538, 87);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(229, 53);
            this.groupBox19.TabIndex = 75;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Estatus Ocupaciòn:";
            // 
            // cmbestatusocupacion
            // 
            this.cmbestatusocupacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbestatusocupacion.FormattingEnabled = true;
            this.cmbestatusocupacion.Location = new System.Drawing.Point(13, 19);
            this.cmbestatusocupacion.Name = "cmbestatusocupacion";
            this.cmbestatusocupacion.Size = new System.Drawing.Size(198, 21);
            this.cmbestatusocupacion.TabIndex = 80;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.cmbestadoproceso);
            this.groupBox12.Location = new System.Drawing.Point(340, 87);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(183, 53);
            this.groupBox12.TabIndex = 74;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Estado de Proceso:";
            // 
            // cmbestadoproceso
            // 
            this.cmbestadoproceso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbestadoproceso.FormattingEnabled = true;
            this.cmbestadoproceso.Location = new System.Drawing.Point(13, 19);
            this.cmbestadoproceso.Name = "cmbestadoproceso";
            this.cmbestadoproceso.Size = new System.Drawing.Size(164, 21);
            this.cmbestadoproceso.TabIndex = 79;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtproveedor);
            this.groupBox8.Location = new System.Drawing.Point(340, 209);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(183, 53);
            this.groupBox8.TabIndex = 73;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Proveedor:";
            // 
            // txtproveedor
            // 
            this.txtproveedor.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtproveedor.Location = new System.Drawing.Point(13, 19);
            this.txtproveedor.MaxLength = 50;
            this.txtproveedor.Name = "txtproveedor";
            this.txtproveedor.Size = new System.Drawing.Size(164, 20);
            this.txtproveedor.TabIndex = 66;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.cmbtipocontrato);
            this.groupBox9.Controls.Add(this.cmbmodalidad);
            this.groupBox9.Controls.Add(this.label28);
            this.groupBox9.Controls.Add(this.label29);
            this.groupBox9.Location = new System.Drawing.Point(18, 258);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(294, 98);
            this.groupBox9.TabIndex = 74;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Contrato:";
            // 
            // cmbtipocontrato
            // 
            this.cmbtipocontrato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbtipocontrato.FormattingEnabled = true;
            this.cmbtipocontrato.Location = new System.Drawing.Point(114, 56);
            this.cmbtipocontrato.Name = "cmbtipocontrato";
            this.cmbtipocontrato.Size = new System.Drawing.Size(168, 21);
            this.cmbtipocontrato.TabIndex = 80;
            // 
            // cmbmodalidad
            // 
            this.cmbmodalidad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbmodalidad.FormattingEnabled = true;
            this.cmbmodalidad.Location = new System.Drawing.Point(114, 25);
            this.cmbmodalidad.Name = "cmbmodalidad";
            this.cmbmodalidad.Size = new System.Drawing.Size(168, 21);
            this.cmbmodalidad.TabIndex = 79;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 59);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(74, 13);
            this.label28.TabIndex = 75;
            this.label28.Text = "Tipo Contrato:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 33);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 13);
            this.label29.TabIndex = 73;
            this.label29.Text = "Modalidad:";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.cmbmedioate);
            this.groupBox18.Controls.Add(this.cmbtipoproceso);
            this.groupBox18.Controls.Add(this.label25);
            this.groupBox18.Controls.Add(this.txtfuentepostulacion);
            this.groupBox18.Controls.Add(this.label24);
            this.groupBox18.Controls.Add(this.label23);
            this.groupBox18.Location = new System.Drawing.Point(18, 129);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(294, 121);
            this.groupBox18.TabIndex = 69;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Publicacion:";
            // 
            // cmbmedioate
            // 
            this.cmbmedioate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbmedioate.FormattingEnabled = true;
            this.cmbmedioate.Location = new System.Drawing.Point(114, 49);
            this.cmbmedioate.Name = "cmbmedioate";
            this.cmbmedioate.Size = new System.Drawing.Size(168, 21);
            this.cmbmedioate.TabIndex = 78;
            // 
            // cmbtipoproceso
            // 
            this.cmbtipoproceso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbtipoproceso.FormattingEnabled = true;
            this.cmbtipoproceso.Location = new System.Drawing.Point(114, 20);
            this.cmbtipoproceso.Name = "cmbtipoproceso";
            this.cmbtipoproceso.Size = new System.Drawing.Size(168, 21);
            this.cmbtipoproceso.TabIndex = 77;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 80);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(101, 13);
            this.label25.TabIndex = 71;
            this.label25.Text = "Fuente Postulaciòn:";
            // 
            // txtfuentepostulacion
            // 
            this.txtfuentepostulacion.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtfuentepostulacion.Location = new System.Drawing.Point(114, 77);
            this.txtfuentepostulacion.MaxLength = 50;
            this.txtfuentepostulacion.Name = "txtfuentepostulacion";
            this.txtfuentepostulacion.Size = new System.Drawing.Size(168, 20);
            this.txtfuentepostulacion.TabIndex = 70;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(99, 13);
            this.label24.TabIndex = 69;
            this.label24.Text = "Medio de Atenciòn:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 13);
            this.label23.TabIndex = 67;
            this.label23.Text = "Tipo de Proceso:";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.txtcantevaluados);
            this.groupBox17.Location = new System.Drawing.Point(538, 25);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(229, 53);
            this.groupBox17.TabIndex = 73;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Cantidad Evaluados:";
            // 
            // txtcantevaluados
            // 
            this.txtcantevaluados.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtcantevaluados.Location = new System.Drawing.Point(13, 19);
            this.txtcantevaluados.MaxLength = 5;
            this.txtcantevaluados.Name = "txtcantevaluados";
            this.txtcantevaluados.Size = new System.Drawing.Size(198, 20);
            this.txtcantevaluados.TabIndex = 66;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.cmborigen);
            this.groupBox16.Controls.Add(this.label27);
            this.groupBox16.Controls.Add(this.txtreemplazo);
            this.groupBox16.Controls.Add(this.label26);
            this.groupBox16.Location = new System.Drawing.Point(18, 25);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(294, 98);
            this.groupBox16.TabIndex = 68;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Motivo:";
            // 
            // cmborigen
            // 
            this.cmborigen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmborigen.FormattingEnabled = true;
            this.cmborigen.Location = new System.Drawing.Point(114, 25);
            this.cmborigen.Name = "cmborigen";
            this.cmborigen.Size = new System.Drawing.Size(168, 21);
            this.cmborigen.TabIndex = 76;
            this.cmborigen.SelectedValueChanged += new System.EventHandler(this.cmborigen_SelectedValueChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(78, 13);
            this.label27.TabIndex = 75;
            this.label27.Text = "Reemplazo de:";
            // 
            // txtreemplazo
            // 
            this.txtreemplazo.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtreemplazo.Location = new System.Drawing.Point(114, 52);
            this.txtreemplazo.MaxLength = 80;
            this.txtreemplazo.Name = "txtreemplazo";
            this.txtreemplazo.Size = new System.Drawing.Size(168, 20);
            this.txtreemplazo.TabIndex = 74;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 13);
            this.label26.TabIndex = 73;
            this.label26.Text = "Origen:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.cmbprioridad);
            this.groupBox13.Location = new System.Drawing.Point(340, 147);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(183, 53);
            this.groupBox13.TabIndex = 72;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Prioridad:";
            // 
            // cmbprioridad
            // 
            this.cmbprioridad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbprioridad.FormattingEnabled = true;
            this.cmbprioridad.Location = new System.Drawing.Point(13, 19);
            this.cmbprioridad.Name = "cmbprioridad";
            this.cmbprioridad.Size = new System.Drawing.Size(164, 21);
            this.cmbprioridad.TabIndex = 80;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtvacantes);
            this.groupBox10.Location = new System.Drawing.Point(340, 25);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(183, 53);
            this.groupBox10.TabIndex = 70;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Vacantes:";
            // 
            // txtvacantes
            // 
            this.txtvacantes.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtvacantes.Location = new System.Drawing.Point(13, 19);
            this.txtvacantes.MaxLength = 5;
            this.txtvacantes.Name = "txtvacantes";
            this.txtvacantes.Size = new System.Drawing.Size(164, 20);
            this.txtvacantes.TabIndex = 66;
            // 
            // tabPageEX5
            // 
            this.tabPageEX5.Controls.Add(this.tabPlame);
            this.tabPageEX5.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX5.Name = "tabPageEX5";
            this.tabPageEX5.Size = new System.Drawing.Size(777, 591);
            this.tabPageEX5.TabIndex = 3;
            this.tabPageEX5.Text = "Fechas Registro";
            // 
            // tabPlame
            // 
            this.tabPlame.Controls.Add(this.tabPage1);
            this.tabPlame.Location = new System.Drawing.Point(19, 37);
            this.tabPlame.Name = "tabPlame";
            this.tabPlame.SelectedIndex = 0;
            this.tabPlame.Size = new System.Drawing.Size(738, 393);
            this.tabPlame.TabIndex = 45;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.txttotaldias);
            this.tabPage1.Controls.Add(this.groupBox15);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(730, 367);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Periodos de Vínculo Laboral";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(446, 32);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 13);
            this.label21.TabIndex = 39;
            this.label21.Text = "Total dias:";
            // 
            // txttotaldias
            // 
            this.txttotaldias.Enabled = false;
            this.txttotaldias.Location = new System.Drawing.Point(518, 29);
            this.txttotaldias.MaxLength = 5;
            this.txttotaldias.Name = "txttotaldias";
            this.txttotaldias.Size = new System.Drawing.Size(100, 20);
            this.txttotaldias.TabIndex = 44;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.txtfecierre);
            this.groupBox15.Controls.Add(this.txtfeestimacion);
            this.groupBox15.Controls.Add(this.txtfeinicioproceso);
            this.groupBox15.Controls.Add(this.label22);
            this.groupBox15.Controls.Add(this.label10);
            this.groupBox15.Controls.Add(this.label11);
            this.groupBox15.Location = new System.Drawing.Point(23, 18);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(365, 129);
            this.groupBox15.TabIndex = 40;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Periodo selecciòn:";
            // 
            // txtfecierre
            // 
            this.txtfecierre.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtfecierre.Location = new System.Drawing.Point(211, 81);
            this.txtfecierre.Name = "txtfecierre";
            this.txtfecierre.Size = new System.Drawing.Size(139, 20);
            this.txtfecierre.TabIndex = 56;
            this.txtfecierre.ValueChanged += new System.EventHandler(this.txtfecierre_ValueChanged);
            // 
            // txtfeestimacion
            // 
            this.txtfeestimacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtfeestimacion.Location = new System.Drawing.Point(211, 55);
            this.txtfeestimacion.Name = "txtfeestimacion";
            this.txtfeestimacion.Size = new System.Drawing.Size(139, 20);
            this.txtfeestimacion.TabIndex = 55;
            // 
            // txtfeinicioproceso
            // 
            this.txtfeinicioproceso.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtfeinicioproceso.Location = new System.Drawing.Point(211, 29);
            this.txtfeinicioproceso.Name = "txtfeinicioproceso";
            this.txtfeinicioproceso.Size = new System.Drawing.Size(139, 20);
            this.txtfeinicioproceso.TabIndex = 54;
            this.txtfeinicioproceso.ValueChanged += new System.EventHandler(this.txtfeinicioproceso_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 85);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(85, 13);
            this.label22.TabIndex = 37;
            this.label22.Text = "Fecha de Cierre:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Fecha de Inicio Proceso :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Fecha de Estimaciòn :";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtfeincorporacion);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(23, 153);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(681, 86);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Periodo de Vínculo Laboral";
            // 
            // txtfeincorporacion
            // 
            this.txtfeincorporacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtfeincorporacion.Location = new System.Drawing.Point(211, 24);
            this.txtfeincorporacion.Name = "txtfeincorporacion";
            this.txtfeincorporacion.Size = new System.Drawing.Size(139, 20);
            this.txtfeincorporacion.TabIndex = 57;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Fecha de Incorporaciòn:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(136, 17);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(136, 13);
            this.lblNombre.TabIndex = 49;
            this.lblNombre.Text = "...........................................";
            this.lblNombre.TextChanged += new System.EventHandler(this.lblNombre_TextChanged);
            this.lblNombre.Click += new System.EventHandler(this.lblNombre_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Datos de :";
            // 
            // toolstripform
            // 
            this.toolstripform.BackColor = System.Drawing.SystemColors.HighlightText;
            this.toolstripform.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolstripform.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.toolStripSeparator1,
            this.btnGuardar,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripButton1,
            this.toolStripSeparator4,
            this.excel,
            this.toolStripSeparator3,
            this.btnSalir});
            this.toolstripform.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolstripform.Location = new System.Drawing.Point(0, 681);
            this.toolstripform.Name = "toolstripform";
            this.toolstripform.ShowItemToolTips = false;
            this.toolstripform.Size = new System.Drawing.Size(819, 25);
            this.toolstripform.TabIndex = 52;
            // 
            // btnNuevo
            // 
            this.btnNuevo.Image = global::CaniaBrava.Properties.Resources.NEW;
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(62, 22);
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = global::CaniaBrava.Properties.Resources.SAVE;
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(69, 22);
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.Visible = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = global::CaniaBrava.Properties.Resources.refresh;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(79, 22);
            this.toolStripButton2.Text = "Actualizar";
            this.toolStripButton2.Visible = false;
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator2.Visible = false;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::CaniaBrava.Properties.Resources.NOTE;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(105, 22);
            this.toolStripButton1.Text = "Listar personas";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // excel
            // 
            this.excel.Image = global::CaniaBrava.Properties.Resources.EXCEL;
            this.excel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.excel.Name = "excel";
            this.excel.Size = new System.Drawing.Size(54, 22);
            this.excel.Text = "Excel";
            this.excel.Click += new System.EventHandler(this.excel_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // btnSalir
            // 
            this.btnSalir.Image = global::CaniaBrava.Properties.Resources.CLOSE;
            this.btnSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(49, 22);
            this.btnSalir.Text = "Salir";
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // ui_atraccion_seleccion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 706);
            this.ControlBox = false;
            this.Controls.Add(this.toolstripform);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControlPer);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ui_atraccion_seleccion";
            this.Text = "Atraccion y Seleccion";
            this.Load += new System.EventHandler(this.ui_atraccion_seleccion_Load);
            this.tabControlPer.ResumeLayout(false);
            this.tabPageEX1.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.groupBox34.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.tabPageEX3.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox35.ResumeLayout(false);
            this.groupBox58.ResumeLayout(false);
            this.groupBox58.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.groupBox33.ResumeLayout(false);
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.tabPageEX11.ResumeLayout(false);
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox57.ResumeLayout(false);
            this.groupBox57.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPageEX5.ResumeLayout(false);
            this.tabPlame.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.toolstripform.ResumeLayout(false);
            this.toolstripform.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Dotnetrix.Controls.TabControlEX tabControlPer;
        private Dotnetrix.Controls.TabPageEX tabPageEX1;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.ComboBox cmbNivelEducativo;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox cmbSexo;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox txtcodempleado;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbCategoriaBrevete;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNroLicenciaConductor;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.ComboBox cmbEstadoCivil;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.ComboBox cmbNacionalidad;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox25;
        public System.Windows.Forms.TextBox txtCelular;
        public System.Windows.Forms.TextBox txtTelFijo;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.GroupBox groupBox27;
        public System.Windows.Forms.TextBox txtNombres;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.ComboBox cmbTipoDocumento;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private Dotnetrix.Controls.TabPageEX tabPageEX3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbPosicion;
        private System.Windows.Forms.GroupBox groupBox23;
        public System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.ComboBox cmbnivorganizacional;
        private System.Windows.Forms.GroupBox groupBox58;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.ComboBox cmbGerencia;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.ComboBox cmbunidorg;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.ComboBox cmbsoc;
        private System.Windows.Forms.GroupBox groupBox36;
        private Dotnetrix.Controls.TabPageEX tabPageEX11;
        private Dotnetrix.Controls.TabPageEX tabPageEX5;
        private System.Windows.Forms.TabControl tabPlame;
        private System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.TextBox txtregistro;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox cmbsede;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox8;
        public System.Windows.Forms.TextBox txtproveedor;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label25;
        public System.Windows.Forms.TextBox txtfuentepostulacion;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox17;
        public System.Windows.Forms.TextBox txtcantevaluados;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.TextBox txtreemplazo;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox10;
        public System.Windows.Forms.TextBox txtvacantes;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txttotaldias;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox32;
        public System.Windows.Forms.TextBox txtcomentarios;
        private System.Windows.Forms.GroupBox groupBox31;
        public System.Windows.Forms.TextBox txtsatisfaccion;
        private System.Windows.Forms.GroupBox groupBox30;
        public System.Windows.Forms.TextBox txtnrolistenvi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbdInduccionSI;
        private System.Windows.Forms.RadioButton rbdInduccionNo;
        private System.Windows.Forms.GroupBox groupBox57;
        private System.Windows.Forms.RadioButton rdbcartaSi;
        private System.Windows.Forms.RadioButton rdbcartaNo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtjefatura;
        private System.Windows.Forms.TextBox txtrrhh;
        private System.Windows.Forms.TextBox txtnomsoc;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmborigen;
        private System.Windows.Forms.ComboBox cmbtipoproceso;
        private System.Windows.Forms.ComboBox cmbmedioate;
        private System.Windows.Forms.ComboBox cmbestadoproceso;
        private System.Windows.Forms.ComboBox cmbprioridad;
        private System.Windows.Forms.ComboBox cmbestatusocupacion;
        private System.Windows.Forms.ComboBox cmbmodalidad;
        private System.Windows.Forms.ComboBox cmbtipocontrato;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtreferencia;
        private System.Windows.Forms.TextBox txtdepartamento;
        private System.Windows.Forms.TextBox txtdistrito;
        private System.Windows.Forms.TextBox txtprovincia;
        private System.Windows.Forms.ToolStrip toolstripform;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnSalir;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        public System.Windows.Forms.TextBox txtNroDoc;
        public System.Windows.Forms.TextBox txtidmax;
        private System.Windows.Forms.DateTimePicker txtfeinicioproceso;
        private System.Windows.Forms.DateTimePicker txtFechaNac;
        private System.Windows.Forms.DateTimePicker txtfecierre;
        private System.Windows.Forms.DateTimePicker txtfeestimacion;
        private System.Windows.Forms.DateTimePicker txtfeincorporacion;
        private System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton excel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    }
}