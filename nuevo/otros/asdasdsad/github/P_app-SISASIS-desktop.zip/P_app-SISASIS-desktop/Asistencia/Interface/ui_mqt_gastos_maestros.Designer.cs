﻿namespace CaniaBrava.Interface
{
    partial class ui_mqt_gastos_maestros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tbpOrdCeCo = new System.Windows.Forms.TabPage();
            this.GifLoading = new System.Windows.Forms.PictureBox();
            this.lbNReg = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbHojas = new System.Windows.Forms.ComboBox();
            this.dgvDatos = new System.Windows.Forms.DataGridView();
            this.btnRegData = new System.Windows.Forms.Button();
            this.lbPorcentaje = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.btnCargar = new System.Windows.Forms.Button();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbpCntCont = new System.Windows.Forms.TabPage();
            this.dgvDatos_Cc = new System.Windows.Forms.DataGridView();
            this.btnRegData_Cc = new System.Windows.Forms.Button();
            this.lbPorcentaje_Cc = new System.Windows.Forms.Label();
            this.progressBar_Cc = new System.Windows.Forms.ProgressBar();
            this.btnCargar_Cc = new System.Windows.Forms.Button();
            this.txtRuta_Cc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbpMat = new System.Windows.Forms.TabPage();
            this.dgvDatos_Mat = new System.Windows.Forms.DataGridView();
            this.btnRegData_Mat = new System.Windows.Forms.Button();
            this.lbPorcentaje_Mat = new System.Windows.Forms.Label();
            this.progressBar_Mat = new System.Windows.Forms.ProgressBar();
            this.btnCargar_Mat = new System.Windows.Forms.Button();
            this.txtRuta_Mat = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbpAgrp = new System.Windows.Forms.TabPage();
            this.dgvDatos_Agr = new System.Windows.Forms.DataGridView();
            this.btnRegData_Agr = new System.Windows.Forms.Button();
            this.lbPorcentaje_Agr = new System.Windows.Forms.Label();
            this.progressBar_Agr = new System.Windows.Forms.ProgressBar();
            this.btnCargar_Agr = new System.Windows.Forms.Button();
            this.txtRuta_Agr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbpTpMant = new System.Windows.Forms.TabPage();
            this.dgvDatos_Tdm = new System.Windows.Forms.DataGridView();
            this.btnRegData_Tdm = new System.Windows.Forms.Button();
            this.lbPorcentaje_Tdm = new System.Windows.Forms.Label();
            this.progressBar_Tdm = new System.Windows.Forms.ProgressBar();
            this.btnCargar_Tdm = new System.Windows.Forms.Button();
            this.txtRuta_Tdm = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbpJefRev = new System.Windows.Forms.TabPage();
            this.dgvDatos_Jr = new System.Windows.Forms.DataGridView();
            this.btnRegData_Jr = new System.Windows.Forms.Button();
            this.lbPorcentaje_Jr = new System.Windows.Forms.Label();
            this.progressBar_Jr = new System.Windows.Forms.ProgressBar();
            this.btnCargar_Jr = new System.Windows.Forms.Button();
            this.txtRuta_Jr = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbpDic = new System.Windows.Forms.TabPage();
            this.tabDicControl = new System.Windows.Forms.TabControl();
            this.tbpDicOrd = new System.Windows.Forms.TabPage();
            this.dgvDic_Ord = new System.Windows.Forms.DataGridView();
            this.tbpDicCc = new System.Windows.Forms.TabPage();
            this.dgvDic_Cc = new System.Windows.Forms.DataGridView();
            this.tbpDicMat = new System.Windows.Forms.TabPage();
            this.dgvDic_Mat = new System.Windows.Forms.DataGridView();
            this.tbpDicAgr = new System.Windows.Forms.TabPage();
            this.dgvDic_Agr = new System.Windows.Forms.DataGridView();
            this.tbpDicTdm = new System.Windows.Forms.TabPage();
            this.dgvDic_Tdm = new System.Windows.Forms.DataGridView();
            this.tbpDicJr = new System.Windows.Forms.TabPage();
            this.dgvDic_Jr = new System.Windows.Forms.DataGridView();
            this.tabControl.SuspendLayout();
            this.tbpOrdCeCo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GifLoading)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos)).BeginInit();
            this.tbpCntCont.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Cc)).BeginInit();
            this.tbpMat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Mat)).BeginInit();
            this.tbpAgrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Agr)).BeginInit();
            this.tbpTpMant.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Tdm)).BeginInit();
            this.tbpJefRev.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Jr)).BeginInit();
            this.tbpDic.SuspendLayout();
            this.tabDicControl.SuspendLayout();
            this.tbpDicOrd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Ord)).BeginInit();
            this.tbpDicCc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Cc)).BeginInit();
            this.tbpDicMat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Mat)).BeginInit();
            this.tbpDicAgr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Agr)).BeginInit();
            this.tbpDicTdm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Tdm)).BeginInit();
            this.tbpDicJr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Jr)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tbpOrdCeCo);
            this.tabControl.Controls.Add(this.tbpCntCont);
            this.tabControl.Controls.Add(this.tbpMat);
            this.tabControl.Controls.Add(this.tbpAgrp);
            this.tabControl.Controls.Add(this.tbpTpMant);
            this.tabControl.Controls.Add(this.tbpJefRev);
            this.tabControl.Controls.Add(this.tbpDic);
            this.tabControl.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabControl.ItemSize = new System.Drawing.Size(108, 21);
            this.tabControl.Location = new System.Drawing.Point(2, 2);
            this.tabControl.Name = "tabControl";
            this.tabControl.Padding = new System.Drawing.Point(10, 3);
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(995, 677);
            this.tabControl.TabIndex = 0;
            this.tabControl.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl_DrawItem);
            // 
            // tbpOrdCeCo
            // 
            this.tbpOrdCeCo.BackColor = System.Drawing.Color.White;
            this.tbpOrdCeCo.Controls.Add(this.GifLoading);
            this.tbpOrdCeCo.Controls.Add(this.lbNReg);
            this.tbpOrdCeCo.Controls.Add(this.label2);
            this.tbpOrdCeCo.Controls.Add(this.cmbHojas);
            this.tbpOrdCeCo.Controls.Add(this.dgvDatos);
            this.tbpOrdCeCo.Controls.Add(this.btnRegData);
            this.tbpOrdCeCo.Controls.Add(this.lbPorcentaje);
            this.tbpOrdCeCo.Controls.Add(this.progressBar);
            this.tbpOrdCeCo.Controls.Add(this.btnCargar);
            this.tbpOrdCeCo.Controls.Add(this.txtRuta);
            this.tbpOrdCeCo.Controls.Add(this.label1);
            this.tbpOrdCeCo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbpOrdCeCo.Location = new System.Drawing.Point(4, 25);
            this.tbpOrdCeCo.Name = "tbpOrdCeCo";
            this.tbpOrdCeCo.Padding = new System.Windows.Forms.Padding(3);
            this.tbpOrdCeCo.Size = new System.Drawing.Size(987, 648);
            this.tbpOrdCeCo.TabIndex = 0;
            this.tbpOrdCeCo.Text = "Maestros";
            // 
            // GifLoading
            // 
            this.GifLoading.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GifLoading.BackColor = System.Drawing.Color.DarkGray;
            this.GifLoading.Image = global::CaniaBrava.Properties.Resources.loading;
            this.GifLoading.Location = new System.Drawing.Point(439, 346);
            this.GifLoading.Name = "GifLoading";
            this.GifLoading.Size = new System.Drawing.Size(108, 108);
            this.GifLoading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GifLoading.TabIndex = 11;
            this.GifLoading.TabStop = false;
            this.GifLoading.Visible = false;
            // 
            // lbNReg
            // 
            this.lbNReg.AutoSize = true;
            this.lbNReg.Location = new System.Drawing.Point(17, 179);
            this.lbNReg.Name = "lbNReg";
            this.lbNReg.Size = new System.Drawing.Size(111, 17);
            this.lbNReg.TabIndex = 10;
            this.lbNReg.Text = "N° de registros: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(674, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Hojas:";
            // 
            // cmbHojas
            // 
            this.cmbHojas.FormattingEnabled = true;
            this.cmbHojas.Location = new System.Drawing.Point(677, 63);
            this.cmbHojas.Name = "cmbHojas";
            this.cmbHojas.Size = new System.Drawing.Size(176, 24);
            this.cmbHojas.TabIndex = 7;
            this.cmbHojas.SelectedIndexChanged += new System.EventHandler(this.cmbHojas_SelectedIndexChanged);
            // 
            // dgvDatos
            // 
            this.dgvDatos.AllowUserToAddRows = false;
            this.dgvDatos.AllowUserToDeleteRows = false;
            this.dgvDatos.AllowUserToResizeColumns = false;
            this.dgvDatos.AllowUserToResizeRows = false;
            this.dgvDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos.Location = new System.Drawing.Point(20, 199);
            this.dgvDatos.Name = "dgvDatos";
            this.dgvDatos.ReadOnly = true;
            this.dgvDatos.RowTemplate.Height = 24;
            this.dgvDatos.Size = new System.Drawing.Size(948, 402);
            this.dgvDatos.TabIndex = 6;
            // 
            // btnRegData
            // 
            this.btnRegData.Location = new System.Drawing.Point(795, 133);
            this.btnRegData.Name = "btnRegData";
            this.btnRegData.Size = new System.Drawing.Size(153, 31);
            this.btnRegData.TabIndex = 5;
            this.btnRegData.Text = "Registrar Data";
            this.btnRegData.UseVisualStyleBackColor = true;
            this.btnRegData.Click += new System.EventHandler(this.btnRegData_Click);
            // 
            // lbPorcentaje
            // 
            this.lbPorcentaje.AutoSize = true;
            this.lbPorcentaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentaje.Location = new System.Drawing.Point(701, 140);
            this.lbPorcentaje.Name = "lbPorcentaje";
            this.lbPorcentaje.Size = new System.Drawing.Size(30, 17);
            this.lbPorcentaje.TabIndex = 4;
            this.lbPorcentaje.Text = "0%";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(40, 137);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(655, 23);
            this.progressBar.TabIndex = 3;
            // 
            // btnCargar
            // 
            this.btnCargar.Location = new System.Drawing.Point(479, 59);
            this.btnCargar.Name = "btnCargar";
            this.btnCargar.Size = new System.Drawing.Size(149, 31);
            this.btnCargar.TabIndex = 2;
            this.btnCargar.Text = "Cargar Archivo";
            this.btnCargar.UseVisualStyleBackColor = true;
            this.btnCargar.Click += new System.EventHandler(this.btnCargar_Click);
            // 
            // txtRuta
            // 
            this.txtRuta.Location = new System.Drawing.Point(40, 63);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.Size = new System.Drawing.Size(404, 22);
            this.txtRuta.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ruta:";
            // 
            // tbpCntCont
            // 
            this.tbpCntCont.BackColor = System.Drawing.Color.White;
            this.tbpCntCont.Controls.Add(this.dgvDatos_Cc);
            this.tbpCntCont.Controls.Add(this.btnRegData_Cc);
            this.tbpCntCont.Controls.Add(this.lbPorcentaje_Cc);
            this.tbpCntCont.Controls.Add(this.progressBar_Cc);
            this.tbpCntCont.Controls.Add(this.btnCargar_Cc);
            this.tbpCntCont.Controls.Add(this.txtRuta_Cc);
            this.tbpCntCont.Controls.Add(this.label3);
            this.tbpCntCont.Location = new System.Drawing.Point(4, 25);
            this.tbpCntCont.Name = "tbpCntCont";
            this.tbpCntCont.Padding = new System.Windows.Forms.Padding(3);
            this.tbpCntCont.Size = new System.Drawing.Size(987, 648);
            this.tbpCntCont.TabIndex = 1;
            this.tbpCntCont.Text = "Cuentas Contables";
            // 
            // dgvDatos_Cc
            // 
            this.dgvDatos_Cc.AllowUserToAddRows = false;
            this.dgvDatos_Cc.AllowUserToDeleteRows = false;
            this.dgvDatos_Cc.AllowUserToResizeColumns = false;
            this.dgvDatos_Cc.AllowUserToResizeRows = false;
            this.dgvDatos_Cc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos_Cc.Location = new System.Drawing.Point(20, 199);
            this.dgvDatos_Cc.Name = "dgvDatos_Cc";
            this.dgvDatos_Cc.ReadOnly = true;
            this.dgvDatos_Cc.RowTemplate.Height = 24;
            this.dgvDatos_Cc.Size = new System.Drawing.Size(948, 402);
            this.dgvDatos_Cc.TabIndex = 13;
            // 
            // btnRegData_Cc
            // 
            this.btnRegData_Cc.Location = new System.Drawing.Point(795, 133);
            this.btnRegData_Cc.Name = "btnRegData_Cc";
            this.btnRegData_Cc.Size = new System.Drawing.Size(153, 31);
            this.btnRegData_Cc.TabIndex = 12;
            this.btnRegData_Cc.Text = "Registrar Data";
            this.btnRegData_Cc.UseVisualStyleBackColor = true;
            // 
            // lbPorcentaje_Cc
            // 
            this.lbPorcentaje_Cc.AutoSize = true;
            this.lbPorcentaje_Cc.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentaje_Cc.Location = new System.Drawing.Point(701, 140);
            this.lbPorcentaje_Cc.Name = "lbPorcentaje_Cc";
            this.lbPorcentaje_Cc.Size = new System.Drawing.Size(30, 17);
            this.lbPorcentaje_Cc.TabIndex = 11;
            this.lbPorcentaje_Cc.Text = "0%";
            // 
            // progressBar_Cc
            // 
            this.progressBar_Cc.Location = new System.Drawing.Point(40, 137);
            this.progressBar_Cc.Name = "progressBar_Cc";
            this.progressBar_Cc.Size = new System.Drawing.Size(655, 23);
            this.progressBar_Cc.TabIndex = 10;
            // 
            // btnCargar_Cc
            // 
            this.btnCargar_Cc.Location = new System.Drawing.Point(479, 59);
            this.btnCargar_Cc.Name = "btnCargar_Cc";
            this.btnCargar_Cc.Size = new System.Drawing.Size(149, 31);
            this.btnCargar_Cc.TabIndex = 9;
            this.btnCargar_Cc.Text = "Cargar Archivo";
            this.btnCargar_Cc.UseVisualStyleBackColor = true;
            // 
            // txtRuta_Cc
            // 
            this.txtRuta_Cc.Location = new System.Drawing.Point(40, 63);
            this.txtRuta_Cc.Name = "txtRuta_Cc";
            this.txtRuta_Cc.Size = new System.Drawing.Size(404, 22);
            this.txtRuta_Cc.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Ruta:";
            // 
            // tbpMat
            // 
            this.tbpMat.BackColor = System.Drawing.Color.White;
            this.tbpMat.Controls.Add(this.dgvDatos_Mat);
            this.tbpMat.Controls.Add(this.btnRegData_Mat);
            this.tbpMat.Controls.Add(this.lbPorcentaje_Mat);
            this.tbpMat.Controls.Add(this.progressBar_Mat);
            this.tbpMat.Controls.Add(this.btnCargar_Mat);
            this.tbpMat.Controls.Add(this.txtRuta_Mat);
            this.tbpMat.Controls.Add(this.label5);
            this.tbpMat.Location = new System.Drawing.Point(4, 25);
            this.tbpMat.Name = "tbpMat";
            this.tbpMat.Size = new System.Drawing.Size(987, 648);
            this.tbpMat.TabIndex = 0;
            this.tbpMat.Text = "Materiales";
            // 
            // dgvDatos_Mat
            // 
            this.dgvDatos_Mat.AllowUserToAddRows = false;
            this.dgvDatos_Mat.AllowUserToDeleteRows = false;
            this.dgvDatos_Mat.AllowUserToResizeColumns = false;
            this.dgvDatos_Mat.AllowUserToResizeRows = false;
            this.dgvDatos_Mat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos_Mat.Location = new System.Drawing.Point(20, 199);
            this.dgvDatos_Mat.Name = "dgvDatos_Mat";
            this.dgvDatos_Mat.ReadOnly = true;
            this.dgvDatos_Mat.RowTemplate.Height = 24;
            this.dgvDatos_Mat.Size = new System.Drawing.Size(948, 402);
            this.dgvDatos_Mat.TabIndex = 20;
            // 
            // btnRegData_Mat
            // 
            this.btnRegData_Mat.Location = new System.Drawing.Point(795, 133);
            this.btnRegData_Mat.Name = "btnRegData_Mat";
            this.btnRegData_Mat.Size = new System.Drawing.Size(153, 31);
            this.btnRegData_Mat.TabIndex = 19;
            this.btnRegData_Mat.Text = "Registrar Data";
            this.btnRegData_Mat.UseVisualStyleBackColor = true;
            // 
            // lbPorcentaje_Mat
            // 
            this.lbPorcentaje_Mat.AutoSize = true;
            this.lbPorcentaje_Mat.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentaje_Mat.Location = new System.Drawing.Point(701, 140);
            this.lbPorcentaje_Mat.Name = "lbPorcentaje_Mat";
            this.lbPorcentaje_Mat.Size = new System.Drawing.Size(30, 17);
            this.lbPorcentaje_Mat.TabIndex = 18;
            this.lbPorcentaje_Mat.Text = "0%";
            // 
            // progressBar_Mat
            // 
            this.progressBar_Mat.Location = new System.Drawing.Point(40, 137);
            this.progressBar_Mat.Name = "progressBar_Mat";
            this.progressBar_Mat.Size = new System.Drawing.Size(655, 23);
            this.progressBar_Mat.TabIndex = 17;
            // 
            // btnCargar_Mat
            // 
            this.btnCargar_Mat.Location = new System.Drawing.Point(479, 59);
            this.btnCargar_Mat.Name = "btnCargar_Mat";
            this.btnCargar_Mat.Size = new System.Drawing.Size(149, 31);
            this.btnCargar_Mat.TabIndex = 16;
            this.btnCargar_Mat.Text = "Cargar Archivo";
            this.btnCargar_Mat.UseVisualStyleBackColor = true;
            // 
            // txtRuta_Mat
            // 
            this.txtRuta_Mat.Location = new System.Drawing.Point(40, 63);
            this.txtRuta_Mat.Name = "txtRuta_Mat";
            this.txtRuta_Mat.Size = new System.Drawing.Size(404, 22);
            this.txtRuta_Mat.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Ruta:";
            // 
            // tbpAgrp
            // 
            this.tbpAgrp.BackColor = System.Drawing.Color.White;
            this.tbpAgrp.Controls.Add(this.dgvDatos_Agr);
            this.tbpAgrp.Controls.Add(this.btnRegData_Agr);
            this.tbpAgrp.Controls.Add(this.lbPorcentaje_Agr);
            this.tbpAgrp.Controls.Add(this.progressBar_Agr);
            this.tbpAgrp.Controls.Add(this.btnCargar_Agr);
            this.tbpAgrp.Controls.Add(this.txtRuta_Agr);
            this.tbpAgrp.Controls.Add(this.label11);
            this.tbpAgrp.Location = new System.Drawing.Point(4, 25);
            this.tbpAgrp.Name = "tbpAgrp";
            this.tbpAgrp.Size = new System.Drawing.Size(987, 648);
            this.tbpAgrp.TabIndex = 4;
            this.tbpAgrp.Text = "Agrupadores";
            // 
            // dgvDatos_Agr
            // 
            this.dgvDatos_Agr.AllowUserToAddRows = false;
            this.dgvDatos_Agr.AllowUserToDeleteRows = false;
            this.dgvDatos_Agr.AllowUserToResizeColumns = false;
            this.dgvDatos_Agr.AllowUserToResizeRows = false;
            this.dgvDatos_Agr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos_Agr.Location = new System.Drawing.Point(20, 199);
            this.dgvDatos_Agr.Name = "dgvDatos_Agr";
            this.dgvDatos_Agr.ReadOnly = true;
            this.dgvDatos_Agr.RowTemplate.Height = 24;
            this.dgvDatos_Agr.Size = new System.Drawing.Size(948, 402);
            this.dgvDatos_Agr.TabIndex = 34;
            // 
            // btnRegData_Agr
            // 
            this.btnRegData_Agr.Location = new System.Drawing.Point(795, 133);
            this.btnRegData_Agr.Name = "btnRegData_Agr";
            this.btnRegData_Agr.Size = new System.Drawing.Size(153, 31);
            this.btnRegData_Agr.TabIndex = 33;
            this.btnRegData_Agr.Text = "Registrar Data";
            this.btnRegData_Agr.UseVisualStyleBackColor = true;
            // 
            // lbPorcentaje_Agr
            // 
            this.lbPorcentaje_Agr.AutoSize = true;
            this.lbPorcentaje_Agr.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentaje_Agr.Location = new System.Drawing.Point(701, 140);
            this.lbPorcentaje_Agr.Name = "lbPorcentaje_Agr";
            this.lbPorcentaje_Agr.Size = new System.Drawing.Size(30, 17);
            this.lbPorcentaje_Agr.TabIndex = 32;
            this.lbPorcentaje_Agr.Text = "0%";
            // 
            // progressBar_Agr
            // 
            this.progressBar_Agr.Location = new System.Drawing.Point(40, 137);
            this.progressBar_Agr.Name = "progressBar_Agr";
            this.progressBar_Agr.Size = new System.Drawing.Size(655, 23);
            this.progressBar_Agr.TabIndex = 31;
            // 
            // btnCargar_Agr
            // 
            this.btnCargar_Agr.Location = new System.Drawing.Point(479, 59);
            this.btnCargar_Agr.Name = "btnCargar_Agr";
            this.btnCargar_Agr.Size = new System.Drawing.Size(149, 31);
            this.btnCargar_Agr.TabIndex = 30;
            this.btnCargar_Agr.Text = "Cargar Archivo";
            this.btnCargar_Agr.UseVisualStyleBackColor = true;
            // 
            // txtRuta_Agr
            // 
            this.txtRuta_Agr.Location = new System.Drawing.Point(40, 63);
            this.txtRuta_Agr.Name = "txtRuta_Agr";
            this.txtRuta_Agr.Size = new System.Drawing.Size(404, 22);
            this.txtRuta_Agr.TabIndex = 29;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(37, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 17);
            this.label11.TabIndex = 28;
            this.label11.Text = "Ruta:";
            // 
            // tbpTpMant
            // 
            this.tbpTpMant.BackColor = System.Drawing.Color.White;
            this.tbpTpMant.Controls.Add(this.dgvDatos_Tdm);
            this.tbpTpMant.Controls.Add(this.btnRegData_Tdm);
            this.tbpTpMant.Controls.Add(this.lbPorcentaje_Tdm);
            this.tbpTpMant.Controls.Add(this.progressBar_Tdm);
            this.tbpTpMant.Controls.Add(this.btnCargar_Tdm);
            this.tbpTpMant.Controls.Add(this.txtRuta_Tdm);
            this.tbpTpMant.Controls.Add(this.label7);
            this.tbpTpMant.Location = new System.Drawing.Point(4, 25);
            this.tbpTpMant.Name = "tbpTpMant";
            this.tbpTpMant.Size = new System.Drawing.Size(987, 648);
            this.tbpTpMant.TabIndex = 5;
            this.tbpTpMant.Text = "Tipos de Mantenimiento";
            // 
            // dgvDatos_Tdm
            // 
            this.dgvDatos_Tdm.AllowUserToAddRows = false;
            this.dgvDatos_Tdm.AllowUserToDeleteRows = false;
            this.dgvDatos_Tdm.AllowUserToResizeColumns = false;
            this.dgvDatos_Tdm.AllowUserToResizeRows = false;
            this.dgvDatos_Tdm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos_Tdm.Location = new System.Drawing.Point(20, 199);
            this.dgvDatos_Tdm.Name = "dgvDatos_Tdm";
            this.dgvDatos_Tdm.ReadOnly = true;
            this.dgvDatos_Tdm.RowTemplate.Height = 24;
            this.dgvDatos_Tdm.Size = new System.Drawing.Size(948, 402);
            this.dgvDatos_Tdm.TabIndex = 41;
            // 
            // btnRegData_Tdm
            // 
            this.btnRegData_Tdm.Location = new System.Drawing.Point(795, 133);
            this.btnRegData_Tdm.Name = "btnRegData_Tdm";
            this.btnRegData_Tdm.Size = new System.Drawing.Size(153, 31);
            this.btnRegData_Tdm.TabIndex = 40;
            this.btnRegData_Tdm.Text = "Registrar Data";
            this.btnRegData_Tdm.UseVisualStyleBackColor = true;
            // 
            // lbPorcentaje_Tdm
            // 
            this.lbPorcentaje_Tdm.AutoSize = true;
            this.lbPorcentaje_Tdm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentaje_Tdm.Location = new System.Drawing.Point(701, 140);
            this.lbPorcentaje_Tdm.Name = "lbPorcentaje_Tdm";
            this.lbPorcentaje_Tdm.Size = new System.Drawing.Size(30, 17);
            this.lbPorcentaje_Tdm.TabIndex = 39;
            this.lbPorcentaje_Tdm.Text = "0%";
            // 
            // progressBar_Tdm
            // 
            this.progressBar_Tdm.Location = new System.Drawing.Point(40, 137);
            this.progressBar_Tdm.Name = "progressBar_Tdm";
            this.progressBar_Tdm.Size = new System.Drawing.Size(655, 23);
            this.progressBar_Tdm.TabIndex = 38;
            // 
            // btnCargar_Tdm
            // 
            this.btnCargar_Tdm.Location = new System.Drawing.Point(479, 59);
            this.btnCargar_Tdm.Name = "btnCargar_Tdm";
            this.btnCargar_Tdm.Size = new System.Drawing.Size(149, 31);
            this.btnCargar_Tdm.TabIndex = 37;
            this.btnCargar_Tdm.Text = "Cargar Archivo";
            this.btnCargar_Tdm.UseVisualStyleBackColor = true;
            // 
            // txtRuta_Tdm
            // 
            this.txtRuta_Tdm.Location = new System.Drawing.Point(40, 63);
            this.txtRuta_Tdm.Name = "txtRuta_Tdm";
            this.txtRuta_Tdm.Size = new System.Drawing.Size(404, 22);
            this.txtRuta_Tdm.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(37, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 17);
            this.label7.TabIndex = 35;
            this.label7.Text = "Ruta:";
            // 
            // tbpJefRev
            // 
            this.tbpJefRev.BackColor = System.Drawing.Color.White;
            this.tbpJefRev.Controls.Add(this.dgvDatos_Jr);
            this.tbpJefRev.Controls.Add(this.btnRegData_Jr);
            this.tbpJefRev.Controls.Add(this.lbPorcentaje_Jr);
            this.tbpJefRev.Controls.Add(this.progressBar_Jr);
            this.tbpJefRev.Controls.Add(this.btnCargar_Jr);
            this.tbpJefRev.Controls.Add(this.txtRuta_Jr);
            this.tbpJefRev.Controls.Add(this.label9);
            this.tbpJefRev.Location = new System.Drawing.Point(4, 25);
            this.tbpJefRev.Name = "tbpJefRev";
            this.tbpJefRev.Size = new System.Drawing.Size(987, 648);
            this.tbpJefRev.TabIndex = 6;
            this.tbpJefRev.Text = "Jefes Revisores";
            // 
            // dgvDatos_Jr
            // 
            this.dgvDatos_Jr.AllowUserToAddRows = false;
            this.dgvDatos_Jr.AllowUserToDeleteRows = false;
            this.dgvDatos_Jr.AllowUserToResizeColumns = false;
            this.dgvDatos_Jr.AllowUserToResizeRows = false;
            this.dgvDatos_Jr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos_Jr.Location = new System.Drawing.Point(20, 199);
            this.dgvDatos_Jr.Name = "dgvDatos_Jr";
            this.dgvDatos_Jr.ReadOnly = true;
            this.dgvDatos_Jr.RowTemplate.Height = 24;
            this.dgvDatos_Jr.Size = new System.Drawing.Size(948, 402);
            this.dgvDatos_Jr.TabIndex = 48;
            // 
            // btnRegData_Jr
            // 
            this.btnRegData_Jr.Location = new System.Drawing.Point(795, 133);
            this.btnRegData_Jr.Name = "btnRegData_Jr";
            this.btnRegData_Jr.Size = new System.Drawing.Size(153, 31);
            this.btnRegData_Jr.TabIndex = 47;
            this.btnRegData_Jr.Text = "Registrar Data";
            this.btnRegData_Jr.UseVisualStyleBackColor = true;
            // 
            // lbPorcentaje_Jr
            // 
            this.lbPorcentaje_Jr.AutoSize = true;
            this.lbPorcentaje_Jr.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentaje_Jr.Location = new System.Drawing.Point(701, 140);
            this.lbPorcentaje_Jr.Name = "lbPorcentaje_Jr";
            this.lbPorcentaje_Jr.Size = new System.Drawing.Size(30, 17);
            this.lbPorcentaje_Jr.TabIndex = 46;
            this.lbPorcentaje_Jr.Text = "0%";
            // 
            // progressBar_Jr
            // 
            this.progressBar_Jr.Location = new System.Drawing.Point(40, 137);
            this.progressBar_Jr.Name = "progressBar_Jr";
            this.progressBar_Jr.Size = new System.Drawing.Size(655, 23);
            this.progressBar_Jr.TabIndex = 45;
            // 
            // btnCargar_Jr
            // 
            this.btnCargar_Jr.Location = new System.Drawing.Point(479, 59);
            this.btnCargar_Jr.Name = "btnCargar_Jr";
            this.btnCargar_Jr.Size = new System.Drawing.Size(149, 31);
            this.btnCargar_Jr.TabIndex = 44;
            this.btnCargar_Jr.Text = "Cargar Archivo";
            this.btnCargar_Jr.UseVisualStyleBackColor = true;
            // 
            // txtRuta_Jr
            // 
            this.txtRuta_Jr.Location = new System.Drawing.Point(40, 63);
            this.txtRuta_Jr.Name = "txtRuta_Jr";
            this.txtRuta_Jr.Size = new System.Drawing.Size(404, 22);
            this.txtRuta_Jr.TabIndex = 43;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(37, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 17);
            this.label9.TabIndex = 42;
            this.label9.Text = "Ruta:";
            // 
            // tbpDic
            // 
            this.tbpDic.BackColor = System.Drawing.Color.White;
            this.tbpDic.Controls.Add(this.tabDicControl);
            this.tbpDic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpDic.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbpDic.Location = new System.Drawing.Point(4, 25);
            this.tbpDic.Name = "tbpDic";
            this.tbpDic.Size = new System.Drawing.Size(987, 648);
            this.tbpDic.TabIndex = 7;
            this.tbpDic.Text = "Diccionario";
            // 
            // tabDicControl
            // 
            this.tabDicControl.Controls.Add(this.tbpDicOrd);
            this.tabDicControl.Controls.Add(this.tbpDicCc);
            this.tabDicControl.Controls.Add(this.tbpDicMat);
            this.tabDicControl.Controls.Add(this.tbpDicAgr);
            this.tabDicControl.Controls.Add(this.tbpDicTdm);
            this.tabDicControl.Controls.Add(this.tbpDicJr);
            this.tabDicControl.Location = new System.Drawing.Point(0, 0);
            this.tabDicControl.Name = "tabDicControl";
            this.tabDicControl.Padding = new System.Drawing.Point(8, 3);
            this.tabDicControl.SelectedIndex = 0;
            this.tabDicControl.Size = new System.Drawing.Size(987, 647);
            this.tabDicControl.TabIndex = 0;
            this.tabDicControl.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabDicControl_DrawItem);
            // 
            // tbpDicOrd
            // 
            this.tbpDicOrd.BackColor = System.Drawing.Color.White;
            this.tbpDicOrd.Controls.Add(this.dgvDic_Ord);
            this.tbpDicOrd.Location = new System.Drawing.Point(4, 25);
            this.tbpDicOrd.Name = "tbpDicOrd";
            this.tbpDicOrd.Padding = new System.Windows.Forms.Padding(3);
            this.tbpDicOrd.Size = new System.Drawing.Size(979, 618);
            this.tbpDicOrd.TabIndex = 0;
            this.tbpDicOrd.Text = "Ordenes - CeCo";
            // 
            // dgvDic_Ord
            // 
            this.dgvDic_Ord.AllowUserToAddRows = false;
            this.dgvDic_Ord.AllowUserToDeleteRows = false;
            this.dgvDic_Ord.AllowUserToResizeColumns = false;
            this.dgvDic_Ord.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Ord.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDic_Ord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDic_Ord.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDic_Ord.Location = new System.Drawing.Point(76, 36);
            this.dgvDic_Ord.Name = "dgvDic_Ord";
            this.dgvDic_Ord.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Ord.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDic_Ord.RowTemplate.Height = 24;
            this.dgvDic_Ord.Size = new System.Drawing.Size(809, 530);
            this.dgvDic_Ord.TabIndex = 8;
            // 
            // tbpDicCc
            // 
            this.tbpDicCc.BackColor = System.Drawing.Color.White;
            this.tbpDicCc.Controls.Add(this.dgvDic_Cc);
            this.tbpDicCc.Location = new System.Drawing.Point(4, 25);
            this.tbpDicCc.Name = "tbpDicCc";
            this.tbpDicCc.Padding = new System.Windows.Forms.Padding(3);
            this.tbpDicCc.Size = new System.Drawing.Size(979, 618);
            this.tbpDicCc.TabIndex = 1;
            this.tbpDicCc.Text = "Cuentas Contables";
            // 
            // dgvDic_Cc
            // 
            this.dgvDic_Cc.AllowUserToAddRows = false;
            this.dgvDic_Cc.AllowUserToDeleteRows = false;
            this.dgvDic_Cc.AllowUserToResizeColumns = false;
            this.dgvDic_Cc.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Cc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvDic_Cc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDic_Cc.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvDic_Cc.Location = new System.Drawing.Point(76, 36);
            this.dgvDic_Cc.Name = "dgvDic_Cc";
            this.dgvDic_Cc.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Cc.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvDic_Cc.RowTemplate.Height = 24;
            this.dgvDic_Cc.Size = new System.Drawing.Size(809, 117);
            this.dgvDic_Cc.TabIndex = 16;
            // 
            // tbpDicMat
            // 
            this.tbpDicMat.BackColor = System.Drawing.Color.White;
            this.tbpDicMat.Controls.Add(this.dgvDic_Mat);
            this.tbpDicMat.Location = new System.Drawing.Point(4, 25);
            this.tbpDicMat.Name = "tbpDicMat";
            this.tbpDicMat.Size = new System.Drawing.Size(979, 618);
            this.tbpDicMat.TabIndex = 2;
            this.tbpDicMat.Text = "Materiales";
            // 
            // dgvDic_Mat
            // 
            this.dgvDic_Mat.AllowUserToAddRows = false;
            this.dgvDic_Mat.AllowUserToDeleteRows = false;
            this.dgvDic_Mat.AllowUserToResizeColumns = false;
            this.dgvDic_Mat.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Mat.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvDic_Mat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDic_Mat.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvDic_Mat.Location = new System.Drawing.Point(76, 36);
            this.dgvDic_Mat.Name = "dgvDic_Mat";
            this.dgvDic_Mat.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Mat.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvDic_Mat.RowTemplate.Height = 24;
            this.dgvDic_Mat.Size = new System.Drawing.Size(809, 176);
            this.dgvDic_Mat.TabIndex = 24;
            // 
            // tbpDicAgr
            // 
            this.tbpDicAgr.BackColor = System.Drawing.Color.White;
            this.tbpDicAgr.Controls.Add(this.dgvDic_Agr);
            this.tbpDicAgr.Location = new System.Drawing.Point(4, 25);
            this.tbpDicAgr.Name = "tbpDicAgr";
            this.tbpDicAgr.Size = new System.Drawing.Size(979, 618);
            this.tbpDicAgr.TabIndex = 3;
            this.tbpDicAgr.Text = "Agrupadores";
            // 
            // dgvDic_Agr
            // 
            this.dgvDic_Agr.AllowUserToAddRows = false;
            this.dgvDic_Agr.AllowUserToDeleteRows = false;
            this.dgvDic_Agr.AllowUserToResizeColumns = false;
            this.dgvDic_Agr.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Agr.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvDic_Agr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDic_Agr.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvDic_Agr.Location = new System.Drawing.Point(76, 36);
            this.dgvDic_Agr.Name = "dgvDic_Agr";
            this.dgvDic_Agr.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Agr.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvDic_Agr.RowTemplate.Height = 24;
            this.dgvDic_Agr.Size = new System.Drawing.Size(809, 150);
            this.dgvDic_Agr.TabIndex = 24;
            // 
            // tbpDicTdm
            // 
            this.tbpDicTdm.BackColor = System.Drawing.Color.White;
            this.tbpDicTdm.Controls.Add(this.dgvDic_Tdm);
            this.tbpDicTdm.Location = new System.Drawing.Point(4, 25);
            this.tbpDicTdm.Name = "tbpDicTdm";
            this.tbpDicTdm.Size = new System.Drawing.Size(979, 618);
            this.tbpDicTdm.TabIndex = 4;
            this.tbpDicTdm.Text = "Tipos de Mantenimiento";
            // 
            // dgvDic_Tdm
            // 
            this.dgvDic_Tdm.AllowUserToAddRows = false;
            this.dgvDic_Tdm.AllowUserToDeleteRows = false;
            this.dgvDic_Tdm.AllowUserToResizeColumns = false;
            this.dgvDic_Tdm.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Tdm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvDic_Tdm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDic_Tdm.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvDic_Tdm.Location = new System.Drawing.Point(76, 36);
            this.dgvDic_Tdm.Name = "dgvDic_Tdm";
            this.dgvDic_Tdm.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Tdm.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvDic_Tdm.RowTemplate.Height = 24;
            this.dgvDic_Tdm.Size = new System.Drawing.Size(809, 117);
            this.dgvDic_Tdm.TabIndex = 24;
            // 
            // tbpDicJr
            // 
            this.tbpDicJr.BackColor = System.Drawing.Color.White;
            this.tbpDicJr.Controls.Add(this.dgvDic_Jr);
            this.tbpDicJr.Location = new System.Drawing.Point(4, 25);
            this.tbpDicJr.Name = "tbpDicJr";
            this.tbpDicJr.Size = new System.Drawing.Size(979, 618);
            this.tbpDicJr.TabIndex = 5;
            this.tbpDicJr.Text = "Jefes Revisores";
            // 
            // dgvDic_Jr
            // 
            this.dgvDic_Jr.AllowUserToAddRows = false;
            this.dgvDic_Jr.AllowUserToDeleteRows = false;
            this.dgvDic_Jr.AllowUserToResizeColumns = false;
            this.dgvDic_Jr.AllowUserToResizeRows = false;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Jr.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvDic_Jr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDic_Jr.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvDic_Jr.Location = new System.Drawing.Point(76, 36);
            this.dgvDic_Jr.Name = "dgvDic_Jr";
            this.dgvDic_Jr.ReadOnly = true;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDic_Jr.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvDic_Jr.RowTemplate.Height = 24;
            this.dgvDic_Jr.Size = new System.Drawing.Size(809, 145);
            this.dgvDic_Jr.TabIndex = 24;
            // 
            // ui_mqt_gastos_maestros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 679);
            this.Controls.Add(this.tabControl);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ui_mqt_gastos_maestros";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Maestros de Maqueta de Gastos";
            this.Load += new System.EventHandler(this.ui_mqt_gastos_maestros_Load);
            this.tabControl.ResumeLayout(false);
            this.tbpOrdCeCo.ResumeLayout(false);
            this.tbpOrdCeCo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GifLoading)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos)).EndInit();
            this.tbpCntCont.ResumeLayout(false);
            this.tbpCntCont.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Cc)).EndInit();
            this.tbpMat.ResumeLayout(false);
            this.tbpMat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Mat)).EndInit();
            this.tbpAgrp.ResumeLayout(false);
            this.tbpAgrp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Agr)).EndInit();
            this.tbpTpMant.ResumeLayout(false);
            this.tbpTpMant.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Tdm)).EndInit();
            this.tbpJefRev.ResumeLayout(false);
            this.tbpJefRev.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos_Jr)).EndInit();
            this.tbpDic.ResumeLayout(false);
            this.tabDicControl.ResumeLayout(false);
            this.tbpDicOrd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Ord)).EndInit();
            this.tbpDicCc.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Cc)).EndInit();
            this.tbpDicMat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Mat)).EndInit();
            this.tbpDicAgr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Agr)).EndInit();
            this.tbpDicTdm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Tdm)).EndInit();
            this.tbpDicJr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDic_Jr)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tbpOrdCeCo;
        private System.Windows.Forms.TabPage tbpCntCont;
        private System.Windows.Forms.TabPage tbpMat;
        private System.Windows.Forms.TabPage tbpTpMant;
        private System.Windows.Forms.TabPage tbpJefRev;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.Button btnCargar;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label lbPorcentaje;
        private System.Windows.Forms.Button btnRegData;
        private System.Windows.Forms.DataGridView dgvDatos;
        private System.Windows.Forms.DataGridView dgvDatos_Cc;
        private System.Windows.Forms.Button btnRegData_Cc;
        private System.Windows.Forms.Label lbPorcentaje_Cc;
        private System.Windows.Forms.ProgressBar progressBar_Cc;
        private System.Windows.Forms.Button btnCargar_Cc;
        private System.Windows.Forms.TextBox txtRuta_Cc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvDatos_Mat;
        private System.Windows.Forms.Button btnRegData_Mat;
        private System.Windows.Forms.Label lbPorcentaje_Mat;
        private System.Windows.Forms.ProgressBar progressBar_Mat;
        private System.Windows.Forms.Button btnCargar_Mat;
        private System.Windows.Forms.TextBox txtRuta_Mat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgvDatos_Tdm;
        private System.Windows.Forms.Button btnRegData_Tdm;
        private System.Windows.Forms.Label lbPorcentaje_Tdm;
        private System.Windows.Forms.ProgressBar progressBar_Tdm;
        private System.Windows.Forms.Button btnCargar_Tdm;
        private System.Windows.Forms.TextBox txtRuta_Tdm;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvDatos_Jr;
        private System.Windows.Forms.Button btnRegData_Jr;
        private System.Windows.Forms.Label lbPorcentaje_Jr;
        private System.Windows.Forms.ProgressBar progressBar_Jr;
        private System.Windows.Forms.Button btnCargar_Jr;
        private System.Windows.Forms.TextBox txtRuta_Jr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tbpDic;
        private System.Windows.Forms.TabControl tabDicControl;
        private System.Windows.Forms.TabPage tbpDicOrd;
        private System.Windows.Forms.TabPage tbpDicCc;
        private System.Windows.Forms.TabPage tbpDicMat;
        private System.Windows.Forms.TabPage tbpDicAgr;
        private System.Windows.Forms.TabPage tbpDicTdm;
        private System.Windows.Forms.TabPage tbpDicJr;
        private System.Windows.Forms.TabPage tbpAgrp;
        private System.Windows.Forms.DataGridView dgvDatos_Agr;
        private System.Windows.Forms.Button btnRegData_Agr;
        private System.Windows.Forms.Label lbPorcentaje_Agr;
        private System.Windows.Forms.ProgressBar progressBar_Agr;
        private System.Windows.Forms.Button btnCargar_Agr;
        private System.Windows.Forms.TextBox txtRuta_Agr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgvDic_Ord;
        private System.Windows.Forms.DataGridView dgvDic_Cc;
        private System.Windows.Forms.DataGridView dgvDic_Mat;
        private System.Windows.Forms.DataGridView dgvDic_Agr;
        private System.Windows.Forms.DataGridView dgvDic_Tdm;
        private System.Windows.Forms.DataGridView dgvDic_Jr;
        private System.Windows.Forms.ComboBox cmbHojas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbNReg;
        private System.Windows.Forms.PictureBox GifLoading;
    }
}