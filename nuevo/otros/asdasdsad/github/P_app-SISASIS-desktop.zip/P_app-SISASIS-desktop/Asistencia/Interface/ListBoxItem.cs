﻿namespace CaniaBrava.Interface
{
    internal class ListBoxItem
    {
    }
}